from src.problems.cvrp.components import *
import numpy as np
from typing import Tuple, Optional

def greedy_insertion_e356(problem_state: dict, algorithm_data: dict, **kwargs) -> Tuple[Optional[InsertOperator], dict]:
    """Enhanced greedy insertion heuristic for CVRP with adaptive penalty for inefficient depot patterns.
    
    This algorithm identifies the best insertion position for each unvisited customer by calculating
    the minimal distance increase while respecting vehicle capacity constraints. It applies adaptive
    penalties that scale with problem spatial characteristics to discourage inefficient depot-customer-depot
    patterns in early route construction.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - distance_matrix (numpy.ndarray): Distance matrix between all nodes
            - capacity (int): Vehicle capacity constraint
            - depot (int): Depot node index
            - demands (numpy.ndarray): Demand values for each node
            - current_solution (Solution): Current solution with routes
            - validation_solution (callable): Function to validate solution feasibility
            - avg_distance_to_depot (float): Average distance from customers to depot
        algorithm_data (dict): Not used in this algorithm, returns empty dict
        **kwargs: Hyper-parameters for the algorithm:
            - insertion_strategy (str): Strategy for customer selection ('farthest_first' or 'nearest_first', default: 'farthest_first')
            - allow_new_routes (bool): Whether to allow inserting into empty vehicles (default: True)
            - max_attempts (int): Maximum attempts to find valid insertion (default: 1000)
            - min_route_length_for_penalty (int): Minimum route length to apply penalty (default: 2)
            - base_penalty_start (float): Base penalty factor for start positions (default: 1.2)
            - base_penalty_end (float): Base penalty factor for end positions (default: 1.1)
            - distance_scale_factor_start (float): Scaling factor for distance-based penalty at start (default: 0.3)
            - distance_scale_factor_end (float): Scaling factor for distance-based penalty at end (default: 0.2)

    Returns:
        InsertOperator: Operator that inserts a customer at the optimal position, or None if no valid insertion found
        dict: Empty dictionary as no algorithm data is updated

    The algorithm will return None if:
    1. All customers are already visited in the solution
    2. No valid insertion position found that respects capacity constraints
    3. Maximum attempts reached without finding a feasible insertion
    """
    
    # Extract hyper-parameters with default values
    insertion_strategy = kwargs.get('insertion_strategy', 'farthest_first')
    allow_new_routes = kwargs.get('allow_new_routes', True)
    max_attempts = kwargs.get('max_attempts', 1000)
    min_route_length_for_penalty = kwargs.get('min_route_length_for_penalty', 2)
    base_penalty_start = kwargs.get('base_penalty_start', 1.2)
    base_penalty_end = kwargs.get('base_penalty_end', 1.1)
    distance_scale_factor_start = kwargs.get('distance_scale_factor_start', 0.3)
    distance_scale_factor_end = kwargs.get('distance_scale_factor_end', 0.2)
    
    # Extract necessary problem state data
    distance_matrix = problem_state['distance_matrix']
    capacity = problem_state['capacity']
    depot = problem_state['depot']
    demands = problem_state['demands']
    current_solution = problem_state['current_solution']
    validation_solution = problem_state['validation_solution']
    avg_distance_to_depot = problem_state['avg_distance_to_depot']
    
    # Calculate maximum possible distance for normalization
    max_distance = np.max(distance_matrix)
    if max_distance == 0:  # Handle edge case
        max_distance = 1
    
    # Calculate adaptive penalty factors based on spatial characteristics
    distance_ratio = avg_distance_to_depot / max_distance
    adaptive_penalty_start = base_penalty_start + (distance_scale_factor_start * distance_ratio)
    adaptive_penalty_end = base_penalty_end + (distance_scale_factor_end * distance_ratio)
    
    # Get all nodes and identify unvisited customers (excluding depot)
    all_nodes = set(range(len(distance_matrix)))
    visited_nodes = set()
    for route in current_solution.routes:
        visited_nodes.update(route)
    
    unvisited_customers = all_nodes - visited_nodes - {depot}
    
    # If no unvisited customers, return None
    if not unvisited_customers:
        return None, {}
    
    # Sort unvisited customers based on strategy
    if insertion_strategy == 'farthest_first':
        # Prioritize customers farthest from depot
        sorted_customers = sorted(unvisited_customers, 
                                 key=lambda node: distance_matrix[depot][node], 
                                 reverse=True)
    else:  # nearest_first
        # Prioritize customers nearest to depot
        sorted_customers = sorted(unvisited_customers, 
                                 key=lambda node: distance_matrix[depot][node])
    
    # Calculate current route loads
    route_loads = []
    for route in current_solution.routes:
        route_load = sum(demands[node] for node in route if node != depot)
        route_loads.append(route_load)
    
    best_insertion = None
    best_cost_increase = float('inf')
    attempts = 0
    
    # Try each customer in priority order
    for customer in sorted_customers:
        customer_demand = demands[customer]
        
        # Try each vehicle route
        for vehicle_id, route in enumerate(current_solution.routes):
            current_load = route_loads[vehicle_id]
            
            # Check capacity constraint
            if current_load + customer_demand > capacity:
                continue
            
            # Try each insertion position in the route
            for position in range(len(route) + 1):
                attempts += 1
                if attempts > max_attempts:
                    return None, {}
                
                # Apply adaptive penalty for empty/short routes
                penalty_factor = 1.0
                if len(route) < min_route_length_for_penalty:
                    if position == 0:  # Inserting at beginning
                        penalty_factor = adaptive_penalty_start
                    elif position == len(route):  # Inserting at end
                        penalty_factor = adaptive_penalty_end
                
                # Calculate cost increase for insertion with penalty
                if len(route) == 0:
                    # Empty route: cost is depot-customer-depot
                    cost_increase = 2 * distance_matrix[depot][customer] * penalty_factor
                elif position == 0:
                    # Insert at beginning
                    prev_node = depot
                    next_node = route[0]
                    cost_increase = (distance_matrix[prev_node][customer] + 
                                    distance_matrix[customer][next_node] - 
                                    distance_matrix[prev_node][next_node]) * penalty_factor
                elif position == len(route):
                    # Insert at end
                    prev_node = route[-1]
                    next_node = depot
                    cost_increase = (distance_matrix[prev_node][customer] + 
                                    distance_matrix[customer][next_node] - 
                                    distance_matrix[prev_node][next_node]) * penalty_factor
                else:
                    # Insert in middle
                    prev_node = route[position - 1]
                    next_node = route[position]
                    cost_increase = (distance_matrix[prev_node][customer] + 
                                    distance_matrix[customer][next_node] - 
                                    distance_matrix[prev_node][next_node])
                
                # Update best insertion if better
                if cost_increase < best_cost_increase:
                    best_insertion = (vehicle_id, customer, position)
                    best_cost_increase = cost_increase
        
        # Check empty vehicles if allowed
        if allow_new_routes:
            for vehicle_id, route in enumerate(current_solution.routes):
                if len(route) == 0:  # Empty vehicle
                    attempts += 1
                    if attempts > max_attempts:
                        return None, {}
                    
                    # Apply adaptive penalty for inserting at beginning of empty route
                    penalty_factor = adaptive_penalty_start
                    
                    # Cost for new route: depot-customer-depot
                    cost_increase = 2 * distance_matrix[depot][customer] * penalty_factor
                    
                    if cost_increase < best_cost_increase:
                        best_insertion = (vehicle_id, customer, 0)
                        best_cost_increase = cost_increase
    
    # Return the best insertion operator if found
    if best_insertion:
        vehicle_id, customer, position = best_insertion
        return InsertOperator(vehicle_id, customer, position), {}
    
    # No valid insertion found
    return None, {}