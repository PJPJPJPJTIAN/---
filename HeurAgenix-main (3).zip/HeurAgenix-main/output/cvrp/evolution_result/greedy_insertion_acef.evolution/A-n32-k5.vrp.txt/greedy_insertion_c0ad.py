from src.problems.cvrp.components import *
import numpy as np
from typing import Tuple, Optional

def greedy_insertion_c0ad(problem_state: dict, algorithm_data: dict, **kwargs) -> Tuple[Optional[InsertOperator], dict]:
    """Enhanced greedy insertion heuristic for CVRP with clustering awareness.
    
    This algorithm identifies the best insertion position for unvisited customers by calculating
    the minimal distance increase while respecting vehicle capacity constraints. It incorporates
    route clustering logic to maintain geographical proximity and considers route utilization
    to avoid disrupting established clusters in highly utilized routes.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - distance_matrix (numpy.ndarray): Distance matrix between all nodes
            - capacity (int): Vehicle capacity constraint
            - depot (int): Depot node index
            - demands (numpy.ndarray): Demand values for each node
            - current_solution (Solution): Current solution with routes
            - validation_solution (callable): Function to validate solution feasibility
        algorithm_data (dict): Not used in this algorithm, returns empty dict
        **kwargs: Hyper-parameters for the algorithm:
            - insertion_strategy (str): Strategy for customer selection ('farthest_first' or 'nearest_first', default: 'farthest_first')
            - allow_new_routes (bool): Whether to allow inserting into empty vehicles (default: True)
            - max_attempts (int): Maximum attempts to find valid insertion (default: 1000)
            - cluster_threshold (float): Maximum distance for considering nodes as part of the same cluster (default: 30.0)
            - high_utilization_threshold (float): Utilization threshold for considering route as highly utilized (default: 0.8)
            - end_position_discount (float): Discount factor for end positions in highly utilized routes (default: 0.8)
            - middle_position_penalty (float): Penalty factor for middle positions in highly utilized routes (default: 1.2)

    Returns:
        InsertOperator: Operator that inserts a customer at the optimal position considering clustering, or None if:
          1. All customers are already visited in the solution
          2. No valid insertion position found that respects capacity constraints
          3. Maximum attempts reached without finding a feasible insertion
        dict: Empty dictionary as no algorithm data is updated
    """
    
    # Extract hyper-parameters with default values
    insertion_strategy = kwargs.get('insertion_strategy', 'farthest_first')
    allow_new_routes = kwargs.get('allow_new_routes', True)
    max_attempts = kwargs.get('max_attempts', 1000)
    cluster_threshold = kwargs.get('cluster_threshold', 30.0)
    high_utilization_threshold = kwargs.get('high_utilization_threshold', 0.8)
    end_position_discount = kwargs.get('end_position_discount', 0.8)
    middle_position_penalty = kwargs.get('middle_position_penalty', 1.2)
    
    # Extract necessary problem state data
    distance_matrix = problem_state['distance_matrix']
    capacity = problem_state['capacity']
    depot = problem_state['depot']
    demands = problem_state['demands']
    current_solution = problem_state['current_solution']
    validation_solution = problem_state['validation_solution']
    
    # Get all nodes and identify unvisited customers (excluding depot)
    all_nodes = set(range(len(distance_matrix)))
    visited_nodes = set()
    for route in current_solution.routes:
        visited_nodes.update(route)
    
    unvisited_customers = all_nodes - visited_nodes - {depot}
    
    # If no unvisited customers, return None
    if not unvisited_customers:
        return None, {}
    
    # Sort unvisited customers based on strategy
    if insertion_strategy == 'farthest_first':
        # Prioritize customers farthest from depot
        sorted_customers = sorted(unvisited_customers, 
                                 key=lambda node: distance_matrix[depot][node], 
                                 reverse=True)
    else:  # nearest_first
        # Prioritize customers nearest to depot
        sorted_customers = sorted(unvisited_customers, 
                                 key=lambda node: distance_matrix[depot][node])
    
    # Calculate current route loads
    route_loads = []
    for route in current_solution.routes:
        route_load = sum(demands[node] for node in route if node != depot)
        route_loads.append(route_load)
    
    best_insertion = None
    best_cost_increase = float('inf')
    attempts = 0
    
    # Try each customer in priority order
    for customer in sorted_customers:
        customer_demand = demands[customer]
        
        # Try each vehicle route
        for vehicle_id, route in enumerate(current_solution.routes):
            current_load = route_loads[vehicle_id]
            
            # Check capacity constraint
            if current_load + customer_demand > capacity:
                continue
            
            # Check if customer is near any existing node in this route
            is_near_existing = False
            for existing_node in route:
                if existing_node != depot and distance_matrix[customer][existing_node] < cluster_threshold:
                    is_near_existing = True
                    break
            
            # Get current utilization for this route
            current_utilization = current_load / capacity if capacity > 0 else 0
            
            # Try each insertion position in the route
            for position in range(len(route) + 1):
                attempts += 1
                if attempts > max_attempts:
                    return None, {}
                
                # Calculate cost increase for insertion
                if len(route) == 0:
                    # Empty route: cost is depot-customer-depot
                    cost_increase = 2 * distance_matrix[depot][customer]
                elif position == 0:
                    # Insert at beginning
                    prev_node = depot
                    next_node = route[0]
                    cost_increase = (distance_matrix[prev_node][customer] + 
                                    distance_matrix[customer][next_node] - 
                                    distance_matrix[prev_node][next_node])
                elif position == len(route):
                    # Insert at end
                    prev_node = route[-1]
                    next_node = depot
                    cost_increase = (distance_matrix[prev_node][customer] + 
                                    distance_matrix[customer][next_node] - 
                                    distance_matrix[prev_node][next_node])
                else:
                    # Insert in middle
                    prev_node = route[position - 1]
                    next_node = route[position]
                    cost_increase = (distance_matrix[prev_node][customer] + 
                                    distance_matrix[customer][next_node] - 
                                    distance_matrix[prev_node][next_node])
                
                # Apply clustering-aware adjustments
                if is_near_existing and current_utilization > high_utilization_threshold:
                    # If customer is near existing nodes and route utilization is high,
                    # prefer end positions to maintain cluster integrity
                    if position == 0 or position == len(route):
                        cost_increase *= end_position_discount  # Discount end positions
                    else:
                        cost_increase *= middle_position_penalty  # Penalize middle positions
                
                # Update best insertion if better
                if cost_increase < best_cost_increase:
                    best_insertion = (vehicle_id, customer, position)
                    best_cost_increase = cost_increase
        
        # Check empty vehicles if allowed
        if allow_new_routes:
            for vehicle_id, route in enumerate(current_solution.routes):
                if len(route) == 0:  # Empty vehicle
                    attempts += 1
                    if attempts > max_attempts:
                        return None, {}
                    
                    # Cost for new route: depot-customer-depot
                    cost_increase = 2 * distance_matrix[depot][customer]
                    
                    if cost_increase < best_cost_increase:
                        best_insertion = (vehicle_id, customer, 0)
                        best_cost_increase = cost_increase
    
    # Return the best insertion operator if found
    if best_insertion:
        vehicle_id, customer, position = best_insertion
        return InsertOperator(vehicle_id, customer, position), {}
    
    # No valid insertion found
    return None, {}