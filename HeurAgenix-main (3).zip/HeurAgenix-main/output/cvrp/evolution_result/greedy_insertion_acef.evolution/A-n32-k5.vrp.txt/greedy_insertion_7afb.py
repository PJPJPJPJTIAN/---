from src.problems.cvrp.components import *
import numpy as np
from typing import Tuple, Optional

def greedy_insertion_7afb(problem_state: dict, algorithm_data: dict, **kwargs) -> Tuple[Optional[InsertOperator], dict]:
    """Enhanced greedy insertion heuristic for CVRP with non-linear adaptive capacity awareness and proximity-based routing.
    
    This algorithm improves upon basic greedy insertion by considering route capacity utilization
    with non-linear adaptive penalty scaling and customer proximity to existing routes. It prevents 
    overloading vehicles with smooth non-linear penalty transitions and promotes better geographical 
    clustering of customers.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - distance_matrix (numpy.ndarray): Distance matrix between all nodes
            - capacity (int): Vehicle capacity constraint
            - depot (int): Depot node index
            - demands (numpy.ndarray): Demand values for each node
            - current_solution (Solution): Current solution with routes
            - validation_solution (callable): Function to validate solution feasibility
        algorithm_data (dict): Not used in this algorithm, returns empty dict
        **kwargs: Hyper-parameters for the algorithm:
            - capacity_threshold (float): Routes above this utilization (0.0-1.0) start receiving penalties (default: 0.8)
            - penalty_slope (float): Slope factor for non-linear adaptive penalty calculation (default: 10.0)
            - customer_selection (str): Strategy for customer selection ('proximity_first' or 'farthest_first') (default: 'proximity_first')
            - allow_new_routes (bool): Whether to allow inserting into empty vehicles (default: True)
            - max_attempts (int): Maximum attempts to find valid insertion (default: 1000)

    Returns:
        InsertOperator: Operator that inserts a customer at the optimal position considering non-linear adaptive capacity penalties and proximity, 
                       or None if no valid insertion found
        dict: Empty dictionary as no algorithm data is updated

    The algorithm will return None if:
    1. All customers are already visited in the solution
    2. No valid insertion position found that respects capacity constraints
    3. Maximum attempts reached without finding a feasible insertion
    """
    
    # Extract hyper-parameters with default values
    capacity_threshold = kwargs.get('capacity_threshold', 0.8)
    penalty_slope = kwargs.get('penalty_slope', 10.0)
    customer_selection = kwargs.get('customer_selection', 'proximity_first')
    allow_new_routes = kwargs.get('allow_new_routes', True)
    max_attempts = kwargs.get('max_attempts', 1000)
    
    # Extract necessary problem state data
    distance_matrix = problem_state['distance_matrix']
    capacity = problem_state['capacity']
    depot = problem_state['depot']
    demands = problem_state['demands']
    current_solution = problem_state['current_solution']
    validation_solution = problem_state['validation_solution']
    
    # Get all nodes and identify unvisited customers (excluding depot)
    all_nodes = set(range(len(distance_matrix)))
    visited_nodes = set()
    for route in current_solution.routes:
        visited_nodes.update(route)
    
    unvisited_customers = all_nodes - visited_nodes - {depot}
    
    # If no unvisited customers, return None
    if not unvisited_customers:
        return None, {}
    
    # Calculate current route loads and utilizations
    route_loads = []
    route_utilizations = []
    for route in current_solution.routes:
        route_load = sum(demands[node] for node in route if node != depot)
        route_loads.append(route_load)
        route_utilizations.append(route_load / capacity)
    
    # Sort unvisited customers based on strategy
    if customer_selection == 'proximity_first':
        # Calculate minimum distance from each customer to any visited node
        customer_proximity = {}
        for customer in unvisited_customers:
            # Filter out depot and get only visited non-depot nodes
            visited_non_depot = [node for node in visited_nodes if node != depot]
            
            if visited_non_depot:  # Only calculate if there are visited non-depot nodes
                min_distance = min(distance_matrix[customer][node] for node in visited_non_depot)
                customer_proximity[customer] = min_distance
            else:
                # If no visited non-depot nodes, use distance to depot
                customer_proximity[customer] = distance_matrix[depot][customer]
        
        # Prioritize customers closest to existing routes
        sorted_customers = sorted(unvisited_customers, key=lambda node: customer_proximity[node])
    else:  # farthest_first (original strategy)
        # Prioritize customers farthest from depot
        sorted_customers = sorted(unvisited_customers, 
                                 key=lambda node: distance_matrix[depot][node], 
                                 reverse=True)
    
    best_insertion = None
    best_penalized_cost = float('inf')
    attempts = 0
    
    # Try each customer in priority order
    for customer in sorted_customers:
        customer_demand = demands[customer]
        
        # Try each vehicle route
        for vehicle_id, route in enumerate(current_solution.routes):
            current_load = route_loads[vehicle_id]
            
            # Check capacity constraint
            if current_load + customer_demand > capacity:
                continue
            
            # Try each insertion position in the route
            for position in range(len(route) + 1):
                attempts += 1
                if attempts > max_attempts:
                    return None, {}
                
                # Calculate cost increase for insertion
                if len(route) == 0:
                    # Empty route: cost is depot-customer-depot
                    cost_increase = 2 * distance_matrix[depot][customer]
                elif position == 0:
                    # Insert at beginning
                    prev_node = depot
                    next_node = route[0]
                    cost_increase = (distance_matrix[prev_node][customer] + 
                                    distance_matrix[customer][next_node] - 
                                    distance_matrix[prev_node][next_node])
                elif position == len(route):
                    # Insert at end
                    prev_node = route[-1]
                    next_node = depot
                    cost_increase = (distance_matrix[prev_node][customer] + 
                                    distance_matrix[customer][next_node] - 
                                    distance_matrix[prev_node][next_node])
                else:
                    # Insert in middle
                    prev_node = route[position - 1]
                    next_node = route[position]
                    cost_increase = (distance_matrix[prev_node][customer] + 
                                    distance_matrix[customer][next_node] - 
                                    distance_matrix[prev_node][next_node])
                
                # Apply non-linear adaptive penalty based on route utilization
                penalized_cost = cost_increase
                utilization = route_utilizations[vehicle_id]
                if utilization > capacity_threshold:
                    # Calculate non-linear penalty factor: quadratic scaling for smoother transitions
                    excess_utilization = utilization - capacity_threshold
                    penalty_factor = 1.0 + (excess_utilization ** 2) * penalty_slope
                    penalized_cost *= penalty_factor
                
                # Update best insertion if better
                if penalized_cost < best_penalized_cost:
                    best_insertion = (vehicle_id, customer, position)
                    best_penalized_cost = penalized_cost
        
        # Check empty vehicles if allowed
        if allow_new_routes:
            for vehicle_id, route in enumerate(current_solution.routes):
                if len(route) == 0:  # Empty vehicle
                    attempts += 1
                    if attempts > max_attempts:
                        return None, {}
                    
                    # Cost for new route: depot-customer-depot
                    cost_increase = 2 * distance_matrix[depot][customer]
                    
                    # Empty vehicles have 0 utilization, so no penalty
                    if cost_increase < best_penalized_cost:
                        best_insertion = (vehicle_id, customer, 0)
                        best_penalized_cost = cost_increase
    
    # Return the best insertion operator if found
    if best_insertion:
        vehicle_id, customer, position = best_insertion
        return InsertOperator(vehicle_id, customer, position), {}
    
    # No valid insertion found
    return None, {}