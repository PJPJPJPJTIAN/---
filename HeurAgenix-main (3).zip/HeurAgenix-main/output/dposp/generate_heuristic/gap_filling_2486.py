from src.problems.dposp.components import *
import numpy as np
from typing import Optional

def gap_filling_2486(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[Optional[InsertOperator], dict]:
    """ Gap filling heuristic that inserts orders into existing gaps in schedules where they can fit without violating deadlines.
    
    This heuristic identifies the best position across all production lines to insert an unfulfilled order
    that minimizes the impact on the schedule while ensuring the order meets its deadline and doesn't
    cause subsequent orders to miss their deadlines.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - current_solution (Solution): Current solution instance with production schedules
            - production_rate (numpy.array): 2D array of production speeds for each product on each production line
            - transition_time (numpy.array): 3D array of transition times between products
            - order_product (numpy.array): 1D array mapping orders to required products
            - order_quantity (numpy.array): 1D array of quantity required for each order
            - order_deadline (numpy.array): 1D array of deadlines for each order
            - validation_single_production_schedule (callable): Function to validate a production schedule
            - get_time_cost_delta (callable): Function to get time cost delta for insertion
        algorithm_data (dict): The algorithm dictionary for current algorithm. In this algorithm, the following items are necessary:
            - unfulfilled_orders (list): List of order IDs that haven't been scheduled yet (optional, will be computed if not provided)
        max_gap_size_ratio (float, default=0.3): Maximum allowed gap size ratio relative to average order processing time
        min_time_saving (float, default=0.1): Minimum time saving required to consider a gap insertion
        
    Returns:
        InsertOperator: Operator to insert an order at the best found position, or None if no valid insertion found
        dict: Updated algorithm data with unfulfilled_orders list
        
    The algorithm will return None if:
    1. No unfulfilled orders exist
    2. No valid insertion position is found for any unfulfilled order
    3. All potential insertions would violate deadlines or constraints
    """
    
    # Extract hyperparameters with default values
    max_gap_size_ratio = kwargs.get('max_gap_size_ratio', 0.3)
    min_time_saving = kwargs.get('min_time_saving', 0.1)
    
    # Extract necessary problem state data
    current_solution = problem_state['current_solution']
    production_rate = problem_state['production_rate']
    transition_time = problem_state['transition_time']
    order_product = problem_state['order_product']
    order_quantity = problem_state['order_quantity']
    order_deadline = problem_state['order_deadline']
    validation_single_production_schedule = problem_state['validation_single_production_schedule']
    get_time_cost_delta = problem_state['get_time_cost_delta']
    
    # Get or compute unfulfilled orders
    if 'unfulfilled_orders' in algorithm_data:
        unfulfilled_orders = algorithm_data['unfulfilled_orders']
    else:
        # Compute unfulfilled orders by checking all orders not in current solution
        scheduled_orders = set()
        for line_schedule in current_solution.production_schedule:
            scheduled_orders.update(line_schedule)
        unfulfilled_orders = [order_id for order_id in range(len(order_product)) 
                             if order_id not in scheduled_orders]
    
    # If no unfulfilled orders, return None
    if not unfulfilled_orders:
        return None, {'unfulfilled_orders': []}
    
    best_insertion = None
    best_time_saving = float('-inf')
    
    # Iterate through all production lines
    for line_id, line_schedule in enumerate(current_solution.production_schedule):
        line_length = len(line_schedule)
        
        # Check insertion positions (including beginning and end)
        for position in range(line_length + 1):
            
            # For each unfulfilled order, check if it can be inserted at this position
            for order_id in unfulfilled_orders:
                product_id = order_product[order_id]
                
                # Check if machine can produce this product
                if production_rate[line_id, product_id] <= 0:
                    continue
                
                # Check if insertion is valid (transition constraints, deadlines)
                temp_schedule = line_schedule[:]
                temp_schedule.insert(position, order_id)
                
                if validation_single_production_schedule(line_id, temp_schedule):
                    # Calculate time cost delta for this insertion
                    time_delta = get_time_cost_delta(line_id, order_id, position, current_solution)
                    
                    # Negative time_delta means time saving (good)
                    if time_delta < 0 and abs(time_delta) > min_time_saving:
                        # Check if this is the best insertion found so far
                        if time_delta < best_time_saving:
                            best_time_saving = time_delta
                            best_insertion = (line_id, order_id, position)
    
    # If a valid insertion was found, return the operator
    if best_insertion:
        line_id, order_id, position = best_insertion
        # Remove the order from unfulfilled list
        updated_unfulfilled = [oid for oid in unfulfilled_orders if oid != order_id]
        return InsertOperator(line_id, order_id, position), {'unfulfilled_orders': updated_unfulfilled}
    
    # No valid insertion found
    return None, {'unfulfilled_orders': unfulfilled_orders}