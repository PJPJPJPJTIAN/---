from src.problems.dposp.components import *
import numpy as np
from typing import Optional

def least_transition_time_65d2(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[Optional[BaseOperator], dict]:
    """Implements the least transition time heuristic for DPOSP.
    
    This heuristic selects an order that minimizes transition time from the last product
    on a machine and appends it to the end of the production line. It prioritizes reducing
    setup overhead by choosing orders with minimal transition requirements.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - production_line_num (int): Total number of production lines
            - transition_time (numpy.array): 3D array of transition time between products on each production line
            - order_product (numpy.array): 1D array mapping each order to its required product
            - current_solution (Solution): Current solution instance
            - validation_single_production_schedule (callable): Function to validate a production schedule
            - production_rate (numpy.array): 2D array of production time for each product on each production line
            - order_quantity (numpy.array): 1D array of quantity required for each order
            - order_deadline (numpy.array): 1D array of deadline for each order
            - get_time_cost_delta (callable): Function to get time cost delta for insertion
            
        algorithm_data (dict): The algorithm dictionary for current algorithm only. In this algorithm, no specific data is required.
        
        **kwargs: Hyperparameters for the algorithm:
            - max_attempts (int, default=100): Maximum number of attempts to find a valid insertion
            - consider_deadlines (bool, default=True): Whether to consider deadline feasibility

    Returns:
        BaseOperator: An AppendOperator if a valid order is found, None otherwise
        dict: Empty dictionary (no algorithm data updates)
        
    The algorithm will return None if:
    1. No production lines exist
    2. No unfulfilled orders can be found
    3. No valid insertion position is found within max_attempts
    4. All potential insertions violate deadlines (when consider_deadlines=True)
    """
    
    # Extract hyperparameters with default values
    max_attempts = kwargs.get('max_attempts', 100)
    consider_deadlines = kwargs.get('consider_deadlines', True)
    
    # Extract necessary problem state data
    production_line_num = problem_state['production_line_num']
    transition_time = problem_state['transition_time']
    order_product = problem_state['order_product']
    current_solution = problem_state['current_solution']
    validation_func = problem_state['validation_single_production_schedule']
    production_rate = problem_state['production_rate']
    order_quantity = problem_state['order_quantity']
    order_deadline = problem_state['order_deadline']
    get_time_cost_delta = problem_state['get_time_cost_delta']
    
    # Get all orders from current solution to identify unfulfilled ones
    fulfilled_orders = set()
    for line_schedule in current_solution.production_schedule:
        fulfilled_orders.update(line_schedule)
    
    # Find unfulfilled orders (orders not in any production line)
    unfulfilled_orders = [order_id for order_id in range(len(order_product)) 
                         if order_id not in fulfilled_orders]
    
    if not unfulfilled_orders or production_line_num == 0:
        return None, {}
    
    # Try to find the best order to append with minimal transition time
    best_line_id = None
    best_order_id = None
    min_transition = float('inf')
    
    attempts = 0
    for line_id in range(production_line_num):
        # Get the current schedule for this production line
        current_schedule = current_solution.production_schedule[line_id]
        
        # Determine the last product on this line (if any)
        last_product = None
        if current_schedule:
            last_order = current_schedule[-1]
            last_product = order_product[last_order]
        
        # Check each unfulfilled order for minimal transition
        for order_id in unfulfilled_orders:
            if attempts >= max_attempts:
                break
                
            attempts += 1
            
            product_id = order_product[order_id]
            
            # Check if machine can produce this product
            if production_rate[line_id, product_id] == 0:
                continue
            
            # Calculate transition time
            if last_product is None:
                # First order on the line, no transition time
                transition = 0
            else:
                transition = transition_time[line_id, last_product, product_id]
                # Skip if transition is infinite (not allowed)
                if np.isinf(transition) or transition < 0:
                    continue
            
            # Check if this order has lower transition time
            if transition < min_transition:
                # Create temporary schedule to validate
                temp_schedule = current_schedule + [order_id]
                
                # Validate the schedule
                if validation_func(line_id, temp_schedule):
                    # Check deadline feasibility if required
                    if consider_deadlines:
                        # Calculate completion time for this order
                        production_time = order_quantity[order_id] / production_rate[line_id, product_id]
                        completion_time = get_time_cost_delta(line_id, order_id, len(current_schedule))
                        
                        if completion_time <= order_deadline[order_id]:
                            best_line_id = line_id
                            best_order_id = order_id
                            min_transition = transition
                    else:
                        best_line_id = line_id
                        best_order_id = order_id
                        min_transition = transition
    
    # Return the best found operator
    if best_line_id is not None and best_order_id is not None:
        return AppendOperator(best_line_id, best_order_id), {}
    else:
        return None, {}