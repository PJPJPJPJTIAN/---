from src.problems.dposp.components import *
import numpy as np
from typing import Optional

def highest_machine_compatibility_58c1(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[Optional[BaseOperator], dict]:
    """Heuristic that assigns orders to machines with the highest production speed for that product type.
    
    This algorithm identifies unfulfilled orders and finds the machine with the highest production rate
    for each order's product. It then attempts to append the order to the end of that machine's schedule
    if feasible (meets deadline and valid transitions). If the optimal machine cannot accommodate the order,
    it tries other machines in descending order of production speed.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - production_rate (numpy.array): 2D array of production rates for each product on each production line
            - order_product (numpy.array): 1D array mapping each order to its required product
            - current_solution (Solution): Current solution instance with production schedules
            - validation_single_production_schedule (callable): Function to validate a production schedule
            - get_time_cost_delta (callable): Function to calculate time cost delta for insertion
        algorithm_data (dict): Not used in this algorithm, returns empty dict
        kwargs: Hyperparameters (none required for this basic heuristic)
        
    Returns:
        AppendOperator if a valid assignment is found, None otherwise
        Empty algorithm data dictionary
        
    The algorithm will return None if:
    - All orders are already fulfilled in the current solution
    - No machine can produce the selected order's product (production_rate = 0)
    - No valid position found on any machine that meets the deadline constraint
    """
    
    # Extract necessary data from problem state
    production_rate = problem_state["production_rate"]
    order_product = problem_state["order_product"]
    current_solution = problem_state["current_solution"]
    validation_single_production_schedule = problem_state["validation_single_production_schedule"]
    get_time_cost_delta = problem_state["get_time_cost_delta"]
    
    # Find unfulfilled orders (orders not present in any production line schedule)
    fulfilled_orders = set()
    for line_schedule in current_solution.production_schedule:
        fulfilled_orders.update(line_schedule)
    
    unfulfilled_orders = [order_id for order_id in range(len(order_product)) 
                         if order_id not in fulfilled_orders]
    
    # If all orders are fulfilled, return None
    if not unfulfilled_orders:
        return None, {}
    
    # For each unfulfilled order, find the best machine and check feasibility
    for order_id in unfulfilled_orders:
        product_id = order_product[order_id]
        
        # Get production rates for this product across all machines
        machine_rates = production_rate[:, product_id]
        
        # Filter out machines that cannot produce this product (rate = 0)
        valid_machines = [i for i, rate in enumerate(machine_rates) if rate > 0]
        
        if not valid_machines:
            continue  # Skip order if no machine can produce it
            
        # Sort machines by production rate (descending order)
        valid_machines.sort(key=lambda i: machine_rates[i], reverse=True)
        
        # Try each machine in order of best production rate
        for machine_id in valid_machines:
            # Check if appending to the end of this machine's schedule is feasible
            current_schedule = current_solution.production_schedule[machine_id]
            position = len(current_schedule)  # Append to the end
            
            # Create temporary schedule to validate
            temp_schedule = current_schedule + [order_id]
            
            # Validate the new schedule
            if validation_single_production_schedule(machine_id, temp_schedule):
                # Create and return the append operator
                operator = AppendOperator(machine_id, order_id)
                return operator, {}
    
    # If no valid assignment found for any unfulfilled order
    return None, {}