from src.problems.dposp.components import *
import numpy as np
from typing import Optional

def earliest_deadline_first_9053(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[Optional[AppendOperator], dict]:
    """Earliest Deadline First heuristic for DPOSP.
    
    This heuristic selects the unfulfilled order with the earliest deadline and appends it
    to the end of a production line where it can be completed before its deadline. The algorithm
    prioritizes time-critical orders to maximize the number of completed orders.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - current_solution (Solution): Current solution instance with production schedules
            - order_deadline (numpy.array): 1D array of deadlines for each order
            - production_rate (numpy.array): 2D array of production speeds for each product on each production line
            - order_product (numpy.array): 1D array mapping each order to its required product
            - order_quantity (numpy.array): 1D array of quantity required for each order
            - transition_time (numpy.array): 3D array of transition times between products
            - validation_single_production_schedule (callable): Function to validate a production schedule
            - production_line_num (int): Total number of production lines
            - order_num (int): Total number of orders
        algorithm_data (dict): The algorithm dictionary for current algorithm. In this algorithm, the following items are used:
            - processed_orders (set): Set of order IDs that have been processed (optional, created if not exists)
        max_attempts (int, optional): Maximum number of attempts to find a valid placement. Default: 10

    Returns:
        AppendOperator: Operator to append the selected order to a production line, or None if no valid placement found
        dict: Updated algorithm data with processed_orders set

    The algorithm will return None if:
    1. All orders are already processed/fulfilled
    2. No production line can produce the selected order's product
    3. The selected order cannot be completed before its deadline on any production line
    4. Maximum attempts reached without finding a valid placement
    """
    
    # Extract hyper-parameters with default values
    max_attempts = kwargs.get('max_attempts', 10)
    
    # Extract necessary data from problem_state
    current_solution = problem_state['current_solution']
    order_deadline = problem_state['order_deadline']
    production_rate = problem_state['production_rate']
    order_product = problem_state['order_product']
    order_quantity = problem_state['order_quantity']
    transition_time = problem_state['transition_time']
    validation_func = problem_state['validation_single_production_schedule']
    production_line_num = problem_state['production_line_num']
    order_num = problem_state['order_num']
    
    # Initialize algorithm_data if needed
    if 'processed_orders' not in algorithm_data:
        algorithm_data['processed_orders'] = set()
    
    # Find all currently scheduled orders
    scheduled_orders = set()
    for line_schedule in current_solution.production_schedule:
        scheduled_orders.update(line_schedule)
    
    # Find unprocessed orders (not scheduled and not previously processed)
    unprocessed_orders = [order_id for order_id in range(order_num) 
                         if order_id not in scheduled_orders and order_id not in algorithm_data['processed_orders']]
    
    if not unprocessed_orders:
        return None, algorithm_data  # No orders left to process
    
    # Sort unprocessed orders by deadline (earliest first)
    sorted_orders = sorted(unprocessed_orders, key=lambda x: order_deadline[x])
    
    # Try to place each order (starting with earliest deadline) on a production line
    for attempt, order_id in enumerate(sorted_orders[:max_attempts]):
        product_id = order_product[order_id]
        deadline = order_deadline[order_id]
        
        # Find production lines that can produce this product
        valid_lines = []
        for line_id in range(production_line_num):
            if production_rate[line_id, product_id] > 0:  # Line can produce this product
                valid_lines.append(line_id)
        
        if not valid_lines:
            algorithm_data['processed_orders'].add(order_id)  # Mark as processed but unplaceable
            continue
        
        # Try each valid production line
        for line_id in valid_lines:
            # Create a test schedule by appending the order
            test_schedule = current_solution.production_schedule[line_id][:] + [order_id]
            
            # Validate if this schedule is feasible
            if validation_func(line_id, test_schedule):
                # Mark this order as processed and return the append operator
                algorithm_data['processed_orders'].add(order_id)
                return AppendOperator(line_id, order_id), algorithm_data
    
    # If we reach here, no valid placement was found for the attempted orders
    return None, algorithm_data