from src.problems.dposp.components import *
import numpy as np

def shortest_processing_time_0ab1(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[InsertOperator, dict]:
    """ Implements the shortest processing time heuristic for DPOSP.
    
    This heuristic selects the order with the smallest quantity/production_time ratio
    and inserts it at the optimal position that minimizes completion time while
    ensuring feasibility (deadlines met, transitions allowed, machine compatibility).
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - current_solution (Solution): Current solution to be modified
            - production_rate (numpy.array): 2D array of production speeds
            - order_quantity (numpy.array): 1D array of order quantities
            - order_product (numpy.array): 1D array mapping orders to products
            - validation_single_production_schedule (callable): Function to validate a production schedule
            - get_time_cost_delta (callable): Function to calculate time cost delta for insertion
        algorithm_data (dict): Not used in this algorithm, returns empty dict
        kwargs: Hyperparameters with default values:
            - position_search_strategy (str): 'all_positions' or 'end_only' - determines where to search for insertion positions
            - min_processing_time_threshold (float): Minimum processing time ratio threshold (default: 0.0)
    
    Returns:
        InsertOperator: Operator that inserts the best order at the best position, or None if no feasible insertion found
        dict: Empty dictionary as no algorithm data is updated
    """
    
    # Extract hyperparameters with defaults
    position_search_strategy = kwargs.get('position_search_strategy', 'all_positions')
    min_processing_time_threshold = kwargs.get('min_processing_time_threshold', 0.0)
    
    # Extract necessary problem state components
    current_solution = problem_state['current_solution']
    production_rate = problem_state['production_rate']
    order_quantity = problem_state['order_quantity']
    order_product = problem_state['order_product']
    validation_func = problem_state['validation_single_production_schedule']
    get_time_cost_delta = problem_state['get_time_cost_delta']
    
    # Get all orders from the problem
    all_orders = list(range(len(order_quantity)))
    
    # Find already scheduled orders to exclude them
    scheduled_orders = set()
    for line_schedule in current_solution.production_schedule:
        scheduled_orders.update(line_schedule)
    
    # Get unscheduled orders
    unscheduled_orders = [order for order in all_orders if order not in scheduled_orders]
    
    if not unscheduled_orders:
        return None, {}  # No orders to schedule
    
    # Calculate processing time ratios for unscheduled orders
    processing_time_ratios = []
    for order in unscheduled_orders:
        product = order_product[order]
        quantity = order_quantity[order]
        
        # Find the fastest machine for this product
        fastest_time = float('inf')
        for machine_id in range(production_rate.shape[0]):
            if production_rate[machine_id, product] > 0:  # Machine can produce this product
                time_needed = quantity / production_rate[machine_id, product]
                fastest_time = min(fastest_time, time_needed)
        
        if fastest_time < float('inf'):
            processing_time_ratios.append((order, quantity / fastest_time))
    
    if not processing_time_ratios:
        return None, {}  # No feasible orders to schedule
    
    # Sort by processing time ratio (ascending - shortest processing time first)
    processing_time_ratios.sort(key=lambda x: x[1])
    
    # Filter by threshold
    feasible_orders = [order for order, ratio in processing_time_ratios 
                      if ratio >= min_processing_time_threshold]
    
    if not feasible_orders:
        return None, {}  # No orders meet the threshold
    
    # Try each candidate order in order of shortest processing time
    best_operator = None
    best_time_delta = float('inf')
    
    for candidate_order in feasible_orders:
        candidate_product = order_product[candidate_order]
        
        # Try each production line
        for line_id in range(len(current_solution.production_schedule)):
            line_schedule = current_solution.production_schedule[line_id]
            
            # Check if machine can produce this product
            if production_rate[line_id, candidate_product] <= 0:
                continue
            
            # Determine insertion positions to try
            if position_search_strategy == 'end_only':
                positions_to_try = [len(line_schedule)]  # Only try appending
            else:  # 'all_positions'
                positions_to_try = range(len(line_schedule) + 1)  # Try all positions
            
            for position in positions_to_try:
                # Check if insertion is feasible
                test_schedule = line_schedule[:]
                test_schedule.insert(position, candidate_order)
                
                if validation_func(line_id, test_schedule):
                    # Calculate time cost delta for this insertion
                    time_delta = get_time_cost_delta(line_id, candidate_order, position, current_solution)
                    
                    if time_delta is not None and time_delta < best_time_delta:
                        best_time_delta = time_delta
                        best_operator = InsertOperator(line_id, candidate_order, position)
    
    return best_operator, {}