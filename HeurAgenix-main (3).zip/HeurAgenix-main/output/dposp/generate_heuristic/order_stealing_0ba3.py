from src.problems.dposp.components import *
import numpy as np
from typing import Optional

def order_stealing_0ba3(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[Optional[RelocateOperator], dict]:
    """ Order stealing heuristic that relocates orders from overloaded machines to underutilized ones.
    
    This algorithm identifies the most overloaded production line (highest total completion time)
    and tries to relocate orders from it to the least loaded production line. For each order
    on the overloaded machine, it checks if it can be feasibly inserted into the underloaded
    machine without violating deadlines or transition constraints.
    
    Hyper-parameters:
        min_utilization_diff (float, default=0.1): Minimum utilization difference between
            overloaded and underloaded machines to consider stealing (ratio of total time)
        max_attempts_per_order (int, default=5): Maximum number of insertion positions to
            try for each order on the target machine
    
    Returns:
        RelocateOperator: If a feasible order relocation is found that improves balance
        None: If no feasible relocation is found, all machines are balanced, or no solution exists
    
    Algorithm data updates:
        last_stealing_success (bool): Whether the last attempt was successful
        attempts_since_success (int): Count of consecutive failed attempts
    """
    
    # Extract hyper-parameters with defaults
    min_utilization_diff = kwargs.get('min_utilization_diff', 0.1)
    max_attempts_per_order = kwargs.get('max_attempts_per_order', 5)
    
    current_solution = problem_state['current_solution']
    production_line_num = problem_state['production_line_num']
    validation_single_production_schedule = problem_state['validation_single_production_schedule']
    get_time_cost_delta = problem_state['get_time_cost_delta']
    
    # Calculate utilization for each production line
    utilizations = []
    for line_id in range(production_line_num):
        schedule = current_solution.production_schedule[line_id]
        if not schedule:
            utilizations.append(0)
            continue
        
        # Calculate total time for this production line
        total_time = 0
        for pos, order_id in enumerate(schedule):
            # Get production time for this order
            product_id = problem_state['order_product'][order_id]
            quantity = problem_state['order_quantity'][order_id]
            speed = problem_state['production_rate'][line_id, product_id]
            production_time = quantity / speed if speed > 0 else float('inf')
            
            # Get transition time (if not first order)
            if pos > 0:
                prev_order_id = schedule[pos-1]
                prev_product_id = problem_state['order_product'][prev_order_id]
                transition_time = problem_state['transition_time'][line_id, prev_product_id, product_id]
                total_time += transition_time
            
            total_time += production_time
        
        utilizations.append(total_time)
    
    # Check if we have at least 2 non-empty production lines
    non_empty_lines = [i for i, util in enumerate(utilizations) if util > 0]
    if len(non_empty_lines) < 2:
        return None, {'last_stealing_success': False, 'attempts_since_success': algorithm_data.get('attempts_since_success', 0) + 1}
    
    # Find most overloaded and most underloaded production lines
    max_util_idx = np.argmax(utilizations)
    min_util_idx = np.argmin(utilizations)
    
    # Check if utilization difference is significant enough
    max_util = utilizations[max_util_idx]
    min_util = utilizations[min_util_idx]
    
    if max_util <= 0 or (max_util - min_util) / max_util < min_utilization_diff:
        return None, {'last_stealing_success': False, 'attempts_since_success': algorithm_data.get('attempts_since_success', 0) + 1}
    
    # Try to relocate orders from overloaded to underloaded machine
    overloaded_schedule = current_solution.production_schedule[max_util_idx]
    underloaded_schedule = current_solution.production_schedule[min_util_idx]
    
    # Try each order on the overloaded machine
    for source_position, order_id in enumerate(overloaded_schedule):
        product_id = problem_state['order_product'][order_id]
        
        # Check if underloaded machine can produce this product
        if problem_state['production_rate'][min_util_idx, product_id] <= 0:
            continue
        
        # Try different insertion positions on underloaded machine
        target_positions = list(range(len(underloaded_schedule) + 1))
        if len(target_positions) > max_attempts_per_order:
            # Sample positions to try (beginning, middle, end)
            target_positions = [0, len(underloaded_schedule)//2, len(underloaded_schedule)]
        
        for target_position in target_positions:
            # Create test schedule for validation
            test_schedule = underloaded_schedule[:]
            test_schedule.insert(target_position, order_id)
            
            # Validate the new schedule
            if validation_single_production_schedule(min_util_idx, test_schedule):
                # Create and return relocate operator
                operator = RelocateOperator(
                    source_production_line_id=max_util_idx,
                    source_position=source_position,
                    target_production_line_id=min_util_idx,
                    target_position=target_position
                )
                return operator, {'last_stealing_success': True, 'attempts_since_success': 0}
    
    # No feasible relocation found
    return None, {'last_stealing_success': False, 'attempts_since_success': algorithm_data.get('attempts_since_success', 0) + 1}