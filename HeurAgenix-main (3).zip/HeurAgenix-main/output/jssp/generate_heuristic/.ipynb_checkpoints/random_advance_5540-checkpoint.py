import random
from src.problems.jssp.components import Solution, AdvanceOperator

def random_advance_5540(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[AdvanceOperator, dict]:
    """Randomly selects a job that has remaining operations and advances its next operation.
    
    This heuristic randomly chooses a job that hasn't completed all its operations and
    uses the AdvanceOperator to schedule its next operation on the appropriate machine.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - current_solution (Solution): Current solution instance containing job sequences and operation indices
            - job_operation_sequence (list): List of operation sequences for each job
            - job_num (int): Total number of jobs in the problem
        algorithm_data (dict): Not used in this algorithm, maintained for interface consistency
        **kwargs: Hyperparameters (none required for this simple heuristic)
        
    Returns:
        AdvanceOperator: Operator that advances the next operation of a randomly selected job
        dict: Empty dictionary as no algorithm data is updated
        
    Notes:
        - Returns None if no jobs have remaining operations to advance
        - Ensures job selection is valid (job exists and has operations remaining)
        - Maintains the sequential execution constraint of JSSP operations
    """
    
    current_solution = problem_state['current_solution']
    job_operation_sequence = problem_state['job_operation_sequence']
    job_num = problem_state['job_num']
    
    # Find all jobs that have remaining operations to process
    available_jobs = []
    for job_id in range(job_num):
        current_op_index = current_solution.job_operation_index[job_id]
        # Check if job has more operations to process
        if current_op_index < len(job_operation_sequence[job_id]):
            available_jobs.append(job_id)
    
    # If no jobs have remaining operations, return None
    if not available_jobs:
        return None, {}
    
    # Randomly select a job from available candidates
    selected_job = random.choice(available_jobs)
    
    # Create and return the AdvanceOperator for the selected job
    return AdvanceOperator(selected_job), {}