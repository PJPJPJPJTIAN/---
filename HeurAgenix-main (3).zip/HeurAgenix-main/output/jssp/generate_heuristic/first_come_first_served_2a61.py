from src.problems.jssp.components import *
import numpy as np
from typing import Optional

def first_come_first_served_2a61(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[Optional[AdvanceOperator], dict]:
    """First-Come-First-Served heuristic for JSSP.
    
    This heuristic processes jobs in the order they become available for their next operation.
    It selects the job that has been waiting the longest (earliest job ID) among those with
    remaining operations that can be scheduled.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - current_solution (Solution): Current solution instance containing job sequences and operation indices
            - job_operation_sequence (numpy.ndarray): Sequence of operations for each job
            - job_num (int): Total number of jobs
        algorithm_data (dict): Not used in this algorithm, maintained for interface compatibility
        **kwargs: No hyper-parameters required for this basic heuristic

    Returns:
        AdvanceOperator: Operator that advances the next operation of the selected job (earliest job ID with remaining operations)
        dict: Empty dictionary as no algorithm data is updated
        
        Returns (None, {}) if no jobs have remaining operations to schedule
    """
    
    current_solution = problem_state['current_solution']
    job_operation_sequence = problem_state['job_operation_sequence']
    num_jobs = problem_state['job_num']
    
    # Find all jobs that have remaining operations to schedule
    available_jobs = []
    for job_id in range(num_jobs):
        current_op_index = current_solution.job_operation_index[job_id]
        # Check if job has remaining operations
        if current_op_index < len(job_operation_sequence[job_id]):
            available_jobs.append(job_id)
    
    # If no jobs have remaining operations, return None
    if not available_jobs:
        return None, {}
    
    # Select the job with the smallest ID (first-come-first-served)
    selected_job = min(available_jobs)
    
    # Return AdvanceOperator for the selected job
    return AdvanceOperator(selected_job), {}