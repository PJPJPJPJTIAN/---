from src.problems.jssp.components import *
import numpy as np
from typing import Tuple, Optional

def first_come_first_served_c13f(problem_state: dict, algorithm_data: dict, **kwargs) -> Tuple[Optional[AdvanceOperator], dict]:
    """First-Come-First-Served heuristic for JSSP.
    
    This heuristic selects the job that has been waiting the longest (has the most advanced
    operations completed) and advances its next operation. The "waiting time" is measured
    by how many operations have already been scheduled for each job.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - current_solution (Solution): Current solution instance containing job_operation_index
            - job_num (int): Total number of jobs
            - validation_solution (callable): Function to validate if a solution is valid
        algorithm_data (dict): Not used in this algorithm, maintained for interface compatibility
        **kwargs: No hyper-parameters required for this basic heuristic

    Returns:
        AdvanceOperator: Operator that advances the next operation of the job with the most
                        completed operations (longest waiting time), or None if no valid job
                        can be advanced (all jobs completed or solution invalid)
        dict: Empty dictionary as no algorithm data is updated

    Note:
        - Returns None if current solution is invalid
        - Returns None if all jobs have completed all operations
        - Returns None if no jobs have any operations left to schedule
        - In case of ties (multiple jobs with same number of completed operations),
          selects the job with the smallest ID
    """
    
    # Validate current solution
    if not problem_state['validation_solution'](problem_state['current_solution']):
        return None, {}
    
    current_solution = problem_state['current_solution']
    job_num = problem_state['job_num']
    
    # Find jobs that still have operations to complete
    available_jobs = []
    for job_id in range(job_num):
        # Check if job has remaining operations
        if current_solution.job_operation_index[job_id] < len(current_solution.job_operation_sequence[job_id]):
            available_jobs.append(job_id)
    
    # If no jobs have operations left to schedule, return None
    if not available_jobs:
        return None, {}
    
    # Find the job with the most completed operations (longest waiting time)
    # In case of ties, select the job with smallest ID
    selected_job = min(available_jobs, 
                      key=lambda job_id: (-current_solution.job_operation_index[job_id], job_id))
    
    # Create and return the AdvanceOperator for the selected job
    return AdvanceOperator(selected_job), {}