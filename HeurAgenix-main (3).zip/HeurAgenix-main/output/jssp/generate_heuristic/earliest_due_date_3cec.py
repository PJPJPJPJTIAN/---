from src.problems.jssp.components import *
import numpy as np
from typing import Optional
import random

def earliest_due_date_3cec(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[Optional[AdvanceOperator], dict]:
    """Earliest Due Date heuristic for JSSP that prioritizes jobs with the earliest due dates.
    
    This heuristic requires due date information for each job. It identifies available jobs
    (jobs that haven't completed all operations) and selects the one with the earliest due date
    for advancement to the next operation.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - job_operation_sequence (numpy.ndarray): Operation sequence for each job
            - current_solution (Solution): Current solution with job sequences and operation indices
            - num_jobs (int): Total number of jobs
        algorithm_data (dict): The algorithm dictionary for current algorithm. In this algorithm, the following items are necessary:
            - job_due_dates (list[float]): Due dates for each job (required)
        due_date_offset (float, optional): Offset to add to processing time if due dates not provided. Default: 2.0
        use_remaining_processing (bool, optional): Whether to use remaining processing time for due date calculation. Default: False
        fallback_to_random (bool, optional): Whether to fall back to random selection if due dates unavailable. Default: True
        
    Returns:
        AdvanceOperator: Operator to advance the job with earliest due date, or None if no jobs available
        dict: Updated algorithm data (empty in this implementation)
        
    Notes:
        - Returns None if all jobs have completed all operations
        - If due dates are not provided, falls back to random selection if fallback_to_random is True
        - The heuristic ensures only jobs with remaining operations are considered
    """
    
    # Extract hyperparameters with defaults
    due_date_offset = kwargs.get('due_date_offset', 2.0)
    use_remaining_processing = kwargs.get('use_remaining_processing', False)
    fallback_to_random = kwargs.get('fallback_to_random', True)
    
    # Extract necessary problem state
    job_operation_sequence = problem_state['job_operation_sequence']
    current_solution = problem_state['current_solution']
    num_jobs = problem_state['num_jobs']
    job_operation_time = problem_state.get('job_operation_time')
    
    # Find available jobs (jobs that haven't completed all operations)
    available_jobs = []
    for job_id in range(num_jobs):
        current_op_index = current_solution.job_operation_index[job_id]
        if current_op_index < len(job_operation_sequence[job_id]):
            available_jobs.append(job_id)
    
    # Return None if no jobs available for advancement
    if not available_jobs:
        return None, {}
    
    # Get due dates from algorithm_data or calculate them
    if 'job_due_dates' in algorithm_data:
        due_dates = algorithm_data['job_due_dates']
        if len(due_dates) != num_jobs:
            # Invalid due date data, fall back to random if enabled
            if fallback_to_random:
                selected_job = random.choice(available_jobs)
                return AdvanceOperator(selected_job), {}
            return None, {}
    else:
        # Calculate due dates based on processing time if not provided
        if job_operation_time is None:
            # Cannot calculate due dates, fall back to random if enabled
            if fallback_to_random:
                selected_job = random.choice(available_jobs)
                return AdvanceOperator(selected_job), {}
            return None, {}
        
        due_dates = []
        for job_id in range(num_jobs):
            total_time = np.sum(job_operation_time[job_id])
            due_dates.append(total_time * due_date_offset)
    
    # Find job with earliest due date among available jobs
    earliest_due_date = float('inf')
    selected_job = None
    
    for job_id in available_jobs:
        if due_dates[job_id] < earliest_due_date:
            earliest_due_date = due_dates[job_id]
            selected_job = job_id
    
    # Return AdvanceOperator for the selected job
    return AdvanceOperator(selected_job), {}