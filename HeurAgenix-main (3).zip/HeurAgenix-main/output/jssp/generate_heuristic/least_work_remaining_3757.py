from src.problems.jssp.components import *
import numpy as np

def least_work_remaining_3757(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[AdvanceOperator, dict]:
    """Implements the Least Work Remaining (LWR) heuristic for JSSP.
    
    This heuristic selects the job with the lowest total remaining processing time
    (sum of processing times for all uncompleted operations) and advances its next
    operation to the corresponding machine queue.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - job_operation_sequence (numpy.ndarray): Sequence of operations for each job
            - job_operation_time (numpy.ndarray): Processing time for each operation
            - current_solution (Solution): Current solution instance containing job_operation_index
            - num_jobs (int): Total number of jobs
        algorithm_data (dict): Not used in this algorithm, maintained for interface consistency
        **kwargs: Hyperparameters (none required for this basic heuristic)
        
    Returns:
        AdvanceOperator: Operator that advances the next operation of the job with least work remaining
        dict: Empty dictionary as no algorithm data is updated
        
    Notes:
        - Returns None if all jobs have been fully scheduled (all operations completed)
        - Only considers jobs that still have remaining operations to schedule
        - If multiple jobs have the same minimum remaining work, selects the first one found
        - Ensures solution validity by only advancing jobs that have uncompleted operations
    """
    
    # Extract necessary data from problem_state
    job_operation_sequence = problem_state['job_operation_sequence']
    job_operation_time = problem_state['job_operation_time']
    current_solution = problem_state['current_solution']
    num_jobs = problem_state['num_jobs']
    
    # Get current operation indices for all jobs
    current_op_indices = current_solution.job_operation_index
    
    # Calculate remaining work for each job
    remaining_work = []
    valid_jobs = []  # Jobs that still have operations to schedule
    
    for job_id in range(num_jobs):
        current_op_index = current_op_indices[job_id]
        
        # Check if job has remaining operations
        if current_op_index < len(job_operation_sequence[job_id]):
            # Calculate sum of processing times for remaining operations
            remaining_ops = job_operation_sequence[job_id][current_op_index:]
            remaining_time = sum(job_operation_time[job_id][op_idx] for op_idx in remaining_ops)
            remaining_work.append(remaining_time)
            valid_jobs.append(job_id)
    
    # If no jobs have remaining operations, return None
    if not valid_jobs:
        return None, {}
    
    # Find job with minimum remaining work
    min_remaining_work = min(remaining_work)
    min_index = remaining_work.index(min_remaining_work)
    selected_job = valid_jobs[min_index]
    
    # Create and return AdvanceOperator for the selected job
    return AdvanceOperator(selected_job), {}