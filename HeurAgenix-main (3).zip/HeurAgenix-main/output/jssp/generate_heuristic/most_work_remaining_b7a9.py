import numpy as np
from src.problems.jssp.components import Solution, AdvanceOperator

def most_work_remaining_b7a9(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[AdvanceOperator, dict]:
    """Most Work Remaining (MWKR) heuristic for JSSP.
    
    This heuristic selects the job with the highest total remaining processing time
    and advances its next operation. The remaining work for a job is calculated as
    the sum of processing times for all operations that haven't been scheduled yet.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - job_operation_sequence (numpy.ndarray): A list of jobs where each job is a list of operations in target sequence
            - job_operation_time (numpy.ndarray): The time cost for each operation in target job
            - current_solution (Solution): Current solution instance containing job_operation_index
            - num_jobs (int): Total number of jobs
        algorithm_data (dict): Not used in this algorithm, maintained for interface consistency
        **kwargs: No hyperparameters required for this basic heuristic

    Returns:
        AdvanceOperator: Operator that advances the next operation of the job with maximum remaining work
        dict: Empty dictionary as no algorithm data is updated
        
    Notes:
        - Returns None if all jobs have been fully scheduled (no operations left to advance)
        - Only considers jobs that have remaining operations to schedule
        - If multiple jobs have the same maximum remaining work, selects the first one encountered
        - Ensures solution validity by only advancing jobs that have pending operations
    """
    
    # Extract necessary data from problem_state
    job_operation_sequence = problem_state['job_operation_sequence']
    job_operation_time = problem_state['job_operation_time']
    current_solution = problem_state['current_solution']
    num_jobs = problem_state['num_jobs']
    
    # Calculate remaining work for each job
    remaining_work = []
    valid_jobs = []  # Jobs that have operations left to schedule
    
    for job_id in range(num_jobs):
        current_op_index = current_solution.job_operation_index[job_id]
        
        # Check if job has remaining operations
        if current_op_index < len(job_operation_sequence[job_id]):
            # Sum processing times of remaining operations
            remaining_ops = job_operation_sequence[job_id][current_op_index:]
            remaining_time = sum(job_operation_time[job_id][op_idx] for op_idx in remaining_ops)
            remaining_work.append(remaining_time)
            valid_jobs.append(job_id)
    
    # If no jobs have remaining operations, return None
    if not valid_jobs:
        return None, {}
    
    # Find job with maximum remaining work
    max_remaining_work = max(remaining_work)
    max_index = remaining_work.index(max_remaining_work)
    selected_job = valid_jobs[max_index]
    
    # Return AdvanceOperator for the selected job
    return AdvanceOperator(selected_job), {}