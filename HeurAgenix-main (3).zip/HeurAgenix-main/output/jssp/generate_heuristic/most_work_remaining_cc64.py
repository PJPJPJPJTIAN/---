from src.problems.jssp.components import *
import numpy as np

def most_work_remaining_cc64(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[AdvanceOperator, dict]:
    """Implements the Most Work Remaining (MWR) heuristic for JSSP.
    
    This heuristic prioritizes jobs with the highest total remaining processing time.
    It calculates the remaining work for each job that has unfinished operations and
    selects the job with the maximum remaining work to advance to its next operation.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - job_operation_sequence (numpy.ndarray): A list of jobs where each job is a list of operations in target sequence
            - job_operation_time (numpy.ndarray): The time cost for each operation in target job
            - current_solution (Solution): Current solution instance containing job_operation_index
            - job_num (int): Total number of jobs for iteration
            - validation_solution (callable): Function to validate if a solution is valid
        algorithm_data (dict): Not used in this algorithm, maintained for interface compatibility
        **kwargs: Hyperparameters (none required for this basic heuristic)
        
    Returns:
        AdvanceOperator: Operator that advances the job with maximum remaining work, or None if no valid job can be advanced
        dict: Empty dictionary as no algorithm data is updated
        
    Notes:
        - Only considers jobs that have remaining operations (job_operation_index < len(operation_sequence))
        - Returns None if all jobs are completed or if no valid job can be selected
        - The heuristic ensures operations are executed in sequence by using AdvanceOperator
        - Validates the resulting solution to ensure feasibility
    """
    
    # Extract necessary data from problem_state
    job_operation_sequence = problem_state['job_operation_sequence']
    job_operation_time = problem_state['job_operation_time']
    current_solution = problem_state['current_solution']
    job_num = problem_state['job_num']
    validation_solution = problem_state['validation_solution']
    
    # Calculate remaining work for each job
    remaining_work = []
    valid_jobs = []
    
    for job_id in range(job_num):
        current_op_index = current_solution.job_operation_index[job_id]
        
        # Check if job has remaining operations
        if current_op_index < len(job_operation_sequence[job_id]):
            # Calculate total remaining processing time
            remaining_ops = job_operation_time[job_id][current_op_index:]
            total_remaining = np.sum(remaining_ops)
            remaining_work.append(total_remaining)
            valid_jobs.append(job_id)
    
    # If no jobs have remaining operations, return None
    if not valid_jobs:
        return None, {}
    
    # Find job with maximum remaining work
    max_remaining_index = np.argmax(remaining_work)
    selected_job = valid_jobs[max_remaining_index]
    
    # Create advance operator for the selected job
    operator = AdvanceOperator(selected_job)
    
    # Validate that this operation doesn't create an invalid solution
    # (e.g., trying to advance a job that's already completed)
    try:
        new_solution = operator.run(current_solution)
        if validation_solution(new_solution):
            return operator, {}
        else:
            return None, {}
    except (IndexError, ValueError):
        # Handle cases where the operation might be invalid
        return None, {}