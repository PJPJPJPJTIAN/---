from src.problems.jssp.components import *
import numpy as np

def shortest_processing_time_8737(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[AdvanceOperator, dict]:
    """Shortest Processing Time (SPT) heuristic for JSSP.
    
    This heuristic selects the job with the shortest processing time for its next operation
    from all jobs that have remaining operations to be scheduled. The algorithm identifies
    available jobs (those not yet fully scheduled) and chooses the one with the minimum
    processing time for its next operation.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - job_operation_sequence (numpy.ndarray): A list of jobs where each job is a list of operations in target sequence
            - job_operation_time (numpy.ndarray): The time cost for each operation in target job
            - current_solution (Solution): Current solution instance containing job_operation_index
            - num_jobs (int): Total number of jobs
        algorithm_data (dict): Not used in this algorithm, maintained for interface compatibility
        **kwargs: No hyperparameters required for this basic heuristic
    
    Returns:
        AdvanceOperator: An operator that advances the selected job with shortest processing time
        dict: Empty dictionary as no algorithm data is updated
        
    Notes:
        - Returns None if all jobs are already fully scheduled (no operations remaining)
        - Only considers jobs that have remaining operations to be advanced
        - Processing time is retrieved from job_operation_time based on current operation index
    """
    
    # Extract necessary data from problem_state
    job_operation_sequence = problem_state['job_operation_sequence']
    job_operation_time = problem_state['job_operation_time']
    current_solution = problem_state['current_solution']
    num_jobs = problem_state['num_jobs']
    
    # Find available jobs (jobs that have remaining operations)
    available_jobs = []
    processing_times = []
    
    for job_id in range(num_jobs):
        current_op_index = current_solution.job_operation_index[job_id]
        
        # Check if job has remaining operations
        if current_op_index < len(job_operation_sequence[job_id]):
            # Get the processing time for the next operation
            next_op_machine = job_operation_sequence[job_id][current_op_index]
            processing_time = job_operation_time[job_id][current_op_index]
            
            available_jobs.append(job_id)
            processing_times.append(processing_time)
    
    # If no available jobs, return None
    if not available_jobs:
        return None, {}
    
    # Find the job with minimum processing time for its next operation
    min_time_index = np.argmin(processing_times)
    selected_job = available_jobs[min_time_index]
    
    # Create and return AdvanceOperator for the selected job
    return AdvanceOperator(selected_job), {}