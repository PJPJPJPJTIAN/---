from src.problems.jssp.components import *
import numpy as np

def fewest_operations_remaining_cade(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[AdvanceOperator, dict]:
    """Implements the Fewest Operations Remaining (FOR) heuristic for JSSP.
    
    This heuristic selects the job with the fewest remaining operations to complete.
    The rationale is that jobs closer to completion should be prioritized to free up
    resources and reduce work-in-process inventory. If multiple jobs have the same
    minimum number of remaining operations, one is selected randomly.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - job_operation_sequence (numpy.ndarray): A list of jobs where each job is a list of operations in target sequence
            - current_solution (Solution): Current solution instance containing job_operation_index
            - job_num (int): Total number of jobs in the problem
            - validation_solution (callable): Function to check solution validity
        algorithm_data (dict): Not used in this algorithm, maintained for interface consistency
        **kwargs: Hyperparameters (none required for this basic heuristic)
    
    Returns:
        AdvanceOperator: Operator to advance the selected job with fewest remaining operations
        dict: Empty dictionary as no algorithm data is updated
        
    Notes:
        - Returns None if no jobs have remaining operations to advance
        - Ensures solution validity by only considering jobs that haven't completed all operations
        - Random selection among ties prevents bias toward specific job IDs
    """
    
    # Extract necessary data from problem_state
    job_operation_sequence = problem_state['job_operation_sequence']
    current_solution = problem_state['current_solution']
    job_num = problem_state['job_num']
    validation_solution = problem_state['validation_solution']
    
    # Calculate remaining operations for each job
    remaining_ops = []
    valid_jobs = []
    
    for job_id in range(job_num):
        current_op_index = current_solution.job_operation_index[job_id]
        total_ops = len(job_operation_sequence[job_id])
        
        # Check if job has remaining operations
        if current_op_index < total_ops:
            remaining_ops_count = total_ops - current_op_index
            remaining_ops.append(remaining_ops_count)
            valid_jobs.append(job_id)
    
    # If no jobs have remaining operations, return None
    if not valid_jobs:
        return None, {}
    
    # Find minimum remaining operations
    min_remaining = min(remaining_ops)
    
    # Find all jobs with minimum remaining operations
    candidate_jobs = [valid_jobs[i] for i, count in enumerate(remaining_ops) if count == min_remaining]
    
    # Randomly select one job from candidates (prevents bias toward lower job IDs)
    selected_job = np.random.choice(candidate_jobs)
    
    # Create and return AdvanceOperator for the selected job
    return AdvanceOperator(selected_job), {}