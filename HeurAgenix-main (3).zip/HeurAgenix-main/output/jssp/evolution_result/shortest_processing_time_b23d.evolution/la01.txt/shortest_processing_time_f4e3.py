from src.problems.jssp.components import *
import numpy as np

def shortest_processing_time_f4e3(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[AdvanceOperator, dict]:
    """Enhanced Shortest Processing Time heuristic with machine workload balancing for JSSP.
    
    This heuristic extends the basic SPT rule by incorporating machine workload considerations.
    It selects jobs based on a weighted priority score that balances both processing time
    and current machine utilization to prevent bottlenecks and improve load distribution.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - job_operation_sequence (numpy.ndarray): A list of jobs where each job is a list of operations in target sequence
            - job_operation_time (numpy.ndarray): The time cost for each operation in target job
            - current_solution (Solution): Current solution instance containing job_operation_index and job_sequences
            - num_jobs (int): Total number of jobs
            - num_machines (int): Total number of machines
        algorithm_data (dict): The algorithm dictionary for current algorithm only. In this algorithm, no specific data is required.
        **kwargs: Hyper-parameters for the algorithm:
            - alpha (float, default=0.4): Weight factor for machine workload balancing (range 0.3-0.5 recommended)
    
    Returns:
        AdvanceOperator: An operator that advances the job with the best priority score,
                         or None if no jobs have remaining operations to schedule.
        dict: Empty dictionary as no algorithm data needs to be updated.

    Notes:
        - Priority score = processing_time - alpha * (machine_workload / max_machine_workload)
        - Lower scores are better (favors shorter operations on less utilized machines)
        - If multiple jobs have the same best score, selects the one with smallest job ID
        - Returns None if all jobs have been fully scheduled
    """
    
    # Extract necessary data from problem_state
    job_operation_sequence = problem_state['job_operation_sequence']
    job_operation_time = problem_state['job_operation_time']
    current_solution = problem_state['current_solution']
    num_jobs = problem_state['num_jobs']
    num_machines = problem_state['num_machines']
    
    # Set default hyper-parameters
    alpha = kwargs.get('alpha', 0.4)
    
    # Calculate current machine workloads (sum of processing times for scheduled operations)
    machine_workloads = [0] * num_machines
    for machine_id in range(num_machines):
        for job_id in current_solution.job_sequences[machine_id]:
            # Find the operation index for this job on this machine
            job_ops = job_operation_sequence[job_id]
            op_index = None
            for i, op_machine in enumerate(job_ops):
                if op_machine == machine_id:
                    op_index = i
                    break
            if op_index is not None:
                machine_workloads[machine_id] += job_operation_time[job_id][op_index]
    
    max_machine_workload = max(machine_workloads) if machine_workloads else 1
    
    # Find jobs with remaining operations and calculate priority scores
    available_jobs = []
    priority_scores = []
    
    for job_id in range(num_jobs):
        current_op_index = current_solution.job_operation_index[job_id]
        
        # Check if job has remaining operations
        if current_op_index < len(job_operation_sequence[job_id]):
            # Get the processing time and target machine for the next operation
            next_machine = job_operation_sequence[job_id][current_op_index]
            processing_time = job_operation_time[job_id][current_op_index]
            
            # Calculate priority score: lower is better
            machine_utilization = machine_workloads[next_machine] / max_machine_workload if max_machine_workload > 0 else 0
            priority_score = processing_time - alpha * machine_utilization
            
            available_jobs.append(job_id)
            priority_scores.append(priority_score)
    
    # If no jobs have remaining operations, return None
    if not available_jobs:
        return None, {}
    
    # Find the job with the best (lowest) priority score
    min_score = min(priority_scores)
    candidate_jobs = [job_id for job_id, score in zip(available_jobs, priority_scores) 
                     if score == min_score]
    
    # Select the job with smallest ID among candidates
    selected_job = min(candidate_jobs)
    
    # Return the AdvanceOperator for the selected job
    return AdvanceOperator(selected_job), {}