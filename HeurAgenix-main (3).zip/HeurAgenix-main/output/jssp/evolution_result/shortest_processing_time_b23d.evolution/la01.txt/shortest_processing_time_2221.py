from src.problems.jssp.components import *
import numpy as np

def shortest_processing_time_2221(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[AdvanceOperator, dict]:
    """Enhanced Shortest Processing Time heuristic with machine workload balancing for JSSP.
    
    This heuristic extends the basic SPT rule by incorporating machine workload considerations.
    It selects the job with the best combination of short processing time and favorable machine
    loading conditions using a weighted priority score formula.
    
    Hyper-parameters:
        alpha (float, default=0.4): Weighting factor for machine workload consideration. 
                                   Higher values give more importance to machine balancing.
        beta (float, default=0.0): Weighting factor for job remaining workload consideration.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - job_operation_sequence (numpy.ndarray): A list of jobs where each job is a list of operations in target sequence
            - job_operation_time (numpy.ndarray): The time cost for each operation in target job
            - current_solution (Solution): Current solution instance containing job_operation_index and job_sequences
            - num_jobs (int): Total number of jobs
            - num_machines (int): Total number of machines
        algorithm_data (dict): The algorithm dictionary for current algorithm only. In this algorithm, no specific data is required.
        **kwargs: Hyper-parameters for the algorithm:
            - alpha (float): Weight for machine workload balancing (default: 0.4)
            - beta (float): Weight for job remaining workload (default: 0.0)

    Returns:
        AdvanceOperator: An operator that advances the job with the best priority score,
                         or None if no jobs have remaining operations to schedule.
        dict: Empty dictionary as no algorithm data needs to be updated.

    Notes:
        - Priority score = processing_time * (1 + alpha * (machine_current_workload / max_machine_workload))
        - Only considers jobs that have remaining operations to schedule
        - Returns None if all jobs have been fully scheduled (no remaining operations)
        - If multiple jobs have the same best score, selects the one with the smallest job ID
    """
    
    # Extract necessary data from problem_state
    job_operation_sequence = problem_state['job_operation_sequence']
    job_operation_time = problem_state['job_operation_time']
    current_solution = problem_state['current_solution']
    num_jobs = problem_state['num_jobs']
    num_machines = problem_state['num_machines']
    
    # Set hyper-parameters with defaults
    alpha = kwargs.get('alpha', 0.4)
    beta = kwargs.get('beta', 0.0)
    
    # Calculate current machine workloads
    machine_workloads = [0] * num_machines
    for machine_id in range(num_machines):
        for job_id in current_solution.job_sequences[machine_id]:
            # Find the operation index for this job on this machine
            job_ops = job_operation_sequence[job_id]
            op_index = list(job_ops).index(machine_id)
            machine_workloads[machine_id] += job_operation_time[job_id][op_index]
    
    max_machine_workload = max(machine_workloads) if machine_workloads else 0
    
    # Find jobs with remaining operations and calculate their priority scores
    available_jobs = []
    priority_scores = []
    
    for job_id in range(num_jobs):
        current_op_index = current_solution.job_operation_index[job_id]
        
        # Check if job has remaining operations
        if current_op_index < len(job_operation_sequence[job_id]):
            # Get the processing time and target machine for the next operation
            next_machine = job_operation_sequence[job_id][current_op_index]
            processing_time = job_operation_time[job_id][current_op_index]
            
            # Calculate machine workload factor (normalized)
            machine_load_factor = machine_workloads[next_machine] / max_machine_workload if max_machine_workload > 0 else 0
            
            # Calculate priority score
            priority_score = processing_time * (1 + alpha * machine_load_factor)
            
            available_jobs.append(job_id)
            priority_scores.append(priority_score)
    
    # If no jobs have remaining operations, return None
    if not available_jobs:
        return None, {}
    
    # Find the job with the best (lowest) priority score
    min_score = min(priority_scores)
    candidate_jobs = [job_id for job_id, score in zip(available_jobs, priority_scores) 
                     if abs(score - min_score) < 1e-6]  # Handle floating point precision
    
    # Select the job with smallest ID among candidates
    selected_job = min(candidate_jobs)
    
    # Return the AdvanceOperator for the selected job
    return AdvanceOperator(selected_job), {}