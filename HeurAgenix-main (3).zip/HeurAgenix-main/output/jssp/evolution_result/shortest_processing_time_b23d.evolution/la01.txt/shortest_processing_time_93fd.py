from src.problems.jssp.components import *
import numpy as np

def shortest_processing_time_93fd(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[AdvanceOperator, dict]:
    """Enhanced Shortest Processing Time heuristic with machine workload balancing for JSSP.
    
    This heuristic selects jobs based on a weighted combination of shortest processing time
    and machine workload balance. It considers both the immediate processing time of the
    next operation and the remaining workload on the target machine to prevent bottlenecks.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - job_operation_sequence (numpy.ndarray): A list of jobs where each job is a list of operations in target sequence
            - job_operation_time (numpy.ndarray): The time cost for each operation in target job
            - current_solution (Solution): Current solution instance containing job_operation_index and job_sequences
            - num_jobs (int): Total number of jobs
            - num_machines (int): Total number of machines
        algorithm_data (dict): The algorithm dictionary for current algorithm only. In this algorithm, no specific data is required.
        **kwargs: Hyper-parameters for the algorithm:
            - processing_time_weight (float, default=0.7): Weight for processing time component in scoring
            - workload_balance_weight (float, default=0.3): Weight for machine workload balance component in scoring
    
    Returns:
        AdvanceOperator: An operator that advances the job with the best combined score of 
                         short processing time and good machine workload balance,
                         or None if no jobs have remaining operations to schedule.
        dict: Empty dictionary as no algorithm data needs to be updated.

    Notes:
        - Only considers jobs that have remaining operations to schedule
        - Calculates remaining workload for each machine based on unscheduled operations
        - Uses normalized scoring to balance processing time and machine workload
        - Returns None if all jobs have been fully scheduled (no remaining operations)
    """
    
    # Extract necessary data from problem_state
    job_operation_sequence = problem_state['job_operation_sequence']
    job_operation_time = problem_state['job_operation_time']
    current_solution = problem_state['current_solution']
    num_jobs = problem_state['num_jobs']
    num_machines = problem_state['num_machines']
    
    # Set default hyper-parameters
    processing_time_weight = kwargs.get('processing_time_weight', 0.7)
    workload_balance_weight = kwargs.get('workload_balance_weight', 0.3)
    
    # Validate weights sum to 1.0
    total_weight = processing_time_weight + workload_balance_weight
    if abs(total_weight - 1.0) > 1e-6:
        processing_time_weight = 0.7
        workload_balance_weight = 0.3
    
    # Find jobs with remaining operations and collect processing times
    available_jobs = []
    processing_times = []
    target_machines = []
    
    for job_id in range(num_jobs):
        current_op_index = current_solution.job_operation_index[job_id]
        
        # Check if job has remaining operations
        if current_op_index < len(job_operation_sequence[job_id]):
            # Get the processing time and target machine for the next operation
            next_machine = job_operation_sequence[job_id][current_op_index]
            processing_time = job_operation_time[job_id][current_op_index]
            
            available_jobs.append(job_id)
            processing_times.append(processing_time)
            target_machines.append(next_machine)
    
    # If no jobs have remaining operations, return None
    if not available_jobs:
        return None, {}
    
    # Calculate remaining workload for each machine
    machine_remaining_workload = [0] * num_machines
    
    for job_id in range(num_jobs):
        current_op_index = current_solution.job_operation_index[job_id]
        
        # Add processing times for all remaining operations of this job
        for op_idx in range(current_op_index, len(job_operation_sequence[job_id])):
            machine_id = job_operation_sequence[job_id][op_idx]
            processing_time = job_operation_time[job_id][op_idx]
            machine_remaining_workload[machine_id] += processing_time
    
    # Normalize processing times and machine workloads for scoring
    if processing_times:
        max_processing_time = max(processing_times)
        min_processing_time = min(processing_times)
        processing_range = max_processing_time - min_processing_time if max_processing_time > min_processing_time else 1.0
    else:
        processing_range = 1.0
    
    if machine_remaining_workload:
        max_machine_workload = max(machine_remaining_workload)
        min_machine_workload = min(machine_remaining_workload)
        workload_range = max_machine_workload - min_machine_workload if max_machine_workload > min_machine_workload else 1.0
    else:
        workload_range = 1.0
    
    # Calculate scores for each available job
    scores = []
    for i, job_id in enumerate(available_jobs):
        # Normalized processing time component (lower is better)
        norm_processing_time = (processing_times[i] - min_processing_time) / processing_range
        
        # Normalized machine workload component (lower is better)
        target_machine = target_machines[i]
        norm_machine_workload = (machine_remaining_workload[target_machine] - min_machine_workload) / workload_range
        
        # Combined score
        score = (norm_processing_time * processing_time_weight + 
                norm_machine_workload * workload_balance_weight)
        
        scores.append(score)
    
    # Find the job with the lowest score
    min_score = min(scores)
    candidate_indices = [i for i, score in enumerate(scores) if abs(score - min_score) < 1e-6]
    
    # If multiple jobs have the same score, select the one with smallest job ID
    selected_index = min(candidate_indices)
    selected_job = available_jobs[selected_index]
    
    # Return the AdvanceOperator for the selected job
    return AdvanceOperator(selected_job), {}