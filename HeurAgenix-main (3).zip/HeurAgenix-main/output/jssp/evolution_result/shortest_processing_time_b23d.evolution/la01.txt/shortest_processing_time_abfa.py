from src.problems.jssp.components import *
import numpy as np

def shortest_processing_time_abfa(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[AdvanceOperator, dict]:
    """Enhanced Shortest Processing Time heuristic with adaptive machine workload balancing and look-ahead for JSSP.
    
    This heuristic extends the basic SPT rule with dynamic weighting that adapts to problem characteristics
    and incorporates both current machine utilization and future job workload considerations for better global optimization.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - job_operation_sequence (numpy.ndarray): A list of jobs where each job is a list of operations in target sequence
            - job_operation_time (numpy.ndarray): The time cost for each operation in target job
            - current_solution (Solution): Current solution instance containing job_operation_index and job_sequences
            - num_jobs (int): Total number of jobs
            - num_machines (int): Total number of machines
            - processing_time_cv (float): Coefficient of variation of all processing times
        algorithm_data (dict): The algorithm dictionary for current algorithm only. In this algorithm, no specific data is required.
        **kwargs: Hyper-parameters for the algorithm:
            - alpha_base (float, default=0.3): Base weight factor for machine workload balancing
            - beta (float, default=0.2): Scaling factor for processing time variability adaptation
            - gamma (float, default=0.1): Weight factor for remaining job workload consideration
    
    Returns:
        AdvanceOperator: An operator that advances the job with the best priority score,
                         or None if no jobs have remaining operations to schedule.
        dict: Empty dictionary as no algorithm data needs to be updated.

    Notes:
        - Priority score = processing_time - (alpha_base + beta * processing_time_cv) * (machine_workload / max_machine_workload) + gamma * (remaining_job_workload / max_remaining_workload)
        - Lower scores are better (favors shorter operations on less utilized machines with lighter future workload)
        - If multiple jobs have the same best score, selects the one with smallest job ID
        - Returns None if all jobs have been fully scheduled
    """
    
    # Extract necessary data from problem_state
    job_operation_sequence = problem_state['job_operation_sequence']
    job_operation_time = problem_state['job_operation_time']
    current_solution = problem_state['current_solution']
    num_jobs = problem_state['num_jobs']
    num_machines = problem_state['num_machines']
    processing_time_cv = problem_state['processing_time_cv']
    
    # Set default hyper-parameters
    alpha_base = kwargs.get('alpha_base', 0.3)
    beta = kwargs.get('beta', 0.2)
    gamma = kwargs.get('gamma', 0.1)
    
    # Calculate current machine workloads (sum of processing times for scheduled operations)
    machine_workloads = [0] * num_machines
    for machine_id in range(num_machines):
        for job_id in current_solution.job_sequences[machine_id]:
            # Find the operation index for this job on this machine
            job_ops = job_operation_sequence[job_id]
            op_index = None
            for i, op_machine in enumerate(job_ops):
                if op_machine == machine_id:
                    op_index = i
                    break
            if op_index is not None:
                machine_workloads[machine_id] += job_operation_time[job_id][op_index]
    
    max_machine_workload = max(machine_workloads) if machine_workloads else 1
    
    # Calculate remaining workload for each job
    remaining_job_workloads = [0] * num_jobs
    for job_id in range(num_jobs):
        current_op_index = current_solution.job_operation_index[job_id]
        if current_op_index < len(job_operation_sequence[job_id]):
            remaining_job_workloads[job_id] = sum(job_operation_time[job_id][current_op_index:])
    
    max_remaining_workload = max(remaining_job_workloads) if remaining_job_workloads else 1
    
    # Find jobs with remaining operations and calculate priority scores
    available_jobs = []
    priority_scores = []
    
    for job_id in range(num_jobs):
        current_op_index = current_solution.job_operation_index[job_id]
        
        # Check if job has remaining operations
        if current_op_index < len(job_operation_sequence[job_id]):
            # Get the processing time and target machine for the next operation
            next_machine = job_operation_sequence[job_id][current_op_index]
            processing_time = job_operation_time[job_id][current_op_index]
            
            # Calculate adaptive alpha based on processing time variability
            adaptive_alpha = alpha_base + beta * processing_time_cv
            
            # Calculate priority score: lower is better
            machine_utilization = machine_workloads[next_machine] / max_machine_workload if max_machine_workload > 0 else 0
            remaining_workload_ratio = remaining_job_workloads[job_id] / max_remaining_workload if max_remaining_workload > 0 else 0
            
            priority_score = (processing_time - adaptive_alpha * machine_utilization + 
                            gamma * remaining_workload_ratio)
            
            available_jobs.append(job_id)
            priority_scores.append(priority_score)
    
    # If no jobs have remaining operations, return None
    if not available_jobs:
        return None, {}
    
    # Find the job with the best (lowest) priority score
    min_score = min(priority_scores)
    candidate_jobs = [job_id for job_id, score in zip(available_jobs, priority_scores) 
                     if score == min_score]
    
    # Select the job with smallest ID among candidates
    selected_job = min(candidate_jobs)
    
    # Return the AdvanceOperator for the selected job
    return AdvanceOperator(selected_job), {}