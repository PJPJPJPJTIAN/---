import argparse  # 导入argparse模块，用于解析命令行参数
import os  # 导入os模块，用于文件和目录操作
from src.pipeline.problem_state_generator import ProblemStateGenerator  # 从指定模块导入ProblemStateGenerator类，用于生成问题状态
from src.util.llm_client.get_llm_client import get_llm_client  # 从指定模块导入get_llm_client函数，用于获取LLM客户端实例

def parse_arguments():  # 定义解析命令行参数的函数
    problem_pool = [problem for problem in os.listdir(os.path.join("src", "problems")) if problem != "base"]  # 获取src/problems目录下除base外的所有问题名称，作为可选问题池

    parser = argparse.ArgumentParser(description="Generate problem state")  # 创建参数解析器，描述为"Generate problem state"
    parser.add_argument("-p", "--problem", choices=problem_pool, required=True, help="Specifies the type of combinatorial optimization problem.")  # 添加-p/--problem参数，必填，选择范围为problem_pool，用于指定组合优化问题类型
    parser.add_argument("-m", "--smoke_test", action='store_true', help="Optional flag to conduct a preliminary smoke test.")  # 添加-m/--smoke_test参数，可选标志，用于指定是否进行初步冒烟测试
    parser.add_argument("-l", "--llm_config_file", type=str, default=os.path.join("output", "llm_config", "azure_gpt_4o.json"), help="Path to the language model configuration file. Default is azure_gpt_4o.json.")  # 添加-l/--llm_config_file参数，字符串类型，默认值为output/llm_config/azure_gpt_4o.json，用于指定LLM配置文件路径

    return parser.parse_args()  # 解析命令行参数并返回

def main():  # 定义主函数
    args = parse_arguments()  # 调用参数解析函数，获取解析后的参数
    problem = args.problem  # 从参数中获取问题类型
    smoke_test = args.smoke_test  # 从参数中获取是否进行冒烟测试的标志
    llm_config_file = args.llm_config_file  # 从参数中获取LLM配置文件路径

    prompt_dir=os.path.join("src", "problems", "base", "prompt")  # 定义提示词目录为src/problems/base/prompt
    output_dir=output_dir=os.path.join("output", problem, "generate_problem_state")  # 定义输出目录为output/[问题类型]/generate_problem_state
    llm_client = get_llm_client(llm_config_file, prompt_dir, output_dir)  # 调用get_llm_client函数，传入配置文件路径、提示词目录和输出目录，获取LLM客户端实例

    problem_state_generator = ProblemStateGenerator(llm_client=llm_client, problem=problem)  # 创建ProblemStateGenerator实例，传入LLM客户端和问题类型
    problem_state_generator.generate_problem_state(smoke_test=smoke_test)  # 调用generate_problem_state方法生成问题状态，传入冒烟测试标志

if __name__ == "__main__":  # 如果当前脚本作为主程序运行
    main()  # 调用主函数