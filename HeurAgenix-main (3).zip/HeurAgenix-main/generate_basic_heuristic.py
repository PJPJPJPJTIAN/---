# 导入argparse模块用于解析命令行参数，os模块用于文件路径操作，从src.pipeline.heuristic_generator导入HeuristicGenerator类（启发式生成的核心类），从src.util.llm_client.get_llm_client导入get_llm_client函数（用于获取大语言模型客户端）
import argparse
import os
from src.pipeline.heuristic_generator import HeuristicGenerator
from src.util.llm_client.get_llm_client import get_llm_client

# 定义parse_arguments函数，用于解析命令行输入的参数
def parse_arguments():
    # 从src/problems目录下获取所有问题类型（排除base，因为base是基础模板），作为可选的问题池
    problem_pool = [problem for problem in os.listdir(os.path.join("src", "problems")) if problem != "base"]

    # 创建参数解析器，描述为“Generate heuristic”
    parser = argparse.ArgumentParser(description="Generate heuristic")
    # 添加-p/--problem参数，必选，用于指定组合优化问题类型，选项为problem_pool中的问题
    parser.add_argument("-p", "--problem", choices=problem_pool, required=True, help="Specifies the type of combinatorial optimization problem.")
    # 添加-m/--smoke_test参数，可选标志，用于执行初步的冒烟测试
    parser.add_argument("-m", "--smoke_test", action='store_true', help="Optional flag to conduct a preliminary smoke test.")
    # 添加-l/--llm_config_file参数，字符串类型，默认值为output/llm_config/azure_gpt_4o.json，用于指定语言模型配置文件路径
    parser.add_argument("-l", "--llm_config_file", type=str, default=os.path.join("output", "llm_config", "azure_gpt_4o.json"), help="Path to the language model configuration file. Default is azure_gpt_4o.json.")
    # 添加-s/--source参数，选项为["llm", "paper", "related_problem"]，默认值为"llm"，用于指定启发式生成的来源（大语言模型、论文、相关问题）
    parser.add_argument("-s", "--source", choices=["llm", "paper", "related_problem"], default="llm", help="Source for generating heuristics: 'llm' for automated model generation, 'paper' for literature-based methods, 'related_problem' for adaptations from similar problems.")
    # 添加-pp/--paper_path参数，字符串类型，用于指定包含启发式描述的LaTeX论文文件或目录路径（当source为paper时使用）
    parser.add_argument("-pp", "--paper_path", type=str, help="Specify the path to a LaTeX paper file or directory containing heuristic descriptions.")
    # 添加-r/--related_problems参数，字符串类型，默认值为"all"，用于指定从哪些相关问题领域获取启发式见解（以逗号分隔，当source为related_problem时使用）
    parser.add_argument("-r", "--related_problems", type=str, default="all", help="Comma-separated list of related problem domains to draw heuristic insights from.")
    # 添加-d/--reference_data参数，字符串类型，默认值为None，用于指定参考数据集的路径（生成适应特定数据分布的启发式时使用）
    parser.add_argument("-d", "--reference_data", type=str, default=None, help="Optional path to reference datasets, used when generating heuristics tailored to specific data distributions.")

    # 返回解析后的参数
    return parser.parse_args()

# 定义主函数main
def main():
    # 调用parse_arguments函数获取解析后的命令行参数
    args = parse_arguments()
    # 从参数中提取问题类型
    problem = args.problem
    # 从参数中提取启发式生成来源
    source = args.source
    # 从参数中提取是否进行冒烟测试的标志
    smoke_test = args.smoke_test
    # 从参数中提取语言模型配置文件路径
    llm_config_file = args.llm_config_file

    # 定义提示词模板目录为src/problems/base/prompt
    prompt_dir=os.path.join("src", "problems", "base", "prompt")
    # 定义输出目录为output/[问题类型]/generate_heuristic
    output_dir=os.path.join("output", problem, "generate_heuristic")
    # 调用get_llm_client函数获取大语言模型客户端，传入配置文件路径、提示词目录和输出目录
    llm_client = get_llm_client(llm_config_file, prompt_dir, output_dir)

    # 实例化HeuristicGenerator类，传入大语言模型客户端和问题类型
    heuristic_generator = HeuristicGenerator(llm_client=llm_client, problem=problem)
    # 根据生成来源调用对应的生成方法
    if source == "llm":
        # 若来源为llm，调用generate_from_llm方法，传入参考数据和冒烟测试标志
        heuristic_generator.generate_from_llm(reference_data=args.reference_data, smoke_test=smoke_test)
    elif source == "paper":
        # 若来源为paper，调用generate_from_paper方法，传入论文路径、参考数据和冒烟测试标志
        heuristic_generator.generate_from_paper(paper_path=args.paper_path, reference_data=args.reference_data, smoke_test=smoke_test)
    elif source == "related_problem":
        # 若来源为related_problem，处理相关问题列表
        if args.related_problems == "all":
            # 若related_problems为all，则获取除base和当前问题外的所有问题作为相关问题
            related_problems = [ref_problem for ref_problem in os.listdir(os.path.join("src", "problems")) if ref_problem not in ["base", problem]]
        else:
            # 否则，将输入的字符串按逗号分割为相关问题列表
            related_problems = args.related_problems.split(",")
        # 调用generate_from_reference方法，传入相关问题列表、参考数据和冒烟测试标志
        heuristic_generator.generate_from_reference(related_problems=related_problems, reference_data=args.reference_data, smoke_test=smoke_test)

# 当脚本作为主程序运行时，调用main函数
if __name__ == "__main__":
    main()

