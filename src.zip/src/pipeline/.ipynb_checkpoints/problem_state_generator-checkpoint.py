# 导入所需的模块：os用于文件路径操作，yaml用于处理yaml格式数据，importlib用于动态导入模块，traceback用于捕获和格式化异常信息
import os
import yaml
import importlib
import traceback
# 从自定义工具模块导入工具函数：extract用于从文本中提取特定内容，load_function用于加载函数，
# parse_text_to_dict用于将文本解析为字典，search_file用于搜索文件路径
from src.util.util import extract, load_function, parse_text_to_dict, search_file
# 从自定义的LLM客户端基类模块导入BaseLLMClient，用于与大语言模型交互
from src.util.llm_client.base_llm_client import BaseLLMClient

# `generate_problem_state` 函数是 `ProblemStateGenerator` 类的核心方法，用于自动生成特定问题（如 `dposp`、`jssp` 等）的 `problem_state.py` 代码及描述文件，主要步骤如下：


# ### **1. 初始化与配置加载**
# - **加载背景信息**：通过 `llm_client.load_background` 获取问题相关的背景数据，作为生成提示的基础。
# - **读取问题描述文件**：查找并解析 `problem_state_description.txt`，提取 `instance_data`（实例数据结构）、`key_item`（关键评价指标）等信息，用于构建提示词。


# ### **2. 生成实例问题状态（Instance Problem State）**
# - **获取状态定义**：加载 `generate_instance_problem_state` 提示模板，调用 LLM 生成该问题的实例状态列表（如 `average_operation_time`、`max_operation_time` 等），并提取状态名称。
# - **生成代码**：使用 `implement_instance_problem_state_code` 模板，让 LLM 根据状态定义生成 `get_instance_problem_state` 函数的代码（从实例数据中提取实例状态）。


# ### **3. 生成解决方案问题状态（Solution Problem State）**
# - **获取状态定义**：加载 `generate_solution_problem_state` 提示模板，调用 LLM 生成与当前解决方案相关的状态列表（如 `fulfilled_order_num`、`current_makespan` 等），提取状态名称。
# - **生成代码**：使用 `implement_solution_problem_state_code` 模板，生成 `get_solution_problem_state` 函数的代码（从实例数据和当前解决方案中提取状态）。


# ### **4. 生成观测问题状态（Observation Problem State）**
# - **筛选核心状态**：加载 `generate_observation_problem_state` 提示模板，让 LLM 从解决方案状态中筛选核心状态（用于记录解决方案的关键变化）。
# - **生成代码**：使用 `implement_observation_problem_state_code` 模板，生成 `get_observation_problem_state` 函数的代码（提取核心状态作为观测结果）。


# ### **5. 代码验证与修正（可选，烟雾测试）**
# - **执行烟雾测试**：若启用 `smoke_test`，加载问题的测试数据（`smoke_data`），初始化环境并运行生成的 3 个状态提取函数，检查是否存在错误。
# - **迭代修正**：若测试出错，将错误信息反馈给 LLM，生成修正后的代码，重复测试直至通过（最多尝试 `max_try_times` 次）。


# ### **6. 保存结果**
# - **保存代码文件**：将生成的 3 个函数代码整合为 `problem_state.py`，保存到 `output/{problem}/generate_problem_state` 目录。
# - **保存描述文件**：从代码注释中提取状态描述，生成 `problem_state.txt`，记录所有状态的含义和格式，用于后续启发式算法生成和问题求解。


# ### **核心作用**
# 通过 LLM 自动化生成问题状态提取代码，捕捉问题实例的静态特征和解决方案的动态特征，为后续启发式算法设计、环境交互提供结构化的状态信息，实现不同问题的通用适配。


# 定义ProblemStateGenerator类，用于生成问题状态相关代码和描述
class ProblemStateGenerator:
    # 类的初始化方法，接收llm_client（LLM客户端实例）和problem（问题名称）作为参数
    def __init__(
        self,
        llm_client: BaseLLMClient,
        problem: str
    ) -> None:
        # 将传入的llm_client赋值给实例变量，用于后续与LLM交互
        self.llm_client = llm_client
        # 将传入的problem赋值给实例变量，标识当前处理的问题
        self.problem = problem
        # 从llm_client中获取输出目录，用于保存生成的文件
        self.output_dir = self.llm_client.output_dir
        # 创建输出目录（如果不存在），exist_ok=True确保目录已存在时不会报错
        os.makedirs(self.output_dir, exist_ok=True)

    # 生成问题状态的核心方法，返回生成的problem_state.py文件路径，smoke_test控制是否进行冒烟测试，max_try_times为最大尝试次数
    def generate_problem_state(self, smoke_test: bool=False, max_try_times: int=5) -> str:
        # 调用llm_client的load_background方法加载无代码的背景信息（问题描述等），返回包含背景信息的字典
        prompt_dict = self.llm_client.load_background(self.problem, "background_without_code")
        
        # 搜索当前问题的problem_state_description.txt文件路径，该文件描述问题状态的格式要求
        problem_state_description_file = search_file("problem_state_description.txt", problem=self.problem)
       
        # 断言文件存在，若不存在则抛出异常提示
        assert problem_state_description_file is not None, f"Problem state description file {problem_state_description_file} does not exist"
        # 读取文件内容并解析为字典，获取问题状态描述的具体内容
        problem_state_description = parse_text_to_dict(open(problem_state_description_file).read())

        # 从解析后的字典中提取实例数据介绍，存入prompt_dict供后续生成提示使用
        prompt_dict["instance_data_introduction"] = problem_state_description["instance_data"]
        # 处理key_item，提取关键项名称（去除特殊字符和空格）
        prompt_dict["key_item"] = problem_state_description["key_item"].split(":")[0].split("(")[0].replace("-", "").replace(" ", "").replace("\"", "").replace("\"", "")
        # 提取key_item的描述信息，存入prompt_dict
        prompt_dict["key_item_description"] = problem_state_description["key_item"].split(":")[-1]
       
        # 加载生成实例问题状态的提示，调用LLM生成响应
        self.llm_client.load("generate_instance_problem_state", prompt_dict)
        response = self.llm_client.chat()
        # 从响应中提取实例问题状态列表，处理后存入prompt_dict
        instance_problem_states = extract(response, "instance_problem_state", "\n")
        instance_problem_states = ",".join([instance_problem_state.split(";")[0] for instance_problem_state in instance_problem_states])
        prompt_dict["instance_problem_states"] = instance_problem_states

        # 加载生成实例问题状态代码的提示，调用LLM生成代码
        self.llm_client.load("implement_instance_problem_state_code", prompt_dict)
        response = self.llm_client.chat()
        # 提取生成的实例问题状态代码
        instance_problem_state_code = extract(response, "python_code")
        # 将当前对话内容 dump 到输出目录，文件名为instance_problem_state
        self.llm_client.dump(f"instance_problem_state")

        # 加载生成解决方案问题状态的提示，调用LLM生成响应
        self.llm_client.load("generate_solution_problem_state", prompt_dict)
        response = self.llm_client.chat()
        # 从响应中提取解决方案问题状态列表，处理后存入prompt_dict
        solution_problem_states = extract(response, "solution_problem_state", "\n")
        solution_problem_states = ",".join([solution_problem_state.split(";")[0] for solution_problem_state in solution_problem_states])
        prompt_dict["solution_problem_states"] = solution_problem_states

        # 加载生成解决方案问题状态代码的提示，调用LLM生成代码
        self.llm_client.load("implement_solution_problem_state_code", prompt_dict)
        response = self.llm_client.chat()
        # 提取生成的解决方案问题状态代码，并添加必要的导入语句
        solution_problem_state_code = extract(response, "python_code")
        solution_problem_state_code = f"from src.problems.{self.problem}.components import Solution\n" + solution_problem_state_code
        # 将当前对话内容 dump 到输出目录，文件名为solution_problem_state
        self.llm_client.dump(f"solution_problem_state")

        # 加载生成观察问题状态的提示，调用LLM生成响应
        self.llm_client.load("generate_observation_problem_state", prompt_dict)
        response = self.llm_client.chat()
        # 从响应中提取观察问题状态列表，处理后存入prompt_dict
        observation_problem_states = extract(response, "observation_problem_state", "\n")
        observation_problem_states = ",".join([observation_problem_state.split(";")[0] for observation_problem_state in observation_problem_states])
        prompt_dict["observation_problem_states"] = observation_problem_states

        # 加载生成观察问题状态代码的提示，调用LLM生成代码
        self.llm_client.load("implement_observation_problem_state_code", prompt_dict)
        response = self.llm_client.chat()
        # 提取生成的观察问题状态代码
        observation_problem_state_code = extract(response, "python_code")
        # 将当前对话内容 dump 到输出目录，文件名为observation_problem_state
        self.llm_client.dump(f"observation_problem_state")

        problem_state_code_file = os.path.join(self.output_dir, "problem_state.py")
        # 构建代码头部，包含生成说明和必要的导入语句
        node = f"# This file is generated by generate_problem_state.py.\n\nfrom src.problems.{self.problem}.components import Solution\n"
        # 组合三段代码为完整的problem_state.py内容
        problem_state_code = "\n\n".join([node, instance_problem_state_code, solution_problem_state_code, observation_problem_state_code])
        # 写入文件
        with open(problem_state_code_file, "w") as fp:
            fp.write(problem_state_code) 
        # 临时保存，只是为了让env启动

        # 如果启用冒烟测试，进行代码验证和修订
        if smoke_test:
            print("=== 冒烟测试（smoke test）开始 ===")
            # 初始测试
            instance_error_message, solution_error_message, observation_error_message = self.smoke_test(instance_problem_state_code, solution_problem_state_code, observation_problem_state_code)
            # 记录当前外层循环的重试次数
            current_try = 0
            while (instance_error_message or solution_error_message or observation_error_message) and current_try < max_try_times:
                self.llm_client.dump(f"problem_state_revision_try_{current_try}")
                # 修复错误（同原逻辑）
                if instance_error_message:
                    self.llm_client.load(instance_error_message)
                    response = self.llm_client.chat()
                    instance_problem_state_code = extract(response, "python_code")
                if solution_error_message:
                    self.llm_client.load(solution_error_message)
                    response = self.llm_client.chat()
                    solution_problem_state_code = extract(response, "python_code")
                if observation_error_message:
                    self.llm_client.load(observation_error_message)
                    response = self.llm_client.chat()
                    observation_problem_state_code = extract(response, "python_code")
                # 重新测试
                instance_error_message, solution_error_message, observation_error_message = self.smoke_test(instance_problem_state_code, solution_problem_state_code, observation_problem_state_code)
                current_try += 1  # 累加重试次数
            
            # 若超过最大重试次数仍有错误，则放弃
            if instance_error_message or solution_error_message or observation_error_message:
                self.llm_client.dump("problem_state_abandoned")
                return None
                
        # 测试通过后，正常保存
        # 保存问题状态代码到文件
        problem_state_code_file = os.path.join(self.output_dir, "problem_state.py")
        # 构建代码头部，包含生成说明和必要的导入语句
        node = f"# This file is generated by generate_problem_state.py.\n\nfrom src.problems.{self.problem}.components import Solution\n"
        # 组合三段代码为完整的problem_state.py内容
        problem_state_code = "\n\n".join([node, instance_problem_state_code, solution_problem_state_code, observation_problem_state_code])
        # 写入文件
        with open(problem_state_code_file, "w") as fp:
            fp.write(problem_state_code)
        # 打印保存路径
        print(f"Save problem state in {problem_state_code_file}")

        # 生成并保存问题状态描述
        instance_problem_state_description = self.get_problem_state_description(instance_problem_state_code)
        solution_problem_state_description = self.get_problem_state_description(solution_problem_state_code)
        # 更新问题状态描述字典
        problem_state_description["instance_problem_state"] = instance_problem_state_description
        problem_state_description["solution_problem_state"] = solution_problem_state_description
        # 处理描述内容，整理格式
        problem_state_descriptions = [line.lstrip() for line in "\n".join(problem_state_description.values()).split("\n")]
        node = "problem_state (dict): The dictionary contains the problem state with:\n    "
        problem_state_description_str = node + "\n    ".join(problem_state_descriptions)
        # 保存描述到problem_state.txt文件
        problem_state_description_file = os.path.join(self.output_dir, "problem_state.txt")
        with open(problem_state_description_file, "w") as fp:
            fp.write(problem_state_description_str)
        # 返回生成的problem_state.py文件路径
        return problem_state_code_file

    # 从问题状态代码中提取描述信息的方法
    def get_problem_state_description(self, problem_state_code: str) -> None:
        # 从代码的文档字符串中提取问题状态描述
        description = problem_state_code.split("\"\"\"")[1].split("problem state with:\n")[-1].strip()
        return description

    def smoke_test(self, instance_problem_state_code: str, solution_problem_state_code: str, observation_problem_state_code: str) -> str:
        # 搜索冒烟测试数据所在目录
        smoke_data_dir = search_file("smoke_data", problem=self.problem)
        # 读取之前的操作记录（如果存在）
        previous_operations = []
        if os.path.exists(os.path.join(smoke_data_dir, "previous_operations.txt")):
            previous_operations = open(os.path.join(smoke_data_dir, "previous_operations.txt")).readlines()
        # 过滤非文件的项（避免 .ipynb_checkpoints 等目录）
        # 定义需要排除的隐藏文件夹
        exclude_folders = [".ipynb_checkpoints", "__pycache__"]
        if self.problem != 'dposp':
            smoke_files = [f for f in os.listdir(smoke_data_dir) if f != "previous_operations.txt" and os.path.isfile(os.path.join(smoke_data_dir, f))]
        else:
            # 对于dposp问题，查找案例文件夹（目录）并排除隐藏文件夹
            smoke_files = [
                f for f in os.listdir(smoke_data_dir) 
                if f != "previous_operations.txt" 
                and os.path.isdir(os.path.join(smoke_data_dir, f))
                and f not in exclude_folders
            ]
        if not smoke_files:
            print("测试失败：未找到有效的测试数据文件")
            print("=== 冒烟测试（smoke test）结束 ===")
            return "未找到有效的测试数据文件", None, None
        smoke_data = os.path.join(smoke_data_dir, smoke_files[0])

        # 准备环境：动态导入当前问题的Env类
        module = importlib.import_module(f"src.problems.{self.problem}.env")
        globals()["Env"] = getattr(module, "Env")
        # 导入当前问题的组件类（如Solution、Operator等）
        if os.path.exists(os.path.join("src", "problems", self.problem, "components.py")):
            module = importlib.import_module(f"src.problems.{self.problem}.components")
        else:
            module = importlib.import_module(f"src.problems.base.mdp_components")
        # 将组件类导入到全局变量，方便后续使用
        names_to_import = (name for name in dir(module) if not name.startswith('_'))
        for name in names_to_import:
            globals()[name] = getattr(module, name)
        # 初始化环境并重置
        env = Env(data_name=smoke_data)
   
        env.reset()
        # 执行之前的操作，恢复到特定状态
        for previous_operation in previous_operations:
            env.run_operator(eval(previous_operation.strip()))
        try:
            # 加载并运行实例问题状态函数，验证是否正常返回结果
            get_instance_problem_state = load_function(instance_problem_state_code, function_name="get_instance_problem_state")
            instance_problem_state = get_instance_problem_state(env.instance_data)
            assert instance_problem_state is not None
        except Exception as e:
            # 捕获异常，生成错误信息返回
            error_message = traceback.format_exc()
            return f"We got error when run get_instance_problem_state:\n{error_message}. Please fix up the get_instance_problem_state function in same format.", None, None
        try:
            # 加载并运行解决方案问题状态函数，验证是否正常返回结果
            get_solution_problem_state = load_function(solution_problem_state_code, function_name="get_solution_problem_state")
            solution_problem_state = get_solution_problem_state(env.instance_data, env.current_solution)
            assert solution_problem_state is not None
        except Exception as e:
            # 捕获异常，生成错误信息返回
            error_message = traceback.format_exc()
            return None, f"We got error when run get_solution_problem_state:\n{error_message}. Please fix up the get_solution_problem_state function in same format.", None
        try:
            # 加载并运行观察问题状态函数，验证是否正常返回结果
            get_observation_problem_state = load_function(observation_problem_state_code, function_name="get_observation_problem_state")
            observation_problem_state = get_observation_problem_state(solution_problem_state)
            assert observation_problem_state is not None
        except Exception as e:
            # 捕获异常，生成错误信息返回
            error_message = traceback.format_exc()
            return None, None, f"We got error when run get_observation_problem_state:\n{error_message}. Please fix up the get_observation_problem_state function in same format."
        # 若所有测试通过，返回None（无错误）
        return None, None, None


