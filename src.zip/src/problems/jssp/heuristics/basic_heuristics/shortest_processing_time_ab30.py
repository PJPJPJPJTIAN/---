from src.problems.jssp.components import *
import numpy as np

def shortest_processing_time_ab30(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[AdvanceOperator, dict]:
    """Enhanced Shortest Processing Time with Adaptive Machine Workload Balancing heuristic for JSSP.
    
    This heuristic extends the basic SPT rule with adaptive machine workload balancing.
    It dynamically adjusts the workload balancing weight based on current machine workload imbalance,
    favoring jobs with short operations that go to less loaded machines, with stronger emphasis
    when workloads are highly imbalanced.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - job_operation_sequence (numpy.ndarray): A list of jobs where each job is a list of operations in target sequence
            - job_operation_time (numpy.ndarray): The time cost for each operation in target job
            - current_solution (Solution): Current solution instance containing job_operation_index and job_sequences
            - num_jobs (int): Total number of jobs
            - num_machines (int): Total number of machines
            - machine_workload_std (float): Standard deviation of machine workloads for imbalance measurement
        algorithm_data (dict): The algorithm dictionary for current algorithm only. In this algorithm, no specific data is required.
        **kwargs: Hyper-parameters for the algorithm:
            - base_alpha (float, default=0.4): Base weight factor for machine workload balancing
            - min_alpha (float, default=0.1): Minimum alpha value to maintain some balancing effect
            - max_alpha (float, default=0.8): Maximum alpha value to prevent excessive weighting
            
    Returns:
        AdvanceOperator: An operator that advances the job with the best priority score using adaptive weighting,
                         or None if no jobs have remaining operations to schedule.
        dict: Empty dictionary as no algorithm data needs to be updated.

    Notes:
        - Only considers jobs that have remaining operations to schedule
        - Calculates current machine workload based on processing times of already scheduled operations
        - Dynamically adjusts alpha based on machine workload imbalance ratio
        - Returns None if all jobs have been fully scheduled (no remaining operations)
    """
    
    # Extract necessary data from problem_state
    job_operation_sequence = problem_state['job_operation_sequence']
    job_operation_time = problem_state['job_operation_time']
    current_solution = problem_state['current_solution']
    num_jobs = problem_state['num_jobs']
    num_machines = problem_state['num_machines']
    machine_workload_std = problem_state['machine_workload_std']
    
    # Set default hyper-parameters
    base_alpha = kwargs.get('base_alpha', 0.4)
    min_alpha = kwargs.get('min_alpha', 0.1)
    max_alpha = kwargs.get('max_alpha', 0.8)
    
    # Find jobs with remaining operations and calculate their priority scores
    available_jobs = []
    priority_scores = []
    
    # Calculate current machine workloads (sum of processing times for scheduled operations)
    machine_workloads = [0.0] * num_machines
    for machine_id in range(num_machines):
        for job_id in current_solution.job_sequences[machine_id]:
            # Find the operation index for this job on this machine
            op_index = None
            for i, machine in enumerate(job_operation_sequence[job_id]):
                if machine == machine_id:
                    op_index = i
                    break
            if op_index is not None:
                machine_workloads[machine_id] += job_operation_time[job_id][op_index]
    
    # Calculate average machine workload
    avg_machine_workload = sum(machine_workloads) / num_machines if num_machines > 0 else 0
    
    # Calculate dynamic alpha based on workload imbalance
    if avg_machine_workload > 0:
        imbalance_ratio = machine_workload_std / avg_machine_workload
        alpha = base_alpha * imbalance_ratio
        alpha = max(min_alpha, min(max_alpha, alpha))  # Clamp within bounds
    else:
        alpha = base_alpha  # Default value for initial state
    
    for job_id in range(num_jobs):
        current_op_index = current_solution.job_operation_index[job_id]
        
        # Check if job has remaining operations
        if current_op_index < len(job_operation_sequence[job_id]):
            # Get the processing time and target machine for the next operation
            next_machine = job_operation_sequence[job_id][current_op_index]
            processing_time = job_operation_time[job_id][current_op_index]
            
            # Calculate normalized machine load (avoid division by zero)
            normalized_load = machine_workloads[next_machine] / avg_machine_workload if avg_machine_workload > 0 else 1.0
            
            # Compute priority score: processing_time + alpha * normalized_machine_load
            priority_score = processing_time + alpha * normalized_load
            
            available_jobs.append(job_id)
            priority_scores.append(priority_score)
    
    # If no jobs have remaining operations, return None
    if not available_jobs:
        return None, {}
    
    # Find the job with the smallest priority score
    min_score = min(priority_scores)
    candidate_jobs = [job_id for job_id, score in zip(available_jobs, priority_scores) 
                     if abs(score - min_score) < 1e-6]  # Account for floating point precision
    
    # Select the job with smallest ID among candidates (tie-breaking)
    selected_job = min(candidate_jobs)
    
    # Return the AdvanceOperator for the selected job
    return AdvanceOperator(selected_job), {}