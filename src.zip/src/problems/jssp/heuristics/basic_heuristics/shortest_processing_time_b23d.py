from src.problems.jssp.components import *
import numpy as np

def shortest_processing_time_b23d(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[AdvanceOperator, dict]:
    """Shortest Processing Time (SPT) heuristic for JSSP.
    
    This heuristic selects the job with the shortest processing time for its next operation
    and advances it to the corresponding machine queue. SPT is a well-known dispatching rule
    that tends to minimize average flow time and work-in-process inventory.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - job_operation_sequence (numpy.ndarray): A list of jobs where each job is a list of operations in target sequence
            - job_operation_time (numpy.ndarray): The time cost for each operation in target job
            - current_solution (Solution): Current solution instance containing job_operation_index
            - num_jobs (int): Total number of jobs
        algorithm_data (dict): The algorithm dictionary for current algorithm only. In this algorithm, no specific data is required.
        **kwargs: Hyper-parameters for the algorithm (none required for basic SPT implementation)

    Returns:
        AdvanceOperator: An operator that advances the job with the shortest next operation time,
                         or None if no jobs have remaining operations to schedule.
        dict: Empty dictionary as no algorithm data needs to be updated.

    Notes:
        - Only considers jobs that have remaining operations to schedule
        - If multiple jobs have the same shortest processing time, selects the one with the smallest job ID
        - Returns None if all jobs have been fully scheduled (no remaining operations)
    """
    
    # Extract necessary data from problem_state
    job_operation_sequence = problem_state['job_operation_sequence']
    job_operation_time = problem_state['job_operation_time']
    current_solution = problem_state['current_solution']
    num_jobs = problem_state['num_jobs']
    
    # Find jobs with remaining operations
    available_jobs = []
    processing_times = []
    
    for job_id in range(num_jobs):
        current_op_index = current_solution.job_operation_index[job_id]
        
        # Check if job has remaining operations
        if current_op_index < len(job_operation_sequence[job_id]):
            # Get the processing time for the next operation
            next_machine = job_operation_sequence[job_id][current_op_index]
            processing_time = job_operation_time[job_id][current_op_index]
            
            available_jobs.append(job_id)
            processing_times.append(processing_time)
    
    # If no jobs have remaining operations, return None
    if not available_jobs:
        return None, {}
    
    # Find the job with the shortest processing time for its next operation
    # If multiple jobs have the same shortest time, select the one with smallest job ID
    min_processing_time = min(processing_times)
    candidate_jobs = [job_id for job_id, time in zip(available_jobs, processing_times) 
                     if time == min_processing_time]
    
    # Select the job with smallest ID among candidates
    selected_job = min(candidate_jobs)
    
    # Return the AdvanceOperator for the selected job
    return AdvanceOperator(selected_job), {}