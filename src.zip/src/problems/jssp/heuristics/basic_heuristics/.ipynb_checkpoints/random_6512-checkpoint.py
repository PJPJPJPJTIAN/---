from src.problems.jssp.components import Solution, AdvanceOperator
import random
import numpy as np

def random_6512(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[AdvanceOperator, dict]:
    """This heuristic randomly selects an unfinished job and advances its next operation in the job's processing sequence.

    Args:
        problem_state (dict): The dictionary contains the problem state including:
            - "num_jobs" (int): The total number of jobs in the problem
            - "num_machines" (int): The total number of machines in the problem
            - "job_operation_sequence" (numpy.ndarray): Sequence of machines for each job's operations
            - "job_operation_time" (numpy.ndarray): Time cost for each operation
            - "current_solution" (Solution): Current solution instance
            - "completion_ratio" (float): Ratio of scheduled operations to total operations
            - "avg_remaining_ops_per_job" (float): Average remaining operations per job
            - Other properties from the generated problem_state
    Returns:
        AdvanceOperator: The operator to advance the next operation for a randomly selected unfinished job
        dict: Updated algorithm data (empty in this case)
    """
    # Extract necessary data from problem state
    current_solution = problem_state.get("current_solution")
    num_jobs = problem_state.get("num_jobs", 0)
    num_machines = problem_state.get("num_machines", 0)
    
    if not current_solution or num_jobs == 0 or num_machines == 0:
        return None, {}

    # Identify unfinished jobs based on their operation index
    unfinished_jobs = []
    for job_id in range(num_jobs):
        # Check if job has remaining operations
        if current_solution.job_operation_index[job_id] < num_machines:
            unfinished_jobs.append(job_id)

    # Check if there are any unfinished jobs
    if not unfinished_jobs:
        return None, {}

    # Randomly select an unfinished job
    selected_job = random.choice(unfinished_jobs)

    # Create an AdvanceOperator for the selected job
    operator = AdvanceOperator(job_id=selected_job)

    # Return the operator and an empty dictionary as no algorithm data is updated
    return operator, {}
