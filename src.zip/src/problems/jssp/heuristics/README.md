# Heuristic Folder 
 
This heuristic folder contains heuristics of the Job Shop Scheduling Problem (JSSP). 

- basic_heuristics contains the basic heuristics from GPT-4o by "python generate_heuristic.py"
- evolved_heuristics contains the evolved heuristics from GPT-4o by "python evolution_heuristic.py"
