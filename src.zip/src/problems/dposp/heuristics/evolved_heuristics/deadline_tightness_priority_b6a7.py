from src.problems.dposp.components import *
import numpy as np
from typing import Optional

def deadline_tightness_priority_b6a7(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[Optional[BaseOperator], dict]:
    """ Implements deadline tightness priority heuristic for DPOSP.
    
    This heuristic prioritizes orders with the tightest deadline-to-processing-time ratio
    to prevent missed deadlines. It calculates the tightness ratio for each unfulfilled order
    and selects the most critical one to insert at the best feasible position.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - current_solution (Solution): Current solution instance with production schedules
            - production_rate (numpy.array): 2D array of production speeds for each product on each production line
            - order_product (numpy.array): 1D array mapping each order to its required product
            - order_quantity (numpy.array): 1D array of the quantity required for each order
            - order_deadline (numpy.array): 1D array of the deadline for each order
            - validation_single_production_schedule (callable): Function to validate a production schedule
        algorithm_data (dict): The algorithm dictionary for current algorithm only. In this algorithm, the following items are necessary:
            - last_processed_orders (list): List of recently processed orders to avoid cycling (optional)
        kwargs: Hyper parameters for the algorithm:
            - min_tightness_threshold (float): Minimum tightness ratio to consider (default: 0.1)
            - max_attempts_per_order (int): Maximum insertion attempts per order (default: 50)
            - avoid_recent_cycles (bool): Whether to avoid recently processed orders (default: True)
            - recent_cycle_window (int): Window size for recent order tracking (default: 10)

    Returns:
        BaseOperator: An InsertOperator or AppendOperator for the best feasible insertion, 
                     or None if no valid insertion found.
        dict: Updated algorithm data with last processed orders tracking.

    The algorithm will return None if:
    1. No unfulfilled orders exist
    2. No feasible insertion position found for any order
    3. All orders have tightness ratios below threshold
    """
    
    # Extract hyperparameters with default values
    min_tightness_threshold = kwargs.get('min_tightness_threshold', 0.1)
    max_attempts_per_order = kwargs.get('max_attempts_per_order', 50)
    avoid_recent_cycles = kwargs.get('avoid_recent_cycles', True)
    recent_cycle_window = kwargs.get('recent_cycle_window', 10)
    
    # Extract necessary problem state data
    current_solution = problem_state['current_solution']
    production_rate = problem_state['production_rate']
    order_product = problem_state['order_product']
    order_quantity = problem_state['order_quantity']
    order_deadline = problem_state['order_deadline']
    validation_single_production_schedule = problem_state['validation_single_production_schedule']
    
    # Initialize or update algorithm data for cycle avoidance
    if 'last_processed_orders' not in algorithm_data:
        algorithm_data['last_processed_orders'] = []
    last_processed_orders = algorithm_data['last_processed_orders']
    
    # Find all unfulfilled orders (not in current solution)
    all_orders = set(range(len(order_product)))
    fulfilled_orders = set()
    for line_schedule in current_solution.production_schedule:
        fulfilled_orders.update(line_schedule)
    unfulfilled_orders = list(all_orders - fulfilled_orders)
    
    if not unfulfilled_orders:
        return None, algorithm_data
    
    # Calculate tightness ratio for each unfulfilled order
    order_tightness = {}
    feasible_orders = []
    
    for order_id in unfulfilled_orders:
        # Avoid recently processed orders if enabled
        if avoid_recent_cycles and order_id in last_processed_orders:
            continue
            
        product_id = order_product[order_id]
        quantity = order_quantity[order_id]
        deadline = order_deadline[order_id]
        
        # Find minimum processing time across all machines that can produce this product
        min_processing_time = float('inf')
        for machine_id in range(production_rate.shape[0]):
            if production_rate[machine_id, product_id] > 0:  # Machine can produce this product
                processing_time = quantity / production_rate[machine_id, product_id]
                min_processing_time = min(min_processing_time, processing_time)
        
        if min_processing_time == float('inf'):
            continue  # No machine can produce this product
            
        # Calculate tightness ratio (processing time / remaining time)
        # Lower ratio means tighter deadline
        tightness_ratio = min_processing_time / max(deadline, 1e-6)
        
        if tightness_ratio >= min_tightness_threshold:
            order_tightness[order_id] = tightness_ratio
            feasible_orders.append(order_id)
    
    if not feasible_orders:
        # If no orders meet threshold, try all orders regardless of threshold
        for order_id in unfulfilled_orders:
            if avoid_recent_cycles and order_id in last_processed_orders:
                continue
                
            product_id = order_product[order_id]
            quantity = order_quantity[order_id]
            deadline = order_deadline[order_id]
            
            min_processing_time = float('inf')
            for machine_id in range(production_rate.shape[0]):
                if production_rate[machine_id, product_id] > 0:
                    processing_time = quantity / production_rate[machine_id, product_id]
                    min_processing_time = min(min_processing_time, processing_time)
            
            if min_processing_time != float('inf'):
                tightness_ratio = min_processing_time / max(deadline, 1e-6)
                order_tightness[order_id] = tightness_ratio
                feasible_orders.append(order_id)
    
    if not feasible_orders:
        return None, algorithm_data
    
    # Sort orders by tightness ratio (most critical first - lowest ratio)
    sorted_orders = sorted(feasible_orders, key=lambda x: order_tightness[x])
    
    # Try to insert the most critical orders first
    best_operator = None
    best_order_id = None
    
    for order_id in sorted_orders:
        attempts = 0
        product_id = order_product[order_id]
        
        # Try all production lines that can produce this product
        for machine_id in range(len(current_solution.production_schedule)):
            if production_rate[machine_id, product_id] <= 0:
                continue  # Machine cannot produce this product
                
            line_schedule = current_solution.production_schedule[machine_id]
            
            # Try all possible positions (including append at end)
            for position in range(len(line_schedule) + 1):
                if attempts >= max_attempts_per_order:
                    break
                    
                attempts += 1
                
                # Create new schedule with insertion
                new_schedule = line_schedule[:]
                if position == len(line_schedule):
                    new_schedule.append(order_id)
                else:
                    new_schedule.insert(position, order_id)
                
                # Validate the new schedule
                if validation_single_production_schedule(machine_id, new_schedule):
                    # Create appropriate operator
                    if position == len(line_schedule):
                        operator = AppendOperator(machine_id, order_id)
                    else:
                        operator = InsertOperator(machine_id, order_id, position)
                    
                    best_operator = operator
                    best_order_id = order_id
                    break
            
            if best_operator:
                break
        if best_operator:
            break
    
    # Update algorithm data with processed order
    if best_order_id is not None:
        last_processed_orders.append(best_order_id)
        # Maintain recent cycle window
        if len(last_processed_orders) > recent_cycle_window:
            last_processed_orders.pop(0)
        algorithm_data['last_processed_orders'] = last_processed_orders
    
    return best_operator, algorithm_data