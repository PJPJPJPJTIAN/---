from src.problems.tsp.components import *
import numpy as np

def nearest_neighbor_06cf(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[AppendOperator, dict]:
    """Nearest Neighbor heuristic for TSP with adaptive lookahead: Builds the tour by appending unvisited nodes, starting with an adaptive initial node based on Coefficient of Variation (CV) and subsequently using a lookahead score that balances immediate distance to the current endpoint with connectivity to the remaining unvisited nodes. For the initial empty tour: if CV < 0.6 (low variability), select the central node with minimal average distance to all others; else, select the node (excluding 0) closest to reference node 0 to avoid clusters. For non-empty tours, compute a score for each unvisited u: score(u) = dist(last_node, u) + beta * (mean_dist_unvisited - avg_dist(u, other_unvisited)), where avg_dist(u, other_unvisited) is the average distance from u to the other unvisited nodes (computed efficiently using row sums minus distances to visited); beta is first dynamically adjusted as base_beta * (1 / (1 + damping_strength * max(0, CV - 0.6))) with steeper decay (damping_strength=2.0 default) to reduce lookahead in high-variability instances, then further modulated in mid-to-late stages (unvisited <50% of total) by multiplying beta with a ramp-up factor from 1.0 (at 50%) to late_stage_boost (default 1.5 at near-complete) for stronger hub bias in smaller/more predictable subgraphs, but reverted (divided by boost_factor) if CV > cv_boost_threshold (default 0.6) to disable boosting in erratic cases and favor damped greedy; select the u minimizing this score to avoid local clusters by favoring balanced hubs. This extends pure nearest-neighbor to mitigate greedy traps, with CV damping, conditional late-stage boosting, and threshold control enhancing robustness across CV ranges and tour phases. Performs a single append per call (max_iterations=1 default), suitable for hyper-heuristics. Returns None, {} if tour complete (no unvisited), max_iterations <=0, only one unvisited (but still appends it via simple nearest if applicable), or validation fails post-selection. Ensures no revisits by selecting only from unvisited and validating the new solution.

    Hyper-parameters in kwargs (all with defaults):
        max_iterations (int, default=1): Number of append operations; fixed to 1 for single-step; if <=0, returns None, {} immediately.
        lookahead_beta (float, default=1.0): Base scale for the connectivity penalty in the lookahead score; dynamically adjusted by CV (reduced >0.6) and conditional late-stage boosting.
        cv_damping_strength (float, default=2.0): Steepness factor for CV-based beta decay; higher values (>2.0) emphasize greediness in sparse/irregular graphs (e.g., when Min Spanning Ratio <7).
        late_stage_boost (float, default=1.5): Maximum multiplier for beta in mid-to-late stages (unvisited <50% of node_num); ramps up lookahead influence (e.g., to 1.5x near completion) for better connectivity in smaller subgraphs, applied only if CV <= cv_boost_threshold; tunable (e.g., <1.0 if needed to avoid over-correction).
        cv_boost_threshold (float, default=0.6): Threshold for applying late-stage boost; if CV > threshold, revert to pre-boost beta to favor greedy in erratic graphs; hyper-heuristics can tune (e.g., lower to 0.5 for denser instances with Min Spanning Ratio >10) for phase-specific control.

    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - node_num (int): The total number of nodes in the problem (cities 0 to node_num-1).
            - distance_matrix (numpy.ndarray): A 2D symmetric array of non-negative distances between nodes (diagonal 0).
            - current_solution (Solution): Current partial tour as list of unique node IDs (valid, no duplicates).
            - validation_solution (callable): Function to validate a solution (checks no duplicates/invalid nodes); used post-append.
            - Coefficient of Variation of Distances (float): Normalized variability (std/mean of pairwise distances); used for adaptive initial selection and dynamic beta adjustment.
            - Mean Distance Among Unvisited Cities (float): Average pairwise distance in current unvisited set; used in lookahead penalty.
        algorithm_data (dict): Not required (can be empty); outputs updated data for tracking.

    Returns:
        AppendOperator: Instance appending the selected unvisited node, or None if no action needed/possible.
        dict: Updated with 'visited' (set of visited nodes post-append) and 'last_node' (new endpoint), or {} if no operator.
    """
    # Extract necessary problem state (never modify)
    node_num = problem_state['node_num']
    distance_matrix = problem_state['distance_matrix']
    current_solution = problem_state['current_solution']
    validation_solution = problem_state['validation_solution']
    cv = problem_state['Coefficient of Variation of Distances']
    mean_unvisited = problem_state['Mean Distance Among Unvisited Cities']
    tour = current_solution.tour  # Assumed valid partial tour

    # Hyper-parameters with defaults
    max_iterations = kwargs.get('max_iterations', 1)
    if max_iterations <= 0:
        return None, {}  # No iterations requested

    # Compute unvisited and visited
    visited_set = set(tour)
    unvisited = [i for i in range(node_num) if i not in visited_set]

    # Check if complete
    if not unvisited:
        return None, {}  # No operator needed

    # Precompute row sums for efficiency (sum of distances to all other nodes)
    row_sums = np.sum(distance_matrix, axis=1)

    # Select node based on tour state
    if len(tour) == 0:
        # Adaptive initial node selection
        if node_num <= 1:
            selected_node = 0
        else:
            avg_dists = row_sums / (node_num - 1)
            if cv < 0.6:
                # Low variability: central node (min avg distance)
                selected_node = np.argmin(avg_dists)
            else:
                # High variability: closest to reference 0 (among 1 to node_num-1)
                distances_from_0 = distance_matrix[0, 1:node_num]
                min_idx = np.argmin(distances_from_0)
                selected_node = min_idx + 1
        # Ensure unvisited (true for empty tour)
    else:
        # Non-empty: lookahead selection
        last_node = tour[-1]
        base_beta = kwargs.get('lookahead_beta', 1.0)
        # Dynamic beta adjustment based on CV
        cv_excess = max(0, cv - 0.6)
        damping_strength = kwargs.get('cv_damping_strength', 2.0)
        beta = base_beta * (1.0 / (1 + damping_strength * cv_excess))
        # Late-stage boost adjustment
        late_stage_boost = kwargs.get('late_stage_boost', 1.5)
        cv_boost_threshold = kwargs.get('cv_boost_threshold', 0.6)
        if len(unvisited) < node_num * 0.5:
            remaining_ratio = len(unvisited) / node_num
            boost_factor = 1.0 + (late_stage_boost - 1.0) * (1 - 2 * remaining_ratio)
            beta *= boost_factor
            if cv > cv_boost_threshold:
                beta /= boost_factor  # Revert boost in high-CV cases
        if len(unvisited) == 1:
            # Only one left: append it (simple nearest equivalent)
            selected_node = unvisited[0]
        else:
            # Compute scores for lookahead
            scores = []
            for u in unvisited:
                dist_to_u = distance_matrix[last_node, u]
                # Sum to visited (excluding u, as u unvisited)
                sum_to_visited = sum(distance_matrix[u, v] for v in visited_set)
                # Sum to other unvisited = total row sum - sum to visited
                sum_to_other_unvisited = row_sums[u] - sum_to_visited
                num_other = len(unvisited) - 1
                # Avoid division by zero (handled by len>1)
                avg_to_other = sum_to_other_unvisited / num_other if num_other > 0 else 0.0
                # Penalty: mean_unvisited - avg (penalizes low avg to avoid local clusters)
                penalty = mean_unvisited - avg_to_other
                score = dist_to_u + beta * penalty
                scores.append((score, u))
            # Select min score
            _, selected_node = min(scores)

    # Ensure selected is unvisited
    if selected_node in visited_set:
        return None, {}  # Rare failure; abort

    # Create and validate new solution
    operator = AppendOperator(selected_node)
    new_tour = tour + [selected_node]
    new_solution = Solution(new_tour)
    if not validation_solution(new_solution):
        return None, {}  # Validation failed (e.g., duplicate); abort

    # Update algorithm data (fresh dict)
    updated_data = {
        'visited': visited_set | {selected_node},
        'last_node': selected_node
    }

    # Single step complete
    return operator, updated_data