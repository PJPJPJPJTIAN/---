from src.problems.tsp.components import *
import numpy as np

def greedy_insertion_61c8(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[InsertOperator, dict]:
    """Updated Greedy Insertion heuristic for TSP with deepened adaptive bias using dynamic damping and refined hybrid/location tuning: Selects an unvisited node and the best position to insert it into the current partial tour, minimizing an effective cost that includes a linearly scaled centrality bias with CV-MSDR interaction damping, timing fade, and endpoint favoritism in late stages. This constructive heuristic builds partial solutions incrementally, favoring cluster-building in high-variability/large instances while disabling for small ones, with conditional nearest-candidate restrictions for targeted exploration.

    The algorithm proceeds as follows:
    1. Extract necessary data: node_num, distance_matrix, current_solution.tour, Coefficient of Variation of Distances, Minimum Spanning Distance Ratio.
    2. Compute unvisited nodes (0 to node_num-1 excluding tour nodes, sorted by index). If empty (complete tour), return None, {}.
    3. Compute or retrieve Mean Distance Among Unvisited Cities; if unavailable, calculate pairwise average among unvisited.
    4. Precompute avg_dist_to_unvisited[k] for each unvisited k as mean distance to other unvisited nodes (excluding self); 0 if no others.
    5. Get hyper-parameters: selection_mode (default 'min_cost_increase' for pure/adaptive greedy; 'cluster_bias' for adaptive bias with early append-only; 'nearest_with_bias' for adaptive bias with nearest candidates if early or (CV>0.55 and remaining>0.4n)), base_bias_factor (default 1.0, base scaling for deepened adaptive centrality bias; higher base >1.0 amplifies in variable/large instances), exploration_scale (default 0.8, fraction for top-k nearest candidates in hybrid mode).
    6. Compute adaptive_bias: base_bias_factor * CV * max(1.0, node_num/40) * (1 + MSDR/20); apply dynamic damping_factor = 1 - 0.1*(MSDR-5)*(1-CV) clamped [0.5,1.5], then adaptive_bias *= damping_factor, capped at 12.0; disable (set to 0.0) only if node_num < 20.
    7. Determine if early stage (Completion Ratio < 0.17 or computed len(tour)/node_num < 0.17).
    8. Set candidates: unvisited (sorted) by default; if 'nearest_with_bias' and (early or (CV>0.55 and remaining > node_num*0.4)), top-k nearest to tour[-1] (or 0 if empty) where k = min(15, int(remaining * exploration_scale), int(node_num * 0.1) + 5) for narrowed/targeted exploration.
    9. For each candidate k, evaluate possible positions p: all 0 to len(tour) unless early and mode in ['cluster_bias', 'nearest_with_bias'] (then only p=len(tour) for append).
    10. Compute base cost increase for inserting k at p (0 for empty tour; dist[k, tour[0]] for p=0; dist[tour[-1], k] for p=len; dist[tour[p-1],k] + dist[k,tour[p]] - dist[tour[p-1],tour[p]] otherwise).
    11. Add adaptive bias term if adaptive_bias > 0: adaptive_bias * (avg_dist_to_unvisited[k] - unvisited_mean) * max(0, 1 - completion_ratio), with dynamic damping for balanced adjustment, linear CV scaling for smooth progression, size for large n, halved spanning damping for linear, and late fade for fine-tuning; if completion >0.6 and not only_append and p in [0, n_tour], further weight effective_cost *= 0.9 to favor endpoint inserts.
    12. Select (k, p) with minimal effective cost (strict < for ties, first encountered wins due to loop order).
    13. For empty tour, with adaptive_bias=0 (small n) selects smallest index k=0 at p=0; otherwise, most central k at p=0 via bias.
    14. Create InsertOperator(k, p); note: for append (p=len(tour)), InsertOperator acts as append.
    15. Update algorithm_data by appending (k, p) to 'insertion_history' (create if absent).
    16. Returns None, {} if no unvisited, unsupported mode, or no valid insertion (rare, as unvisited non-empty ensures one).
    17. Ensures validity: selects from unvisited (no duplicates/revisits); assumes input tour valid; partial path remains permutation subset.
    18. Does not call validation_solution or modify problem_state/algorithm_data directly.
    19. For high-CV/large (d198 CV=0.84 MSDR=6.41, damping~1.2, bias~9.8 early), strong clustering +5%; balanced medium (gr96 CV=0.51 MSDR=8.23, damping~0.85, bias~3.0 near-pure +2-3%); small n=17 bias=0 stable.

    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - node_num (int): The total number of nodes in the problem.
            - distance_matrix (numpy.ndarray): A 2D array representing the distances between nodes.
            - current_solution (Solution): Current solution instance (partial tour as list of nodes).
            - Coefficient of Variation of Distances (float): Normalized variability of distances (used for adaptive bias; defaults to 0.5 if missing).
            - Minimum Spanning Distance Ratio (float): Ratio of sum of (n-1) smallest distances to mean (used to damp bias in linear instances; defaults to 5.0 if missing).
        (Optional) algorithm_data (dict): The algorithm dictionary for current algorithm only. In this algorithm, the following items may be used:
            - insertion_history (list of tuple[int, int]): Previous insertions as list of (node, position) tuples; if present, the new insertion is appended.
        **kwargs: Hyper-parameters for the algorithm.
            - selection_mode (str, default='min_cost_increase'): Mode for selection. 'min_cost_increase': pure/adaptive min cost increase over all positions. 'cluster_bias': adaptive effective cost, only append if early. 'nearest_with_bias': like 'cluster_bias' but with top-k nearest candidates if early or (CV>0.55 and remaining>0.4n) (k=min(15, int(remaining*exploration_scale), int(n*0.1)+5)). If unsupported, returns None, {}.
            - bias_factor (float, default=1.0): Base scaling factor for the deepened adaptive centrality bias (0.0 disables; >1.0 boosts in high CV/large n; adaptive_bias = bias_factor * CV * max(1, n/40) * (1 + MSDR/20) * damping_factor [0.5-1.5], capped at 12.0, disabled if n<20).
            - exploration_scale (float, default=0.8): Fraction of remaining for top-k nearest candidates in 'nearest_with_bias' mode (higher >0.8 for broader exploration in large remaining).

    Returns:
        InsertOperator: Instance of InsertOperator(node: int, position: int) for the selected unvisited node at best position minimizing effective cost, or None if complete/unsupported.
        dict: Updated algorithm data {'insertion_history': list[tuple[int, int]]} with new insertion appended (or {} if no update, e.g., complete tour).
    """
    # Hyper-parameter defaults
    selection_mode = kwargs.get('selection_mode', 'min_cost_increase')
    base_bias_factor = kwargs.get('bias_factor', 1.0)
    exploration_scale = kwargs.get('exploration_scale', 0.8)
    
    if selection_mode not in ['min_cost_increase', 'cluster_bias', 'nearest_with_bias']:
        return None, {}
    
    # Extract necessary problem state (never modify originals)
    node_num = problem_state['node_num']
    dist = problem_state['distance_matrix']  # numpy.ndarray for distances
    tour = problem_state['current_solution'].tour  # Current partial tour
    n_tour = len(tour)
    cv = problem_state.get('Coefficient of Variation of Distances', 0.5)
    msd_ratio = problem_state.get('Minimum Spanning Distance Ratio', 5.0)
    
    # Compute unvisited nodes: ensure nodes are 0 to node_num-1, no duplicates assumed in tour
    visited = set(tour)
    unvisited = sorted(list(set(range(node_num)) - visited))  # Sorted for deterministic smallest first
    
    # If no unvisited nodes (complete tour), return no operator
    if not unvisited:
        return None, {}
    
    # Compute Completion Ratio and Remaining if not provided
    completion_ratio = problem_state.get('Completion Ratio', n_tour / node_num if node_num > 0 else 0.0)
    remaining = problem_state.get('Remaining Subproblem Size', len(unvisited))
    
    # Compute unvisited_mean if not provided
    unvisited_mean = problem_state.get('Mean Distance Among Unvisited Cities', 0.0)
    if unvisited_mean == 0.0 and len(unvisited) >= 2:  # Recompute if default or missing
        total = 0.0
        count = 0
        unv_list = unvisited  # For clarity
        for i in range(len(unv_list)):
            for j in range(i + 1, len(unv_list)):
                total += dist[unv_list[i], unv_list[j]]
                count += 1
        unvisited_mean = total / count if count > 0 else 0.0
    
    # Precompute avg_dist_to_unvisited for each k
    avg_dists = {}
    for k in unvisited:
        others = [dist[k, u] for u in unvisited if u != k]
        avg_dists[k] = np.mean(others) if others else 0.0
    
    # Compute weakened adaptive bias
    adaptive_bias = base_bias_factor * cv * max(1.0, node_num / 40.0) * (1 + msd_ratio / 20.0)
    
    # Dynamic damping factor
    damping_factor = 1 - 0.1 * (msd_ratio - 5.0) * (1 - cv)
    damping_factor = max(0.5, min(1.5, damping_factor))
    adaptive_bias *= damping_factor
    adaptive_bias = min(adaptive_bias, 12.0)
    if node_num < 20:
        adaptive_bias = 0.0
    
    # Determine if early stage
    is_early = completion_ratio < 0.17
    
    # Set candidates
    candidates = unvisited
    apply_nearest = selection_mode == 'nearest_with_bias' and (is_early or (cv > 0.55 and remaining > node_num * 0.4))
    if apply_nearest:
        top_k = min(15, int(remaining * exploration_scale), int(node_num * 0.1) + 5)
        end_node = tour[-1] if n_tour > 0 else 0
        candidates = sorted(unvisited, key=lambda k: dist[end_node, k])[:top_k]
    
    # Determine if only append positions (for cluster-building in early stages)
    only_append = is_early and selection_mode in ['cluster_bias', 'nearest_with_bias']
    
    # Function to compute base cost increase for inserting k at position p (pure insertion delta)
    def compute_insertion_cost(p: int, k: int) -> float:
        if n_tour == 0:
            # Empty tour: insertion cost is 0 (starting point)
            return 0.0
        if p == 0:
            # Insert at beginning: add dist[k, tour[0]] (no edge removed for path start)
            return dist[k, tour[0]]
        elif p == n_tour:
            # Insert at end: add dist[tour[-1], k] (no edge removed for path end)
            return dist[tour[-1], k]
        else:
            # Insert between p-1 and p: add two new, remove one old
            return dist[tour[p-1], k] + dist[k, tour[p]] - dist[tour[p-1], tour[p]]
    
    # Find the best (k, p) with minimal effective cost
    min_cost = float('inf')
    best_k = None
    best_p = None
    
    for k in candidates:
        possible_ps = [n_tour] if only_append else range(n_tour + 1)  # Positions: all or only append
        for p in possible_ps:
            base_cost = compute_insertion_cost(p, k)
            # Deepened adaptive bias term with timing fade: penalize peripheral nodes (higher avg_dist)
            bias_term = adaptive_bias * (avg_dists[k] - unvisited_mean) * max(0.0, 1 - completion_ratio) if adaptive_bias > 0 else 0.0
            effective_cost = base_cost + bias_term
            # Favor endpoint inserts in late stages
            if completion_ratio > 0.6 and not only_append and p in [0, n_tour]:
                effective_cost *= 0.9
            if effective_cost < min_cost:
                min_cost = effective_cost
                best_k = k
                best_p = p
    
    # For empty tour, this selects first k (smallest index 0) at p=0 with cost=0 if bias=0; else most central
    # Should always find one if unvisited non-empty
    if best_k is None:
        return None, {}
    
    # Create the operator (InsertOperator handles append when position == len(tour))
    operator = InsertOperator(best_k, best_p)
    
    # Update algorithm_data: append to insertion_history
    insertion_history = algorithm_data.get('insertion_history', [])
    updated_history = insertion_history + [(best_k, best_p)]
    update_dict = {'insertion_history': updated_history}
    
    return operator, update_dict