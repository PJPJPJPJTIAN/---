from src.problems.tsp.components import *
import random

def random_append_79cf(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[AppendOperator, dict]:
    """Randomly selects and appends an unvisited node to the tour for TSP construction.

    This heuristic is a constructive method suitable for building partial tours from scratch or extending existing ones.
    It randomly chooses one unvisited node (ensuring no revisits) from the available unvisited nodes and appends it to the end of the current tour.
    If the current solution is empty (no cities visited), it selects any random node as the starting point.
    The algorithm ensures validity by only selecting from unvisited nodes, preventing duplicates in the tour.
    For reproducibility across runs, it uses or sets a random seed stored in algorithm_data.

    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - node_num (int): The total number of nodes in the problem, used to generate the full set of possible nodes (0 to node_num-1).
            - current_solution (Solution): Current solution instance, used to determine visited nodes from its tour list.
        algorithm_data (dict): The algorithm dictionary for current algorithm only. In this algorithm, the following items are optional but used for reproducibility:
            - random_seed (int): A seed value for the random number generator; if not provided, a new random integer seed is generated and used.
        **kwargs: Hyper-parameters for the algorithm with default values.
            - unvisited_pool_size (int): The maximum number of unvisited nodes to consider for random selection (default: problem_state['node_num'], meaning the full unvisited set is used).
                If the actual number of unvisited nodes is smaller, the full set is used. This allows limiting the pool for controlled randomness in larger instances.

    Returns:
        AppendOperator: An instance of AppendOperator with the randomly selected unvisited node to append to the tour.
            If there are no unvisited nodes (tour is complete), returns None instead of an operator.
        dict: Updated algorithm data containing:
            - 'random_seed' (int): The seed used for random selection, ensuring reproducibility.
            If no operator is returned (tour complete), returns {} for algorithm data.

    The workflow is:
    1. Extract node_num and current_solution from problem_state.
    2. Compute the set of visited nodes from current_solution.tour.
    3. Generate the list of unvisited nodes (all nodes 0 to node_num-1 minus visited).
    4. If unvisited list is empty, return None, {} (no action possible, tour complete).
    5. Get unvisited_pool_size from kwargs, defaulting to node_num; limit the pool size to min(unvisited_pool_size, len(unvisited)).
    6. If pool size > 0, randomly sample or shuffle to select from the limited pool if needed; pick one random node using random.choice.
    7. Retrieve or generate random_seed from/to algorithm_data for seeding random; apply random.seed(random_seed).
    8. Create and return AppendOperator(selected_node), {'random_seed': random_seed}.
    This ensures the new tour will be valid (no duplicates, proper append) and can be validated externally using problem_state['validation_solution'] if needed.
    """
    # Step 1: Extract necessary items from problem_state
    node_num = problem_state['node_num']
    current_tour = problem_state['current_solution'].tour

    # Step 2: Compute visited nodes to avoid revisits
    visited = set(current_tour)

    # Step 3: Generate list of unvisited nodes (assuming nodes are 0 to node_num-1)
    unvisited = [i for i in range(node_num) if i not in visited]

    # Step 4: Check if any unvisited nodes remain; if not, tour is complete, no operator
    if not unvisited:
        return None, {}

    # Step 5: Get hyper-parameter unvisited_pool_size with default
    unvisited_pool_size = kwargs.get('unvisited_pool_size', node_num)
    # Limit to actual unvisited size
    pool_size = min(unvisited_pool_size, len(unvisited))

    # Step 6: Prepare the pool for selection (sample if pool_size < len(unvisited) for efficiency/randomness)
    if pool_size < len(unvisited):
        # Randomly sample a subset for selection
        selection_pool = random.sample(unvisited, pool_size)
    else:
        # Use all unvisited
        selection_pool = unvisited[:]

    # Step 7: Handle random seed for reproducibility from algorithm_data or generate new
    random_seed = algorithm_data.get('random_seed', random.randint(1, 100000))
    random.seed(random_seed)

    # Step 8: Select a random node from the pool
    selected_node = random.choice(selection_pool)

    # Step 9: Create operator and update algorithm data
    operator = AppendOperator(selected_node)
    updated_data = {'random_seed': random_seed}

    return operator, updated_data