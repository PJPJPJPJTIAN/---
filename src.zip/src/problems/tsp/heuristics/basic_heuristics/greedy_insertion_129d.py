from src.problems.tsp.components import *
import numpy as np

def greedy_insertion_129d(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[InsertOperator, dict]:
    """Greedy Insertion heuristic for TSP: Selects an unvisited node and the best position to insert it into the current partial tour such that the increase in total tour cost is minimized. This is a constructive heuristic suitable for building partial solutions incrementally.

    This algorithm proceeds as follows:
    1. Extract necessary data from problem_state: node_num, distance_matrix, current_solution.
    2. Compute the set of unvisited nodes (nodes 0 to node_num-1 not in current_solution.tour). If no unvisited nodes (tour is complete), return None, {}.
    3. If the current tour is empty, select the smallest-index unvisited node and insert it at position 0 (starting the tour).
    4. Otherwise, for each unvisited node k and each possible insertion position p (0 to len(tour)), compute the cost increase of inserting k at p:
       - If p == 0 and tour non-empty: dist[k, tour[0]]
       - If p == len(tour): dist[tour[-1], k]
       - Else: dist[tour[p-1], k] + dist[k, tour[p]] - dist[tour[p-1], tour[p]]
       - For empty tour, cost increase is 0.
    5. Select the (k, p) pair with the minimum cost increase. If multiple, the one encountered first (due to sorted unvisited) is chosen.
    6. Create an InsertOperator with the selected node and position.
    7. Update algorithm_data by appending the insertion (node, position) to the 'insertion_history' list if it exists, or starting a new list.
    8. The returned operator, when applied, will produce a valid solution (no revisits, as unvisited is enforced). No validation_solution call is made here, assuming input is valid.
    9. Hyper-parameters:
       - selection_mode (str, default='min_cost_increase'): Determines how to select the insertion. Currently, only 'min_cost_increase' is implemented, which selects the globally minimal cost increase. If another mode is provided, returns None, {} to indicate unsupported.
    10. This algorithm does not modify problem_state or algorithm_data directly. It handles empty solutions and ensures the result is valid for TSP (permutation without revisits).
    11. If the tour is complete (remaining_subproblem_size == 0 or computed unvisited empty), or unsupported selection_mode, returns None, {} (no operator).

    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - node_num (int): The total number of nodes in the problem.
            - distance_matrix (numpy.ndarray): A 2D array representing the distances between nodes.
            - current_solution (Solution): Current solution instance (partial tour as list of nodes).
        algorithm_data (dict): The algorithm dictionary for current algorithm only. Optional. In this algorithm, the following items may be used:
            - insertion_history (list of tuple[int, int]): Previous insertions as list of (node, position) tuples; if present, the new insertion is appended.
        **kwargs: Hyper-parameters for the algorithm.
            - selection_mode (str): Mode for selecting the insertion point and node. Default: 'min_cost_increase'.

    Returns:
        InsertOperator: An instance of InsertOperator(node: int, position: int) to insert the selected unvisited node at the optimal position, minimizing cost increase. The new solution will be valid (no duplicates, proper TSP partial tour).
        dict: Updated algorithm data as {'insertion_history': list[tuple[int, int]]}, containing the accumulated history with the new insertion appended. If no history existed, starts a new list with the current insertion. Empty dict {} if no updates or no insertion performed.
    """
    # Hyper-parameter defaults
    selection_mode = kwargs.get('selection_mode', 'min_cost_increase')
    
    # Extract necessary problem state (never modify originals)
    node_num = problem_state['node_num']
    dist = problem_state['distance_matrix']  # numpy.ndarray for distances
    tour = problem_state['current_solution'].tour  # Current partial tour
    n_tour = len(tour)
    
    # Compute unvisited nodes: ensure nodes are 0 to node_num-1, no duplicates assumed in tour
    visited = set(tour)
    unvisited = sorted(list(set(range(node_num)) - visited))  # Sorted for deterministic smallest first
    
    # If no unvisited nodes (complete tour), return no operator
    if not unvisited:
        return None, {}
    
    # Check selection mode; only 'min_cost_increase' supported
    if selection_mode != 'min_cost_increase':
        return None, {}
    
    # Function to compute cost increase for inserting k at position p
    def compute_insertion_cost(p: int, k: int) -> float:
        if n_tour == 0:
            # Empty tour: insertion cost is 0 (starting point)
            return 0.0
        if p == 0:
            # Insert at beginning: add dist[k, tour[0]]
            return dist[k, tour[0]]
        elif p == n_tour:
            # Insert at end: add dist[tour[-1], k]
            return dist[tour[-1], k]
        else:
            # Insert between p-1 and p: dist[tour[p-1], k] + dist[k, tour[p]] - dist[tour[p-1], tour[p]]
            return dist[tour[p-1], k] + dist[k, tour[p]] - dist[tour[p-1], tour[p]]
    
    # Find the best (k, p) with minimal cost increase
    min_cost = float('inf')
    best_k = None
    best_p = None
    
    for k in unvisited:
        for p in range(n_tour + 1):  # Positions 0 to n_tour inclusive
            cost_increase = compute_insertion_cost(p, k)
            if cost_increase < min_cost:
                min_cost = cost_increase
                best_k = k
                best_p = p
    
    # For empty tour, this will set best_k to smallest unvisited (0), best_p=0, min_cost=0
    # Should always find one if unvisited non-empty
    if best_k is None:
        return None, {}
    
    # Create the operator
    operator = InsertOperator(best_k, best_p)
    
    # Update algorithm_data: append to insertion_history
    insertion_history = algorithm_data.get('insertion_history', [])
    updated_history = insertion_history + [(best_k, best_p)]
    update_dict = {'insertion_history': updated_history}
    
    return operator, update_dict