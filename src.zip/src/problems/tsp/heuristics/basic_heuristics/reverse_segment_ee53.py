from src.problems.tsp.components import *

def reverse_segment_ee53(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[ReverseSegmentOperator, dict]:
    """Reverses a single segment of the current tour to potentially reduce the total path cost, inspired by local search methods like 3-opt or Lin-Kernighan. This heuristic evaluates possible reversals within a specified length range and selects the one that provides the maximum cost improvement (most negative delta). If no improving reversal is found, it returns None to indicate no operator should be applied.

    The algorithm proceeds as follows:
    1. Extract the current tour from problem_state['current_solution'].
    2. If the tour has fewer than 2 nodes, no reversal is possible, so return None, {}.
    3. Compute the cost delta for each possible segment reversal:
       - For a segment from index i to j (inclusive), the delta accounts for changes in connecting edges:
         - If i > 0, subtract dist(tour[i-1], tour[i]) and add dist(tour[i-1], tour[j]).
         - If j+1 < len(tour), subtract dist(tour[j], tour[j+1]) and add dist(tour[i], tour[j+1]).
       - Only consider segments where the length (j - i + 1) is between min_length and max_length from segment_length_range.
    4. Track the segment with the minimum (most negative) delta.
    5. If the best delta is negative (improving), create a ReverseSegmentOperator with that single segment and return it along with a dict containing the improvement value and segment details.
    6. If no improving segment is found (best delta >= 0), return None, {}.
    7. The resulting operator, when applied, will produce a valid solution (reordering preserves uniqueness and no revisits, assuming input is valid). No direct validation is performed here, but the operator ensures the tour remains a permutation of the original nodes.

    Hyper-parameters in kwargs (with defaults):
    - segment_length_range (tuple[int, int]): The minimum and maximum length of segments to consider for reversal. Default: (2, 10). If the current tour length is shorter than the minimum, no operator is returned.

    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - distance_matrix (numpy.ndarray): A 2D array representing the distances between nodes, used to compute cost deltas for potential reversals.
            - current_solution (Solution): Current solution instance, providing the tour list to evaluate for segment reversals.
        algorithm_data (dict): The algorithm dictionary for current algorithm only. This algorithm does not require any specific keys from algorithm_data and ignores it.

    Returns:
        tuple[ReverseSegmentOperator or None, dict]: The operator to reverse the best improving segment, or None if no improvement is possible. The second element is a dict with reversal stats: {"improvement": float (negative cost reduction), "segment": tuple[int, int] (start and end indices)}, or {} if no operator.
    """
    # Extract necessary data from problem_state (never modify original)
    distance_matrix = problem_state['distance_matrix']
    current_solution = problem_state['current_solution']
    tour = list(current_solution.tour)  # Copy to avoid modifying original
    n = len(tour)

    # Hyper-parameter with default
    segment_length_range = kwargs.get('segment_length_range', (2, 10))
    min_length, max_length = segment_length_range

    # If tour is too short for any reversal, return None
    if n < min_length:
        return None, {}

    # Find the best improving segment
    best_delta = 0.0  # Non-improving default
    best_segment = None

    for i in range(n):
        for j in range(i + min_length - 1, min(i + max_length, n)):
            # Compute delta for reversing i to j
            delta = 0.0

            # Left connection change if i > 0
            if i > 0:
                prev_node = tour[i - 1]
                old_left = distance_matrix[prev_node, tour[i]]
                new_left = distance_matrix[prev_node, tour[j]]
                delta += new_left - old_left

            # Right connection change if j + 1 < n
            if j + 1 < n:
                next_node = tour[j + 1]
                old_right = distance_matrix[tour[j], next_node]
                new_right = distance_matrix[tour[i], next_node]
                delta += new_right - old_right

            # Track if this is the best improvement (most negative delta)
            if delta < best_delta:
                best_delta = delta
                best_segment = (i, j)

    # If an improving reversal is found (delta < 0), return the operator and stats
    if best_delta < 0:
        operator = ReverseSegmentOperator(segments=[best_segment])
        stats = {
            "improvement": best_delta,
            "segment": best_segment
        }
        return operator, stats

    # No improvement possible
    return None, {}