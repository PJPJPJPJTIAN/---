from src.problems.tsp.components import Solution, AppendOperator
import random

def random_80a0(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[AppendOperator, dict]:
    """ Implements the random append heuristic for the TSP problem. 
    At each step, randomly select an unvisited node and append it to the current solution.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - node_num (int): The total number of nodes in the problem.
            - current_solution (Solution): Current solution instance containing the tour.
            - Remaining Subproblem Size (int): The number of unvisited cities.
    
    Returns:
        AppendOperator: An operator that appends the selected node to the current solution.
        dict: The updated algorithm dictionary. In this case, it is empty as no additional data is required for future iterations.
    """
    
    # Check if there are remaining cities to visit
    remaining_cities = problem_state.get("Remaining Subproblem Size", 0)
    if remaining_cities == 0:
        return None, {}
    
    # Get total number of nodes and current tour  
    total_nodes = problem_state.get("node_num") or problem_state.get("Number of Cities")
    current_tour = problem_state["current_solution"].tour
    
    # Calculate unvisited nodes
    visited_set = set(current_tour)
    unvisited_nodes = [i for i in range(total_nodes) if i not in visited_set]
    
    # Double check - if no unvisited nodes, return None
    if not unvisited_nodes:
        return None, {}
    
    # Randomly select an unvisited node
    selected_node = random.choice(unvisited_nodes)
    
    # Create an AppendOperator with the selected node
    operator = AppendOperator(node=selected_node)
    
    return operator, {}