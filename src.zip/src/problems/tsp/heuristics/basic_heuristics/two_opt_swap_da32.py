from src.problems.tsp.components import *
def two_opt_swap_da32(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[SwapOperator, dict]:
    """Implements a simplified 2-opt inspired heuristic using node swaps to improve the tour by finding and applying a single pair of nodes whose position swap reduces the total path cost. This is a local search improvement step suitable for both partial and complete tours. It selects the best improving swap (if any) based on recalculating the cost after the swap. The algorithm proceeds by iterating over all unique pairs of positions in the current tour, simulating the swap to compute the new cost, and selecting the pair that yields the largest cost reduction (delta < 0). If no improving swap is found or the tour is too short (fewer than 2 nodes), it returns None and an empty dict, indicating no operator to apply. The result is ensured to be valid by checking with validation_solution after simulation. This heuristic does not modify the input problem_state or algorithm_data directly.

    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - distance_matrix (numpy.ndarray): A 2D array representing the distances between nodes, used to compute tour costs.
            - current_solution (Solution): Current solution instance, providing the tour list to evaluate swaps on.
            - current_cost (int or float): The total cost of the current solution, used as baseline for improvement check.
            - node_num (int): The total number of nodes in the problem, used to determine if the solution is complete.
            - validation_solution (callable): def validation_solution(solution: Solution) -> bool: The function to check whether the solution is valid, used to verify the swapped solution.
        algorithm_data (dict): The algorithm dictionary for current algorithm only. Optional. In this algorithm, the following items may be used:
            - improvement_count (int): Cumulative count of improvements made by this heuristic across invocations.
        **kwargs: Hyper-parameters for the algorithm.
            - max_swaps (int, default=1): The maximum number of swaps to perform in this invocation. Currently, only 1 is supported; higher values are treated as 1 for single-step operation.

    Returns:
        tuple[SwapOperator or None, dict]: Returns a SwapOperator instance with a single swap pair (node_a, node_b) if an improving swap is found and valid, along with updated algorithm_data incrementing 'improvement_count'. If no improving swap exists, the tour has fewer than 2 nodes, or the swap would invalidate the solution, returns (None, {}).
    """
    # Extract necessary data from problem_state; do not modify inputs
    distance_matrix = problem_state['distance_matrix']
    solution = problem_state['current_solution']
    tour = solution.tour  # list[int], the current tour/path
    current_cost = problem_state['current_cost']
    node_num = problem_state['node_num']
    validate_sol = problem_state['validation_solution']

    # Determine if complete tour based on length vs total nodes
    n = len(tour)
    is_complete = (n == node_num)

    # Hyper-parameter with default
    max_swaps = kwargs.get('max_swaps', 1)
    # Limit to 1 for this single-step implementation
    effective_swaps = min(max_swaps, 1)

    # Helper function to compute the total cost of a tour (path for partial, cycle for complete)
    def compute_cost(tour_list, dist_mat, complete_flag):
        n = len(tour_list)
        if n < 2:
            return 0.0
        cost = 0.0
        for i in range(n - 1 if not complete_flag else n):
            next_i = (i + 1) % n if complete_flag else i + 1
            cost += dist_mat[tour_list[i]][tour_list[next_i]]
        return cost

    # If tour too short, cannot swap; return None
    if n < 2:
        return None, {}

    # Recompute current cost for accurate delta (in case provided current_cost mismatches)
    computed_current = compute_cost(tour, distance_matrix, is_complete)

    # Find the best improving swap: iterate all pairs of positions i < j
    best_delta = 0.0
    best_pair = None
    for i in range(n):
        for j in range(i + 1, n):
            # Simulate the swapped tour without modifying original (swap positions i and j)
            temp_tour = tour[:i] + [tour[j]] + tour[i + 1:j] + [tour[i]] + tour[j + 1:]
            # Compute new cost
            new_cost = compute_cost(temp_tour, distance_matrix, is_complete)
            delta = new_cost - computed_current
            # Create temp solution to validate
            temp_solution = Solution(temp_tour)
            is_valid = validate_sol(temp_solution)
            # Select if improves (delta < 0) and valid; track best (most negative delta)
            if is_valid and delta < best_delta:
                best_delta = delta
                best_pair = (tour[i], tour[j])  # Original nodes at positions i and j

    # If found an improving swap and effective_swaps >=1, create operator
    if best_pair is not None and best_delta < 0 and effective_swaps >= 1:
        operator = SwapOperator([best_pair])
        # Update algorithm_data: copy and increment improvement_count
        updated_data = algorithm_data.copy()
        updated_data['improvement_count'] = updated_data.get('improvement_count', 0) + 1
        return operator, updated_data

    # No improvement or invalid cases: return None and empty dict
    return None, {}