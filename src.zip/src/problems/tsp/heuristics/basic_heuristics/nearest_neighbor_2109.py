from src.problems.tsp.components import *
import numpy as np

def nearest_neighbor_2109(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[AppendOperator, dict]:
    """Nearest Neighbor heuristic for TSP: Appends the unvisited node closest to the current endpoint of the partial tour using the distance matrix. For an empty tour, it starts by appending node 0 as the initial city. This is a constructive heuristic that builds the tour step-by-step by greedily choosing the nearest unvisited neighbor. It performs a single append operation per call (max_iterations=1 by default), suitable for hyper-heuristic selection. If the tour is already complete (no unvisited nodes), it returns None, {} to indicate no further action is needed.

    Hyper-parameters:
        max_iterations (int, default=1): Number of append operations to perform. Currently fixed to 1 for single-step operation in hyper-heuristic context; higher values are not implemented in this basic version.

    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - node_num (int): The total number of nodes in the problem (cities labeled 0 to node_num-1).
            - distance_matrix (numpy.ndarray): A 2D array representing the distances between nodes (symmetric, non-negative).
            - current_solution (Solution): Current solution instance holding the partial tour as a list of node integers.
            - validation_solution (callable): def validation_solution(solution: Solution) -> bool: The function to check whether the solution is valid (used post-construction to ensure no duplicates or invalid nodes).
        algorithm_data (dict): The algorithm dictionary for current algorithm only. In this algorithm, no prior items are necessary (can be empty); it initializes and updates with visited tracking.

    Returns:
        AppendOperator: An instance of AppendOperator with the selected unvisited node to append, creating a new partial tour.
        dict: Updated algorithm data containing:
            - 'visited' (set[int]): Set of all visited nodes after the append (includes the new node).
            - 'last_node' (int): The node ID of the newly appended node (serves as the new endpoint for future steps).
        If the tour is complete (remaining_subproblem_size == 0 or no unvisited nodes), returns (None, {}) to signal termination.
    """
    # Extract necessary problem state (never modify originals)
    node_num = problem_state['node_num']
    distance_matrix = problem_state['distance_matrix']
    current_solution = problem_state['current_solution']
    validation_solution = problem_state['validation_solution']
    tour = current_solution.tour  # Current partial tour (list of unique node IDs, no duplicates assumed)

    # Hyper-parameter defaults (all kwargs get defaults; only max_iterations defined, fixed to 1)
    max_iterations = kwargs.get('max_iterations', 1)

    # Compute unvisited nodes: all nodes 0 to node_num-1 not in current tour
    visited_set = set(tour)
    unvisited = [i for i in range(node_num) if i not in visited_set]
    
    # Check if tour is complete (no unvisited nodes left)
    if not unvisited:
        # No operator needed; tour is complete
        return None, {}
    
    # For single step (max_iterations=1), select one node to append
    if len(tour) == 0:
        # Handle empty solution: start with node 0 (deterministic choice; assumes nodes 0 to node_num-1)
        # All nodes are unvisited, so node 0 is valid
        selected_node = 0
    else:
        # Non-empty tour: find unvisited node closest to the current endpoint (last node in tour)
        last_node = tour[-1]
        # Compute distances to unvisited nodes (exclude self, but since unvisited != last_node, safe)
        # Handle empty unvisited check already done above
        distances_to_unvisited = [distance_matrix[last_node, u] for u in unvisited]
        # Find index of minimum distance (use np.argmin for efficiency on numpy array)
        min_distance_idx = np.argmin(distances_to_unvisited)
        selected_node = unvisited[min_distance_idx]
    
    # Create the operator: Append the selected unvisited node
    operator = AppendOperator(selected_node)
    
    # Validate the new conceptual solution (without actually creating it, but check logic)
    # New tour would be tour + [selected_node]; ensure no revisit (by construction, selected_node unvisited)
    new_tour = tour + [selected_node]
    new_solution = Solution(new_tour)
    if not validation_solution(new_solution):
        # Rare case: validation fails (e.g., invalid node), abort
        return None, {}
    
    # Update algorithm_data: compute new visited set and last node (do not modify input algorithm_data)
    updated_data = {
        'visited': visited_set | {selected_node},  # Union with new node
        'last_node': selected_node  # New endpoint for next iteration
    }
    
    # Since max_iterations=1, perform only this single step
    return operator, updated_data