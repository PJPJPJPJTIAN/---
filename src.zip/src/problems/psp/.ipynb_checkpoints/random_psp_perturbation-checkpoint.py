from src.problems.psp.components import *
import random
import copy
import numpy as np

def random_psp_perturbation(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[CompleteVesselAssignmentOperator, dict]:
    """
    RandomFeasible_Insertion heuristic: Randomly selects an unassigned vessel and attempts to insert it into the schedule
    by sampling compatible berths, start times within the vessel's time window, and compatible tugboats for inbound and
    outbound services. Availability is checked using provided callables, and timing sequences are respected by
    constructing start times with random gaps within the time tolerance. Retries up to max_attempts times to find a
    feasible complete assignment. The result is validated on a temporary solution copy to ensure full compliance with
    all constraints. This heuristic builds partial solutions incrementally and works on any partial solution, including
    empty ones.

    Hyper-parameters in kwargs:
    - max_attempts (int, default=10): Maximum number of sampling attempts to find a feasible assignment for the selected vessel.
    - seed (int, optional): Random seed for reproducibility; if provided, sets the random seed before sampling.

    The algorithm proceeds as follows:
    1. Retrieve unassigned vessels using get_unassigned_vessels. If none, return None, {} (no action possible).
    2. Randomly select one unassigned vessel_id.
    3. Get compatible berths and tugboats for the vessel. If either list is empty, return None, {} (infeasible for this vessel).
    4. Get the vessel's inbound time window (earliest_start, latest_start).
    5. Set random seed if provided in kwargs.
    6. For each attempt (up to max_attempts):
       a. Sample a random compatible inbound tugboat_id.
       b. Sample a random inbound_start within the time window.
       c. Check tugboat availability for inbound service (duration = vessel_inbound_service_times[vessel_id], prep_time = inbound_preparation_time).
       d. If available, compute berthing_start = inbound_start + inbound_duration + random_gap (0 to time_constraint_tolerance).
       e. Sample a random compatible berth_id.
       f. Check berth availability for berthing (duration = vessel_durations[vessel_id]).
       g. If available, compute outbound_start = berthing_start + berthing_duration + random_gap (0 to time_constraint_tolerance).
       h. Sample a random compatible outbound tugboat_id (can be same as inbound).
       i. Check tugboat availability for outbound service (duration = vessel_outbound_service_times[vessel_id], prep_time = outbound_preparation_time).
       j. If all availability checks pass, create inbound_tugboats = [(inbound_tug_id, inbound_start)], outbound_tugboats = [(outbound_tug_id, outbound_start)].
       k. Instantiate CompleteVesselAssignmentOperator with vessel_id, berth_id, berthing_start, inbound_tugboats, outbound_tugboats.
       l. Apply the operator to a deep copy of current_solution to get temp_solution.
       m. Validate temp_solution using validation_solution. If valid, return the operator and updated algorithm_data.
       n. If invalid (unlikely due to checks but possible edge cases), continue to next attempt.
    7. If no feasible assignment found after all attempts, return None, {} (no insertion performed).

    Necessary items from problem_state:
    - get_unassigned_vessels (callable): Returns list of unassigned vessel IDs.
    - get_vessel_time_window (callable): Returns (earliest_start, latest_start) for inbound service.
    - get_compatible_berths (callable): Returns list of compatible berth IDs for the vessel.
    - get_compatible_tugboats (callable): Returns list of compatible tugboat IDs for the vessel.
    - is_berth_available (callable): Checks berth availability for the given start time and duration.
    - is_tugboat_available (callable): Checks tugboat availability for the given start time, duration, and prep_time.
    - vessel_durations (numpy.ndarray): Berthing durations for each vessel.
    - vessel_inbound_service_times (numpy.ndarray): Inbound service durations for each vessel.
    - vessel_outbound_service_times (numpy.ndarray): Outbound service durations for each vessel.
    - current_solution (Solution): Current partial solution instance.
    - validation_solution (callable): Validates the solution against all mathematical constraints.
    - inbound_preparation_time (int): Prep time after inbound service.
    - outbound_preparation_time (int): Prep time after outbound service.
    - time_constraint_tolerance (float): Max allowed time gap in sequencing constraints.
    - time_periods (int): Total time horizon (used implicitly in availability checks).

    algorithm_data (dict): Optional and not required or modified by this heuristic; any updates are returned separately.

    Returns:
        CompleteVesselAssignmentOperator: The operator to assign the vessel if a feasible insertion is found and validated.
        dict: Updated data with {'random_seed_used': int (the seed value), 'insertion_success': True} if successful;
              otherwise, None and {} if no unassigned vessels, no compatible resources, or all attempts fail.
    """
    # Step 1: Get unassigned vessels
    unassigned_vessels = problem_state['get_unassigned_vessels'](problem_state['current_solution'])
    if not unassigned_vessels:
        return None, {}

    # Step 2: Randomly select a vessel
    vessel_id = random.choice(unassigned_vessels)

    # Step 3: Get compatible resources
    compatible_berths = problem_state['get_compatible_berths'](vessel_id)
    compatible_tugboats = problem_state['get_compatible_tugboats'](vessel_id)
    if not compatible_berths or not compatible_tugboats:
        return None, {}

    # Step 4: Get time window for inbound
    earliest_in, latest_in = problem_state['get_vessel_time_window'](vessel_id)
    if earliest_in > latest_in:
        return None, {}

    # Get vessel-specific data
    tau_in = int(problem_state['vessel_inbound_service_times'][vessel_id])
    tau_out = int(problem_state['vessel_outbound_service_times'][vessel_id])
    D_i = int(problem_state['vessel_durations'][vessel_id])
    epsilon = problem_state['time_constraint_tolerance']
    prep_in = problem_state['inbound_preparation_time']
    prep_out = problem_state['outbound_preparation_time']
    current_solution = problem_state['current_solution']
    validation_func = problem_state['validation_solution']

    # Hyper-parameters
    max_attempts = kwargs.get('max_attempts', 10)
    seed = kwargs.get('seed', random.randint(0, 1000))
    random.seed(seed)

    # Step 6: Attempt to find feasible assignment
    for attempt in range(max_attempts):
        # Sample inbound tug and start
        inbound_tug_id = random.choice(compatible_tugboats)
        inbound_start = random.randint(earliest_in, latest_in)

        # Check inbound tug availability (includes prep time)
        if not problem_state['is_tugboat_available'](inbound_tug_id, inbound_start, tau_in, prep_in, current_solution):
            continue

        # Compute berthing start with random gap within tolerance
        gap_in = random.randint(0, int(epsilon))
        berthing_start = inbound_start + tau_in + gap_in

        # Ensure berthing_start within bounds (basic check; availability will confirm)
        if berthing_start < 1 or berthing_start + D_i > problem_state['time_periods']:
            continue

        # Sample berth and check availability
        berth_id = random.choice(compatible_berths)
        if not problem_state['is_berth_available'](berth_id, berthing_start, D_i, current_solution):
            continue

        # Compute outbound start with random gap
        gap_out = random.randint(0, int(epsilon))
        outbound_start = berthing_start + D_i + gap_out

        # Ensure outbound_start within bounds
        if outbound_start < 1 or outbound_start + tau_out > problem_state['time_periods']:
            continue

        # Sample outbound tug and check availability
        outbound_tug_id = random.choice(compatible_tugboats)
        if not problem_state['is_tugboat_available'](outbound_tug_id, outbound_start, tau_out, prep_out, current_solution):
            continue

        # Construct tugboat lists (single services)
        inbound_tugboats = [(inbound_tug_id, inbound_start)]
        outbound_tugboats = [(outbound_tug_id, outbound_start)]

        # Create operator
        operator = CompleteVesselAssignmentOperator(
            vessel_id=vessel_id,
            berth_id=berth_id,
            start_time=berthing_start,
            inbound_tugboats=inbound_tugboats,
            outbound_tugboats=outbound_tugboats
        )

        # Step 7: Validate on temporary solution
        temp_solution = operator.run(copy.deepcopy(current_solution))
        if validation_func(temp_solution):
            return operator, {'random_seed_used': seed, 'insertion_success': True}

        # If invalid (rare, but continue)
        continue

    # No feasible assignment found
    return None, {}