from src.problems.psp.components import *
from typing import Union, Tuple, List, Dict
import numpy as np

def greedy_priority_assignment_506c(problem_state: dict, algorithm_data: dict, **kwargs) -> Tuple[Union[CompleteVesselAssignmentOperator, UnassignVesselOperator, None], Dict]:
    """
    Greedy heuristic that selects the highest priority unassigned vessel and assigns it to the lowest-cost feasible complete assignment.
    Sorts unassigned vessels by descending priority weight (vessel_priority_weights) and processes the top one.
    Uses find_feasible_assignments to get up to max_results feasible options, picks the cheapest.
    If no feasible assignment found, applies UnassignVesselOperator (redundant for unassigned but ensures explicit handling).
    If no unassigned vessels, returns None (no-op).

    Hyper-parameters in kwargs (with defaults):
    - max_results (int, default=5): Maximum number of feasible assignments to retrieve from find_feasible_assignments.
        Controls search breadth; higher values may find better but costlier options.
    - time_window_tolerance_factor (float, default=0.1): Factor to compute tolerance as factor * mean_berthing_duration.
        Not directly used in find_feasible_assignments (which uses time_constraint_tolerance), but can adjust search if needed
        (e.g., for custom time window expansion; here, logged but not applied to keep compatibility).

    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - get_unassigned_vessels (callable): Retrieves list of unassigned vessel IDs.
            - vessel_priority_weights (numpy.ndarray): 1D array of priority weights for sorting vessels.
            - find_feasible_assignments (callable): Finds feasible assignments for a vessel, returns sorted list of dicts.
            - mean_berting_duration (float): Average berthing duration for computing tolerance factor (if expanded).
            - current_solution (Solution): Current solution for feasibility checks in callables.
        algorithm_data (dict): Not used in this algorithm; can be empty.
        **kwargs: Hyper-parameters as described above.

    Returns:
        Union[CompleteVesselAssignmentOperator, UnassignVesselOperator, None]: The operator to apply the assignment (or unassign if infeasible).
            - CompleteVesselAssignmentOperator if a feasible low-cost assignment is found for the top vessel.
            - UnassignVesselOperator if no feasible assignment but vessel exists (ensures explicit no-assignment).
            - None if no unassigned vessels (no action needed).
        dict: Updated algorithm data.
            - If assignment made: {'assigned_vessels': list[int]} with the newly assigned vessel ID.
            - Otherwise: empty dict {}.
    """
    # Extract necessary items from problem_state (never modify problem_state)
    get_unassigned_vessels = problem_state['get_unassigned_vessels']
    vessel_priority_weights = problem_state['vessel_priority_weights']
    find_feasible_assignments = problem_state['find_feasible_assignments']
    mean_berthing_duration = problem_state['mean_berthing_duration']
    current_solution = problem_state['current_solution']

    # Hyper-parameters with defaults
    max_results = kwargs.get('max_results', 5)
    time_window_tolerance_factor = kwargs.get('time_window_tolerance_factor', 0.1)
    time_window_tolerance = time_window_tolerance_factor * mean_berthing_duration
    # Note: time_window_tolerance is computed but not passed to find_feasible_assignments (uses problem_state['time_constraint_tolerance']);
    # it could be used for custom expansion if callable is modified, but kept as-is for compatibility.

    # Get unassigned vessels
    unassigned_vessels = get_unassigned_vessels(current_solution)
    if not unassigned_vessels:
        # No unassigned vessels: no action needed
        return None, {}

    # Sort unassigned vessels by descending priority (highest first)
    # Use numpy argsort for efficiency; handle empty check implicitly since unassigned_vessels is non-empty
    sorted_indices = np.argsort(vessel_priority_weights[unassigned_vessels])[::-1]
    top_vessel_id = unassigned_vessels[sorted_indices[0]]

    # Find feasible assignments for the top vessel
    feasible_assignments = find_feasible_assignments(
        vessel_id=top_vessel_id,
        max_results=max_results,
        solution=current_solution
    )

    if not feasible_assignments:
        # No feasible assignment: explicitly unassign (though already unassigned)
        operator = UnassignVesselOperator(top_vessel_id)
        return operator, {}

    # Select the best (lowest cost) assignment
    best_assignment = feasible_assignments[0]  # Already sorted by total_cost ascending
    berth_id = best_assignment['berth_id']
    berth_start_time = best_assignment['berth_start_time']
    inbound_tugboats = best_assignment['inbound_tugboats']  # List with single tuple (tug_id, start_time)
    outbound_tugboats = best_assignment['outbound_tugboats']  # List with single tuple (tug_id, start_time)

    # Create the assignment operator
    operator = CompleteVesselAssignmentOperator(
        vessel_id=top_vessel_id,
        berth_id=berth_id,
        start_time=berth_start_time,
        inbound_tugboats=inbound_tugboats,
        outbound_tugboats=outbound_tugboats
    )

    # Note: find_feasible_assignments ensures compatibility (constraints 4,5,6), timing (9,10,13), availability (11,12),
    # and domains (15); thus, applying operator yields valid solution per validation_solution.

    # Update algorithm_data with newly assigned vessels
    updated_data = {'assigned_vessels': [top_vessel_id]}

    return operator, updated_data