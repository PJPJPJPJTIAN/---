from src.problems.psp.components import *
import itertools
import numpy as np

def swap_improvement_76a0(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[BaseOperator, dict]:
    """swap_improvement heuristic: Identifies pairs of assigned complete vessels with high ETA deviation, prioritizes those with high priority weights, and applies SwapVesselAssignmentsOperator or SwapBerthsOperator if it reduces total_scheduling_cost while maintaining validity. Scans top fraction of high-deviation vessels. Returns the best improving operator if found, else None.

    Hyper-parameters in kwargs (with defaults):
        - scan_fraction (float, default=0.1): Fraction of high-deviation vessels to consider for pairing (min 2 vessels).
        - deviation_threshold_multiplier (float, default=1.5): Multiplier for eta_deviation_avg to filter high-deviation vessels.

    The algorithm proceeds as follows:
    1. Extract current solution and old_cost from problem_state.
    2. Identify complete vessels (assigned with exactly one inbound and one outbound tugboat service).
    3. If fewer than 2 complete vessels, return None, {} (no possible swaps).
    4. Compute individual ETA deviations for complete vessels using inbound start times.
    5. Compute mean_dev from individual deviations (fallback to eta_deviation_avg if needed, but prioritize individual).
    6. Set threshold = mean_dev * deviation_threshold_multiplier; filter high_dev_vessels where deviation > threshold.
    7. If fewer than 2 high_dev_vessels, return None, {} (no candidates for improvement).
    8. Compute priority-deviation scores = deviation * priority_weight for high_dev_vessels to prioritize high-impact swaps.
    9. Select top_vessels: top scan_fraction of high_dev_vessels sorted by descending score (at least 2).
    10. For each pair in combinations(top_vessels, 2):
        - Create temp_solution with SwapVesselAssignmentsOperator; check validation_solution(temp_solution).
        - If valid, compute new_cost via get_problem_state; if new_cost < old_cost, track delta and operator.
        - If not improving/valid, try SwapBerthsOperator similarly.
        - Increment swaps_attempted for each attempted swap (full or berth).
    11. If a best improving operator found (delta < 0), return it with {'improvement_delta': best_delta, 'swaps_attempted': int}.
    12. Else, return None, {} (no improvement possible).

    Necessary items from problem_state:
        - current_solution (Solution): Current solution instance to copy and modify for testing.
        - total_scheduling_cost (float): Baseline cost for comparison.
        - get_problem_state (callable): Computes state including 'total_scheduling_cost' for new solutions.
        - validation_solution (callable): Validates new solutions against all constraints (4-6,9-13,15).
        - vessel_etas (numpy.ndarray): ETAs for computing individual deviations.
        - vessel_priority_weights (numpy.ndarray): Alpha_i for scoring high-impact vessels.
        - vessel_num (int): Total vessels for iteration bounds.
        - eta_deviation_avg (float): Fallback for mean_dev if no complete vessels.

    No necessary items from algorithm_data (can be empty).

    Returns:
        BaseOperator: The best improving SwapVesselAssignmentsOperator or SwapBerthsOperator if delta < 0 and valid, else None.
        dict: Updated data with 'improvement_delta' (cost reduction, negative if improving) and 'swaps_attempted' (count of swap applications tested), or empty dict if no action.
    """
    # Hyper-parameter defaults
    scan_fraction = kwargs.get('scan_fraction', 0.1)
    deviation_threshold_multiplier = kwargs.get('deviation_threshold_multiplier', 1.5)

    solution = problem_state['current_solution']
    old_cost = problem_state['total_scheduling_cost']
    get_problem_state_func = problem_state['get_problem_state']
    validation_func = problem_state['validation_solution']
    vessel_etas = problem_state['vessel_etas']
    vessel_priorities = problem_state['vessel_priority_weights']
    vessel_num = problem_state['vessel_num']
    eta_dev_avg = problem_state['eta_deviation_avg']

    # Step 1-2: Identify complete vessels (assigned with exactly one inbound and one outbound)
    complete_vessels = []
    for v in range(vessel_num):
        assignment = solution.vessel_assignments.get(v)
        inbound = solution.tugboat_inbound_assignments.get(v, [])
        outbound = solution.tugboat_outbound_assignments.get(v, [])
        if assignment is not None and len(inbound) == 1 and len(outbound) == 1:
            complete_vessels.append(v)
    
    if len(complete_vessels) < 2:
        # No possible swaps
        return None, {}

    # Step 3-4: Compute individual ETA deviations
    deviations = {}
    for v in complete_vessels:
        inbound = solution.tugboat_inbound_assignments[v]
        inbound_start = inbound[0][1]  # Single tuple: (tug_id, start_time)
        eta = vessel_etas[v]
        dev = abs(inbound_start - eta)
        deviations[v] = dev

    # Step 5: Compute mean_dev from individuals (more accurate than global avg)
    if deviations:
        mean_dev = np.mean(list(deviations.values()))
    else:
        mean_dev = eta_dev_avg
    threshold = mean_dev * deviation_threshold_multiplier if mean_dev > 0 else float('inf')  # Avoid div0 or no filter

    # Step 6-7: Filter high-dev vessels
    high_dev_vessels = [v for v in complete_vessels if deviations[v] > threshold]
    if len(high_dev_vessels) < 2:
        # No candidates for improvement
        return None, {}

    # Step 8: Compute scores = deviation * priority (high score = high impact)
    scores = {v: deviations[v] * vessel_priorities[v] for v in high_dev_vessels}

    # Step 9: Select top_vessels by descending score
    num_top = max(2, int(len(high_dev_vessels) * scan_fraction))
    top_vessels = sorted(high_dev_vessels, key=lambda v: -scores[v])[:num_top]

    # Step 10: Test swaps on pairs
    best_op = None
    best_delta = 0.0
    swaps_attempted = 0

    for v1, v2 in itertools.combinations(top_vessels, 2):
        # Try full swap first
        full_op = SwapVesselAssignmentsOperator(v1, v2)
        temp_sol_full = full_op.run(solution)
        if validation_func(temp_sol_full):
            new_state_full = get_problem_state_func(temp_sol_full)
            new_cost_full = new_state_full['total_scheduling_cost']
            delta_full = new_cost_full - old_cost
            swaps_attempted += 1
            if delta_full < best_delta:
                best_delta = delta_full
                best_op = full_op

        # Try berth swap if full not improving
        if best_delta >= 0:  # Only if no improvement yet
            berth_op = SwapBerthsOperator(v1, v2)
            temp_sol_berth = berth_op.run(solution)
            if validation_func(temp_sol_berth):
                new_state_berth = get_problem_state_func(temp_sol_berth)
                new_cost_berth = new_state_berth['total_scheduling_cost']
                delta_berth = new_cost_berth - old_cost
                swaps_attempted += 1
                if delta_berth < best_delta:
                    best_delta = delta_berth
                    best_op = berth_op

    # Step 11-12: Return best improving op if delta < 0, else None
    if best_op is not None and best_delta < 0:
        return best_op, {'improvement_delta': best_delta, 'swaps_attempted': swaps_attempted}
    else:
        return None, {}