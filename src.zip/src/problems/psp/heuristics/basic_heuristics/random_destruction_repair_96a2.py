from src.problems.psp.components import *
import copy
import random

def random_destruction_repair_96a2(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[RandomDestructionOperator, dict]:
    """
    Description for this heuristic algorithm.

    This heuristic simulates a random destruction-repair process for the Port Scheduling Problem. It first identifies currently assigned vessels and applies a random destruction to a specified percentage of them using RandomDestructionOperator logic. Then, it simulates repairing the destroyed vessels in ascending order of their ETA using a first-fit earliest assignment strategy: for each vessel, it searches for the earliest feasible inbound start time within the time window (limited by search_depth), sets the berth start immediately after inbound completion (no gap for simplicity, within tolerance), checks berths and tugboats sequentially from ID 0, and assigns the first available combination that satisfies availability, compatibility, and timing constraints. The simulation computes statistics on destruction and repair success without modifying the original solution. The returned operator is the RandomDestructionOperator to initiate the process (caller can apply it and use stats for subsequent repair). The result ensures validity through availability checks during simulated repair; if the simulated final solution fails validation_solution, the success rate is adjusted downward (though unlikely due to checks).

    Hyper-parameters in kwargs:
    - destruction_rate (float, default=0.2): Proportion of assigned vessels to randomly destroy (0 < rate <= 1).
    - seed (int, optional, default=None): Random seed for reproducible destruction selection. If provided, sets random.seed before simulation.
    - search_depth (int, default=10): Maximum number of earliest inbound start times to try per vessel during repair (limits computational effort).

    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - current_solution (Solution): Current partial solution instance to base the simulation on.
            - vessel_num (int): Total number of vessels.
            - berth_num (int): Total number of berths.
            - tugboat_num (int): Total number of tugboats.
            - time_periods (int): Total scheduling horizon.
            - vessel_etas (numpy.ndarray): ETAs for sorting destroyed vessels.
            - vessel_durations (numpy.ndarray): Berthing durations for availability checks.
            - vessel_inbound_service_times (numpy.ndarray): Inbound service durations.
            - vessel_outbound_service_times (numpy.ndarray): Outbound service durations.
            - inbound_preparation_time (int): Post-inbound preparation time for tugboats.
            - outbound_preparation_time (int): Post-outbound preparation time for tugboats.
            - time_constraint_tolerance (float): Allowed timing deviation (used to validate gaps, though set to 0 gap in this impl).
            - get_unassigned_vessels (callable): Identifies unassigned vessels to compute assigned set.
            - get_vessel_time_window (callable): Feasible inbound start window per vessel.
            - get_compatible_berths (callable): Compatible berths per vessel.
            - get_compatible_tugboats (callable): Compatible tugboats per vessel.
            - is_berth_available (callable): Checks berth availability over interval.
            - is_tugboat_available (callable): Checks tugboat availability including prep time.
            - validation_solution (callable): Validates the simulated repaired solution (used post-repair for confirmation).
        algorithm_data (dict): Not required or modified by this heuristic.

    Returns:
        RandomDestructionOperator: Instance of RandomDestructionOperator with the specified rate and seed to apply destruction (net effect starts the repair cycle; if full repair simulated, caller may skip, but always returns destruction op if vessels to destroy).
        dict: Updated algorithm data with {'destruction_count': int (number of vessels destroyed), 'repair_success_rate': float (fraction repaired successfully in simulation, 0.0 if no destruction)}.

    The algorithm proceeds as follows:
    1. Compute assigned vessels from current_solution using get_unassigned_vessels.
    2. If no assigned vessels, return None, {} (no action possible).
    3. Set random.seed if seed provided.
    4. Create and run RandomDestructionOperator on a deep copy of current_solution to get destroyed_solution and identify destroyed_vessels (assigned now unassigned).
    5. If destruction_count == 0, return None, {}.
    6. Sort destroyed_vessels by ascending ETA.
    7. For each sorted vessel, attempt repair: loop over earliest inbound starts (up to search_depth), set berth_start = inbound_end (0 gap <= tolerance), loop berths/tugs from 0, check availability sequentially, assign first feasible complete service using CompleteVesselAssignmentOperator on intermediate copy.
    8. Count repaired vessels; compute success rate.
    9. Validate simulated intermediate_solution with validation_solution; if invalid (edge case), set success_rate = 0.0.
    10. Return the destruction operator and updated data. No direct modification to problem_state or algorithm_data; if no change needed (e.g., rate=0 or no assigned), returns None, {}.
    """
    # Hyper-parameters with defaults
    destruction_rate = kwargs.get('destruction_rate', 0.2)
    seed = kwargs.get('seed', None)
    search_depth = kwargs.get('search_depth', 10)

    # Extract necessary data from problem_state (never modify originals)
    current_solution = problem_state['current_solution']
    vessel_num = problem_state['vessel_num']
    berth_num = problem_state['berth_num']
    tugboat_num = problem_state['tugboat_num']
    time_periods = problem_state['time_periods']
    vessel_etas = problem_state['vessel_etas']
    vessel_durations = problem_state['vessel_durations']
    vessel_inbound_service_times = problem_state['vessel_inbound_service_times']
    vessel_outbound_service_times = problem_state['vessel_outbound_service_times']
    inbound_preparation_time = problem_state['inbound_preparation_time']
    outbound_preparation_time = problem_state['outbound_preparation_time']
    time_constraint_tolerance = problem_state['time_constraint_tolerance']

    # Get original unassigned to compute assigned
    original_unassigned = problem_state['get_unassigned_vessels'](current_solution)
    original_assigned_set = set(range(vessel_num)) - set(original_unassigned)
    num_assigned = len(original_assigned_set)
    if num_assigned == 0:
        # No vessels to destroy
        return None, {}

    # Set seed for reproducibility if provided
    if seed is not None:
        random.seed(seed)

    # Simulate destruction on copy
    original_copy = copy.deepcopy(current_solution)
    destruction_op = RandomDestructionOperator(destruction_rate=destruction_rate, seed=seed)
    destroyed_solution = destruction_op.run(original_copy)

    # Compute destroyed vessels
    destroyed_unassigned = problem_state['get_unassigned_vessels'](destroyed_solution)
    destroyed_assigned_set = set(range(vessel_num)) - set(destroyed_unassigned)
    destroyed_vessels_set = original_assigned_set - destroyed_assigned_set
    destroyed_vessels = list(destroyed_vessels_set)
    destruction_count = len(destroyed_vessels)
    if destruction_count == 0:
        # No actual destruction occurred (e.g., rate too low or random)
        return None, {}

    # Sort destroyed vessels by ascending ETA for greedy repair order
    eta_pairs = [(vid, vessel_etas[vid]) for vid in destroyed_vessels]
    eta_pairs.sort(key=lambda x: x[1])
    sorted_destroyed_vessels = [vid for vid, _ in eta_pairs]

    # Simulate repair on copy of destroyed_solution
    intermediate_solution = copy.deepcopy(destroyed_solution)
    repaired_count = 0

    for vessel_id in sorted_destroyed_vessels:
        # Skip if already somehow assigned (edge case)
        if problem_state['get_unassigned_vessels'](intermediate_solution).count(vessel_id) == 0:
            continue

        # Get vessel-specific data
        tau_in = vessel_inbound_service_times[vessel_id]
        tau_out = vessel_outbound_service_times[vessel_id]
        duration = vessel_durations[vessel_id]

        # Compatible resources
        compatible_berths = set(problem_state['get_compatible_berths'](vessel_id))
        compatible_tugs = set(problem_state['get_compatible_tugboats'](vessel_id))

        # Time window for inbound
        early, late = problem_state['get_vessel_time_window'](vessel_id)

        found_assignment = False
        # First-fit earliest: try earliest inbound starts
        for in_start_cand in range(early, min(early + search_depth, late + 1)):
            if found_assignment:
                break
            in_end = in_start_cand + tau_in
            # Set berth start to immediate after inbound (0 gap, satisfies <= tolerance)
            berth_start_cand = in_end
            if berth_start_cand > time_periods:
                continue

            # Sequential berth check from 0
            for berth_id in range(berth_num):
                if berth_id not in compatible_berths:
                    continue
                if not problem_state['is_berth_available'](berth_id, berth_start_cand, duration, intermediate_solution):
                    continue

                # Sequential tug check for inbound from 0
                found_inbound = False
                for tug_id in range(tugboat_num):
                    if tug_id not in compatible_tugs:
                        continue
                    if not problem_state['is_tugboat_available'](tug_id, in_start_cand, tau_in, inbound_preparation_time, intermediate_solution):
                        continue

                    # Outbound start after berthing (0 gap)
                    out_start_cand = berth_start_cand + duration
                    if out_start_cand > time_periods:
                        continue

                    # Sequential tug check for outbound from 0
                    found_outbound = False
                    for out_tug_id in range(tugboat_num):
                        if out_tug_id not in compatible_tugs:
                            continue
                        if problem_state['is_tugboat_available'](out_tug_id, out_start_cand, tau_out, outbound_preparation_time, intermediate_solution):
                            # Feasible complete assignment found
                            inbound_tugs = [(tug_id, in_start_cand)]
                            outbound_tugs = [(out_tug_id, out_start_cand)]
                            # Apply repair operator to intermediate
                            repair_op = CompleteVesselAssignmentOperator(
                                vessel_id, berth_id, berth_start_cand, inbound_tugs, outbound_tugs
                            )
                            intermediate_solution = repair_op.run(intermediate_solution)
                            repaired_count += 1
                            found_assignment = True
                            found_outbound = True
                            break
                    if found_outbound:
                        found_inbound = True
                        break
                if found_inbound:
                    break

    # Compute success rate
    repair_success_rate = repaired_count / destruction_count

    # Validate the simulated repaired solution (ensures all constraints respected)
    if not problem_state['validation_solution'](intermediate_solution):
        # Rare case: availability checks failed to catch overlap; penalize by setting rate to 0
        repair_success_rate = 0.0

    # Updated algorithm data
    updated_algorithm_data = {
        'destruction_count': destruction_count,
        'repair_success_rate': repair_success_rate
    }

    # Return the destruction operator as the net starting point (repair stats guide future steps; if full repair, caller can choose not to apply or repair separately)
    # If all repaired in sim, could return None but per description, return destruction for partial/full cycle initiation
    return destruction_op, updated_algorithm_data