from src.problems.psp.components import *
import numpy as np

def first_fit_earliest_d2d7(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[CompleteVesselAssignmentOperator, dict]:
    """
    First-fit earliest heuristic for assigning the unassigned vessel with the earliest ETA to the earliest feasible complete service (inbound tugboat, berth, outbound tugboat).
    Processes vessels in ascending order of ETA. For the first unassigned vessel (earliest ETA), searches for the earliest inbound start time within its time window (limited by search_depth).
    Computes tight timings: berthing_start = inbound_start + tau_in, outbound_start = berthing_start + D_i (gaps=0, within time_constraint_tolerance).
    Checks compatibility and availability sequentially: compatible berths/tugboats in order (0 to n-1), first available combination is selected.
    Ensures all timing, occupation, and domain constraints are respected via callables; the resulting assignment is valid per validation_solution criteria.
    If no unassigned vessels, or no feasible assignment found within search_depth, returns None (no operator applied).
    Hyper-parameters:
        search_depth (int, default=10): Maximum number of consecutive inbound start times to check from the earliest in the time window.
    Necessary items from problem_state:
        - vessel_etas (numpy.ndarray): 1D array for sorting unassigned vessels by ascending ETA.
        - vessel_inbound_service_times (numpy.ndarray): 1D array for inbound service durations (tau_in).
        - vessel_durations (numpy.ndarray): 1D array for berthing durations (D_i).
        - vessel_outbound_service_times (numpy.ndarray): 1D array for outbound service durations (tau_out).
        - time_periods (int): Scheduling horizon to bound start times.
        - inbound_preparation_time (int): Prep time after inbound service for tugboat availability.
        - outbound_preparation_time (int): Prep time after outbound service for tugboat availability.
        - get_unassigned_vessels (callable): Retrieves list of unassigned vessel IDs.
        - get_vessel_time_window (callable): Gets (earliest_inbound, latest_inbound) for the target vessel.
        - get_compatible_berths (callable): List of compatible berth IDs for the vessel.
        - get_compatible_tugboats (callable): List of compatible tugboat IDs for the vessel.
        - is_berth_available (callable): Checks berth availability for [berthing_start, berthing_start + D_i).
        - is_tugboat_available (callable): Checks tugboat availability for service + prep time.
    algorithm_data is not used or modified in this heuristic.
    Returns:
        CompleteVesselAssignmentOperator: Instance for the first feasible assignment of the target vessel, or None if infeasible/no unassigned vessels.
        dict: Updated with {'search_stats': {'feasible_slots_found': int}}, where feasible_slots_found is the count of available berth-time slots checked (berth availability passes) during the search for this vessel.
    """
    # Get unassigned vessels and sort by ascending ETA to select the earliest one
    unassigned_vessels = problem_state['get_unassigned_vessels']()
    if not unassigned_vessels:
        # No unassigned vessels: no operator to apply
        return None, {'search_stats': {'feasible_slots_found': 0}}
    
    vessel_etas = problem_state['vessel_etas']
    sorted_unassigned = sorted(unassigned_vessels, key=lambda vid: vessel_etas[vid])
    target_vessel = sorted_unassigned[0]
    
    # Hyper-parameter: search_depth defaults to 10, limits time slots checked from earliest inbound
    search_depth = kwargs.get('search_depth', 10)
    
    # Get vessel-specific data
    tau_in = problem_state['vessel_inbound_service_times'][target_vessel]
    D_i = problem_state['vessel_durations'][target_vessel]
    tau_out = problem_state['vessel_outbound_service_times'][target_vessel]
    time_horizon = problem_state['time_periods']
    prep_in = problem_state['inbound_preparation_time']
    prep_out = problem_state['outbound_preparation_time']
    
    # Get time window for inbound service and compatible resources
    earliest_inbound, latest_inbound = problem_state['get_vessel_time_window'](target_vessel)
    compatible_berths = problem_state['get_compatible_berths'](target_vessel)
    compatible_tugs = problem_state['get_compatible_tugboats'](target_vessel)
    
    # Initialize search stats and assignment result
    feasible_slots_found = 0  # Counts berth-time pairs where is_berth_available is True
    found_assignment = None
    
    # Search for earliest feasible inbound_start within depth limit
    max_inbound_to_check = min(earliest_inbound + search_depth, latest_inbound)
    for inbound_start in range(earliest_inbound, max_inbound_to_check + 1):
        # Compute tight berthing and outbound starts (gaps=0, valid per constraints 9 & 10 with tolerance)
        berthing_start = inbound_start + tau_in
        if berthing_start + D_i > time_horizon:
            continue  # Berth would exceed horizon
        outbound_start = berthing_start + D_i
        if outbound_start + tau_out > time_horizon:
            continue  # Outbound would exceed horizon
        
        # Check berths sequentially for availability
        for berth_id in compatible_berths:
            if problem_state['is_berth_available'](berth_id, berthing_start, D_i):
                feasible_slots_found += 1  # Berth slot is available
                
                # Check inbound tugboats sequentially
                for tug_in_id in compatible_tugs:
                    if problem_state['is_tugboat_available'](tug_in_id, inbound_start, tau_in, prep_in):
                        # Check outbound tugboats sequentially (can be same or different tug)
                        for tug_out_id in compatible_tugs:
                            if problem_state['is_tugboat_available'](tug_out_id, outbound_start, tau_out, prep_out):
                                # Full feasible assignment found: tight timings ensure sequence constraints (9,10)
                                # Compatibility ensured by get_compatible_*, domains by bounds, occupations by is_*_available
                                # Time window (13) satisfied by inbound_start range
                                found_assignment = {
                                    'berth_id': berth_id,
                                    'berth_start_time': berthing_start,
                                    'inbound_tugboats': [(tug_in_id, inbound_start)],
                                    'outbound_tugboats': [(tug_out_id, outbound_start)]
                                }
                                # First-fit: stop searching further
                                break
                        if found_assignment:
                            break
                if found_assignment:
                    break
        if found_assignment:
            break  # Found for this vessel: no need to check later times
    
    # Return operator if assignment found, else None; always include stats
    if found_assignment:
        operator = CompleteVesselAssignmentOperator(
            target_vessel,
            found_assignment['berth_id'],
            found_assignment['berth_start_time'],
            found_assignment['inbound_tugboats'],
            found_assignment['outbound_tugboats']
        )
        # The operator, when applied, will produce a valid solution per checks used
        return operator, {'search_stats': {'feasible_slots_found': feasible_slots_found}}
    else:
        # No feasible assignment: skip (no operator), but provide stats from search
        return None, {'search_stats': {'feasible_slots_found': feasible_slots_found}}