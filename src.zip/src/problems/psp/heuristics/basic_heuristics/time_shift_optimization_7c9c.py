from src.problems.psp.components import *
import copy
import numpy as np

def time_shift_optimization_7c9c(problem_state: dict, algorithm_data: dict, **kwargs) -> tuple[TimeShiftVesselOperator, dict]:
    """
    This heuristic identifies assigned vessels with high individual waiting times (berthing start - ETA > 0.5 * mean_berthing_duration)
    and attempts to shift their entire schedule (berth start and tugboat service starts) by small time deltas to reduce ETA deviation costs (Z3 component).
    It evaluates shifts in a default range [-5, +5] with step 1, ensuring the new solution remains valid via validation_solution.
    Among candidate vessels (up to 20% of assigned vessels, selected by highest waiting time), it finds the single best shift (max deviation reduction)
    and returns the corresponding TimeShiftVesselOperator. If no improving or valid shift is found for any candidate, returns None, {}.
    Focuses on improving feasibility and cost without unassigning vessels; tugboat and berth availability are implicitly checked via validation.

    Hyper-parameters in kwargs (with defaults):
    - delta_range (tuple[int, int]): Range for time_delta (low, high); default=(-5, 5).
    - step (int): Step size for trying deltas; default=1.
    - fraction (float): Fraction of assigned vessels to process as candidates; default=0.2 (clamped to [0,1]).
    - threshold_multiplier (float): Multiplier for waiting time threshold (0.5 * mean_berthing_duration * multiplier); default=1.0.

    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - vessel_num (int): Total number of vessels.
            - vessel_etas (numpy.ndarray): 1D array of ETA_i for each vessel.
            - mean_berthing_duration (float): Average berthing duration D_i.
            - current_solution (Solution): Current solution instance to evaluate shifts on.
            - get_problem_state (callable): Computes state including 'total_scheduling_cost' for cost comparison.
            - validation_solution (callable): Validates if a solution satisfies all constraints.
            - n_vessels (int): Total vessels (|I|).
            - unserved_vessels_count (int): Number of unserved vessels to compute assigned count.
        algorithm_data (dict): Not used in this algorithm (can be empty).

    Returns:
        TimeShiftVesselOperator: The operator for the best vessel shift (vessel_id, best_delta) that reduces ETA deviation while keeping the solution valid;
            None if no valid improving shift found across candidates.
        dict: Updated algorithm data with {'shifts_applied': int (1 if operator returned, else 0), 'avg_deviation_reduction': float (reduction for the best shift, or 0.0)}.
    """
    # Extract necessary data from problem_state (never modify originals)
    current_solution = problem_state['current_solution']
    vessel_etas = problem_state['vessel_etas']
    mean_berthing_duration = problem_state['mean_berthing_duration']
    get_problem_state = problem_state['get_problem_state']
    validation_solution = problem_state['validation_solution']
    n_vessels = problem_state['n_vessels']
    unserved_vessels_count = problem_state['unserved_vessels_count']
    n_assigned = n_vessels - unserved_vessels_count

    # Hyper-parameter defaults
    delta_range = kwargs.get('delta_range', (-5, 5))
    step = kwargs.get('step', 1)
    fraction = max(0.0, min(1.0, kwargs.get('fraction', 0.2)))
    threshold_multiplier = kwargs.get('threshold_multiplier', 1.0)

    # No action if no assigned vessels
    if n_assigned == 0:
        return None, {'shifts_applied': 0, 'avg_deviation_reduction': 0.0}

    # Compute threshold for high waiting time
    threshold = 0.5 * mean_berting_duration * threshold_multiplier

    # Identify candidate vessels: assigned ones with individual waiting_time > threshold
    # waiting_time = berthing_start - ETA_i; only for vessels with complete assignments
    candidates = []
    for v_id in range(n_vessels):
        assignment = current_solution.vessel_assignments.get(v_id)
        if assignment is not None:  # Assigned to berth
            berth_start = assignment[1]
            waiting_time = berth_start - vessel_etas[v_id]
            # Check if complete (has inbound and outbound, assuming from solution structure)
            inbound = current_solution.tugboat_inbound_assignments.get(v_id, [])
            outbound = current_solution.tugboat_outbound_assignments.get(v_id, [])
            if len(inbound) == 1 and len(outbound) == 1 and waiting_time > threshold:
                candidates.append((v_id, waiting_time))

    # No candidates? Return None
    if not candidates:
        return None, {'shifts_applied': 0, 'avg_deviation_reduction': 0.0}

    # Sort candidates by waiting_time descending (prioritize longest waiters)
    candidates.sort(key=lambda x: x[1], reverse=True)

    # Limit to fraction of assigned
    max_candidates = max(1, int(n_assigned * fraction))
    candidates = candidates[:max_candidates]

    # For each candidate, find best delta
    best_vessel = None
    best_delta = None
    best_reduction = 0.0
    old_total_cost = problem_state['total_scheduling_cost']

    deltas = list(range(delta_range[0], delta_range[1] + 1, step))
    for v_id, _ in candidates:
        # Compute old deviation for this vessel: |inbound_start - ETA|
        inbound_old = current_solution.tugboat_inbound_assignments.get(v_id, [])
        if not inbound_old:
            continue  # Skip if incomplete
        old_inbound_start = inbound_old[0][1]
        old_dev = abs(old_inbound_start - vessel_etas[v_id])

        vessel_best_delta = None
        vessel_best_reduction = 0.0
        for delta in deltas:
            if delta == 0:
                continue  # Skip no-change

            # Create temporary solution with shift
            temp_operator = TimeShiftVesselOperator(v_id, delta)
            temp_solution = temp_operator.run(current_solution)

            # Validate the temporary solution
            if not validation_solution(temp_solution):
                continue

            # Compute new deviation
            inbound_new = temp_solution.tugboat_inbound_assignments.get(v_id, [])
            if not inbound_new:
                continue
            new_inbound_start = inbound_new[0][1]
            new_dev = abs(new_inbound_start - vessel_etas[v_id])
            reduction = old_dev - new_dev

            # Also check total cost improvement (ensures overall benefit, including Z3)
            new_state = get_problem_state(temp_solution)
            new_total_cost = new_state['total_scheduling_cost']
            cost_improvement = old_total_cost - new_total_cost

            # Accept if valid, reduces deviation, and improves total cost (focus on Z3 but holistic)
            if reduction > 0 and cost_improvement > 0 and reduction > vessel_best_reduction:
                vessel_best_reduction = reduction
                vessel_best_delta = delta

        # If found a good delta for this vessel, track if best overall
        if vessel_best_delta is not None and vessel_best_reduction > best_reduction:
            best_reduction = vessel_best_reduction
            best_vessel = v_id
            best_delta = vessel_best_delta

    # Return the best operator if found
    if best_vessel is not None:
        operator = TimeShiftVesselOperator(best_vessel, best_delta)
        return operator, {'shifts_applied': 1, 'avg_deviation_reduction': best_reduction}
    else:
        return None, {'shifts_applied': 0, 'avg_deviation_reduction': 0.0}