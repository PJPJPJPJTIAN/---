from src.problems.cvrp.components import *
import numpy as np
from typing import Tuple, Optional

def two_opt_759b(problem_state: dict, algorithm_data: dict, **kwargs) -> Tuple[Optional[ReverseSegmentOperator], dict]:
    """2-opt heuristic for CVRP that reverses route segments to eliminate route crossings and reduce total distance.
    
    This algorithm searches for the most beneficial 2-opt move by evaluating all possible segment reversals
    within each vehicle's route. It considers the distance savings from eliminating route crossings while
    ensuring the solution remains valid (no duplicate nodes, capacity constraints maintained).
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - distance_matrix (numpy.ndarray): 2D array of distances between nodes
            - current_solution (Solution): Current solution with routes for each vehicle
            - validation_solution (callable): Function to validate solution feasibility
            - capacity (int): Vehicle capacity constraint
            - demands (numpy.ndarray): Demand values for each node
            - depot (int): Depot node index
        algorithm_data (dict): Not used in this algorithm, returns empty dict
        **kwargs: Hyperparameters for the algorithm:
            - max_route_length (int, default=20): Maximum route length to consider for 2-opt (prevents excessive computation)
            - min_segment_length (int, default=2): Minimum segment length to reverse
            - allow_empty_routes (bool, default=False): Whether to consider routes with only depot
    
    Returns:
        ReverseSegmentOperator: Operator that reverses the most beneficial segment, or None if no improving move found
        dict: Empty dictionary as no algorithm data is updated
        
    The algorithm will return None if:
    1. No improving 2-opt move is found
    2. All routes are empty or contain only depot
    3. The best move would violate capacity constraints
    4. The best move would create an invalid solution
    """
    
    # Extract hyperparameters with default values
    max_route_length = kwargs.get('max_route_length', 20)
    min_segment_length = kwargs.get('min_segment_length', 2)
    allow_empty_routes = kwargs.get('allow_empty_routes', False)
    
    # Extract necessary problem state
    distance_matrix = problem_state['distance_matrix']
    current_solution = problem_state['current_solution']
    validation_solution = problem_state['validation_solution']
    capacity = problem_state['capacity']
    demands = problem_state['demands']
    depot = problem_state['depot']
    
    best_savings = 0
    best_move = None
    best_vehicle_id = None
    
    # Iterate through all vehicle routes
    for vehicle_id, route in enumerate(current_solution.routes):
        # Skip empty routes or routes with only depot if not allowed
        if len(route) <= 1 and not allow_empty_routes:
            continue
            
        # Skip routes that are too long for efficient computation
        if len(route) > max_route_length:
            continue
            
        # Evaluate all possible 2-opt moves for this route
        for i in range(len(route)):
            for j in range(i + min_segment_length, len(route)):
                if j - i < min_segment_length:
                    continue
                    
                # Calculate current distance of the segment endpoints
                prev_i = route[i-1] if i > 0 else depot
                next_i = route[i]
                prev_j = route[j-1] if j > 0 else depot
                next_j = route[j] if j < len(route) - 1 else depot
                
                current_distance = (distance_matrix[prev_i, next_i] + 
                                  distance_matrix[prev_j, next_j])
                
                # Calculate distance after reversal
                reversed_distance = (distance_matrix[prev_i, route[j]] + 
                                   distance_matrix[route[i], next_j])
                
                # Calculate savings
                savings = current_distance - reversed_distance
                
                # Check if this is the best move so far
                if savings > best_savings:
                    # Create temporary solution to validate feasibility
                    temp_routes = [r[:] for r in current_solution.routes]
                    temp_route = temp_routes[vehicle_id][:]
                    
                    # Reverse the segment
                    temp_route[i:j+1] = reversed(temp_route[i:j+1])
                    temp_routes[vehicle_id] = temp_route
                    
                    temp_solution = Solution(temp_routes, depot)
                    
                    # Check if solution is valid
                    if validation_solution(temp_solution):
                        best_savings = savings
                        best_move = [(i, j)]
                        best_vehicle_id = vehicle_id
    
    # Return the best move if found
    if best_move is not None and best_savings > 0:
        return ReverseSegmentOperator(best_vehicle_id, best_move), {}
    
    # Return None if no improving move found
    return None, {}