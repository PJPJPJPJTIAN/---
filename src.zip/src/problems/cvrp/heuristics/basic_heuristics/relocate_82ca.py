from src.problems.cvrp.components import *
import numpy as np
from typing import Tuple, Optional

def relocate_82ca(problem_state: dict, algorithm_data: dict, **kwargs) -> Tuple[Optional[RelocateOperator], dict]:
    """Relocate heuristic that moves a customer from one route to another to reduce total distance.
    
    This algorithm evaluates all possible customer relocations between routes, selecting the move that
    provides the maximum distance reduction while maintaining capacity constraints. It considers both
    intra-route and inter-route relocations.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - distance_matrix (numpy.ndarray): Distance matrix between all nodes
            - capacity (int): Vehicle capacity constraint
            - demands (numpy.ndarray): Demand values for each node
            - current_solution (Solution): Current solution to improve
            - validation_solution (callable): Function to validate solution feasibility
            - depot (int): Depot node index
        algorithm_data (dict): Not used in this algorithm, returns empty dict
        max_evaluations (int, optional): Maximum number of relocation evaluations to consider. Default: 1000
        allow_intra_route (bool, optional): Whether to allow relocations within the same route. Default: True
        
    Returns:
        RelocateOperator: The best relocation operator found, or None if no improving move exists
        dict: Empty dictionary as no algorithm data is updated
        
    The algorithm will return None if:
    1. No valid improving relocation move is found
    2. The current solution has empty routes or insufficient vehicles
    3. All relocation evaluations exceed the max_evaluations limit
    """
    
    # Extract hyper-parameters with default values
    max_evaluations = kwargs.get('max_evaluations', 1000)
    allow_intra_route = kwargs.get('allow_intra_route', True)
    
    # Extract necessary problem state components
    distance_matrix = problem_state['distance_matrix']
    capacity = problem_state['capacity']
    demands = problem_state['demands']
    current_solution = problem_state['current_solution']
    validation_func = problem_state['validation_solution']
    depot = problem_state['depot']
    
    routes = current_solution.routes
    num_vehicles = len(routes)
    
    # Check if solution has valid routes
    if num_vehicles == 0 or all(len(route) == 0 for route in routes):
        return None, {}
    
    best_operator = None
    best_delta = float('inf')  # Negative values indicate improvement
    evaluation_count = 0
    
    # Evaluate all possible customer relocations
    for source_vehicle_id in range(num_vehicles):
        source_route = routes[source_vehicle_id]
        
        # Skip empty source routes
        if len(source_route) == 0:
            continue
            
        for source_pos in range(len(source_route)):
            node = source_route[source_pos]
            
            # Skip depot nodes
            if node == depot:
                continue
                
            for target_vehicle_id in range(num_vehicles):
                # Skip same vehicle if intra-route not allowed
                if not allow_intra_route and source_vehicle_id == target_vehicle_id:
                    continue
                    
                target_route = routes[target_vehicle_id]
                
                # Calculate current load of target vehicle
                target_current_load = sum(demands[n] for n in target_route if n != depot)
                
                # Check if target vehicle can accommodate the node
                if target_current_load + demands[node] > capacity:
                    continue
                    
                # Evaluate all possible insertion positions in target route
                for target_pos in range(len(target_route) + 1):
                    # Skip evaluation if max evaluations reached
                    if evaluation_count >= max_evaluations:
                        break
                        
                    evaluation_count += 1
                    
                    # Calculate distance delta for this relocation
                    delta = calculate_relocation_delta(
                        source_vehicle_id, source_pos, 
                        target_vehicle_id, target_pos,
                        routes, distance_matrix, depot
                    )
                    
                    # Update best operator if this is an improvement
                    if delta < best_delta:
                        # Create temporary solution to validate feasibility
                        temp_operator = RelocateOperator(
                            source_vehicle_id, source_pos,
                            target_vehicle_id, target_pos
                        )
                        temp_solution = temp_operator.run(current_solution)
                        
                        if validation_func(temp_solution):
                            best_operator = temp_operator
                            best_delta = delta
                            
                    if evaluation_count >= max_evaluations:
                        break
                if evaluation_count >= max_evaluations:
                    break
            if evaluation_count >= max_evaluations:
                break
        if evaluation_count >= max_evaluations:
            break
    
    # Return best operator if it provides improvement (negative delta)
    if best_operator is not None and best_delta < 0:
        return best_operator, {}
    else:
        return None, {}

def calculate_relocation_delta(source_veh_id, source_pos, target_veh_id, target_pos, routes, dist_matrix, depot):
    """Calculate the distance change for a relocation operation."""
    source_route = routes[source_veh_id]
    target_route = routes[target_veh_id]
    node = source_route[source_pos]
    
    # Calculate removal cost from source route
    prev_node = source_route[source_pos - 1] if source_pos > 0 else depot
    next_node = source_route[source_pos + 1] if source_pos < len(source_route) - 1 else depot
    removal_savings = dist_matrix[prev_node][node] + dist_matrix[node][next_node] - dist_matrix[prev_node][next_node]
    
    # Calculate insertion cost to target route
    if len(target_route) == 0:
        # Inserting into empty route: depot -> node -> depot
        insertion_cost = 2 * dist_matrix[depot][node]
    else:
        if target_pos == 0:
            # Insert at beginning: depot -> node -> first_node
            first_node = target_route[0]
            insertion_cost = dist_matrix[depot][node] + dist_matrix[node][first_node] - dist_matrix[depot][first_node]
        elif target_pos == len(target_route):
            # Insert at end: last_node -> node -> depot
            last_node = target_route[-1]
            insertion_cost = dist_matrix[last_node][node] + dist_matrix[node][depot] - dist_matrix[last_node][depot]
        else:
            # Insert in middle: prev -> node -> next
            prev_node_target = target_route[target_pos - 1]
            next_node_target = target_route[target_pos]
            insertion_cost = (dist_matrix[prev_node_target][node] + dist_matrix[node][next_node_target] 
                            - dist_matrix[prev_node_target][next_node_target])
    
    # Total delta: insertion cost minus removal savings
    return insertion_cost - removal_savings