from src.problems.cvrp.components import *
import numpy as np
from typing import Tuple, Optional

def greedy_insertion_708f(problem_state: dict, algorithm_data: dict, **kwargs) -> Tuple[Optional[InsertOperator], dict]:
    """Enhanced greedy insertion heuristic for CVRP with proximity-based cost calculation.
    
    This algorithm identifies the best insertion position for unvisited customers by calculating
    a weighted cost that considers both distance increase and proximity to route centroid.
    It prioritizes customers based on their distance from depot multiplied by demand to better
    capture both geographical isolation and resource requirements.
    
    Args:
        problem_state (dict): The dictionary contains the problem state. In this algorithm, the following items are necessary:
            - distance_matrix (numpy.ndarray): Distance matrix between all nodes
            - capacity (int): Vehicle capacity constraint
            - depot (int): Depot node index
            - demands (numpy.ndarray): Demand values for each node
            - current_solution (Solution): Current solution with routes
            - validation_solution (callable): Function to validate solution feasibility
        algorithm_data (dict): Not used in this algorithm, returns empty dict
        **kwargs: Hyper-parameters for the algorithm:
            - insertion_strategy (str): Strategy for customer selection ('farthest_first' or 'nearest_first') (default: 'farthest_first')
            - allow_new_routes (bool): Whether to allow inserting into empty vehicles (default: True)
            - max_attempts (int): Maximum attempts to find valid insertion (default: 1000)
            - proximity_weight (float): Weight for proximity to route centroid in cost calculation (default: 0.3)

    Returns:
        InsertOperator: Operator that inserts a customer at the optimal position, or None if no valid insertion found
        dict: Empty dictionary as no algorithm data is updated

    The algorithm will return None if:
    1. All customers are already visited in the solution
    2. No valid insertion position found that respects capacity constraints
    3. Maximum attempts reached without finding a feasible insertion
    """
    
    # Extract hyper-parameters with default values
    insertion_strategy = kwargs.get('insertion_strategy', 'farthest_first')
    allow_new_routes = kwargs.get('allow_new_routes', True)
    max_attempts = kwargs.get('max_attempts', 1000)
    proximity_weight = kwargs.get('proximity_weight', 0.3)
    
    # Extract necessary problem state data
    distance_matrix = problem_state['distance_matrix']
    capacity = problem_state['capacity']
    depot = problem_state['depot']
    demands = problem_state['demands']
    current_solution = problem_state['current_solution']
    validation_solution = problem_state['validation_solution']
    
    # Get all nodes and identify unvisited customers (excluding depot)
    all_nodes = set(range(len(distance_matrix)))
    visited_nodes = set()
    for route in current_solution.routes:
        visited_nodes.update(route)
    
    unvisited_customers = all_nodes - visited_nodes - {depot}
    
    # If no unvisited customers, return None
    if not unvisited_customers:
        return None, {}
    
    # Sort unvisited customers based on strategy with demand consideration
    if insertion_strategy == 'farthest_first':
        # Prioritize customers farthest from depot multiplied by demand
        sorted_customers = sorted(unvisited_customers, 
                                 key=lambda node: distance_matrix[depot][node] * demands[node], 
                                 reverse=True)
    else:  # nearest_first
        # Prioritize customers nearest to depot multiplied by demand
        sorted_customers = sorted(unvisited_customers, 
                                 key=lambda node: distance_matrix[depot][node] * demands[node])
    
    # Calculate current route loads and centroids
    route_loads = []
    route_centroids = []
    
    for route in current_solution.routes:
        # Calculate route load (excluding depot)
        route_load = sum(demands[node] for node in route if node != depot)
        route_loads.append(route_load)
        
        # Calculate route centroid (geometric center of customer nodes)
        customer_nodes = [node for node in route if node != depot]
        if customer_nodes:
            # Use average of customer coordinates (simplified approach)
            centroid = np.mean([distance_matrix[node] for node in customer_nodes], axis=0)
        else:
            # For empty routes, use depot as centroid
            centroid = distance_matrix[depot]
        route_centroids.append(centroid)
    
    best_insertion = None
    best_weighted_cost = float('inf')
    attempts = 0
    
    # Try each customer in priority order
    for customer in sorted_customers:
        customer_demand = demands[customer]
        
        # Try each vehicle route
        for vehicle_id, route in enumerate(current_solution.routes):
            current_load = route_loads[vehicle_id]
            
            # Check capacity constraint
            if current_load + customer_demand > capacity:
                continue
            
            # Try each insertion position in the route
            for position in range(len(route) + 1):
                attempts += 1
                if attempts > max_attempts:
                    return None, {}
                
                # Calculate cost increase for insertion
                if len(route) == 0:
                    # Empty route: cost is depot-customer-depot
                    cost_increase = 2 * distance_matrix[depot][customer]
                elif position == 0:
                    # Insert at beginning
                    prev_node = depot
                    next_node = route[0]
                    cost_increase = (distance_matrix[prev_node][customer] + 
                                    distance_matrix[customer][next_node] - 
                                    distance_matrix[prev_node][next_node])
                elif position == len(route):
                    # Insert at end
                    prev_node = route[-1]
                    next_node = depot
                    cost_increase = (distance_matrix[prev_node][customer] + 
                                    distance_matrix[customer][next_node] - 
                                    distance_matrix[prev_node][next_node])
                else:
                    # Insert in middle
                    prev_node = route[position - 1]
                    next_node = route[position]
                    cost_increase = (distance_matrix[prev_node][customer] + 
                                    distance_matrix[customer][next_node] - 
                                    distance_matrix[prev_node][next_node])
                
                # Calculate proximity cost (distance to route centroid)
                if len(route) > 0 and any(node != depot for node in route):
                    # For non-empty routes, calculate distance to centroid
                    centroid_distance = np.linalg.norm(distance_matrix[customer] - route_centroids[vehicle_id])
                else:
                    # For empty routes, use distance to depot
                    centroid_distance = distance_matrix[depot][customer]
                
                # Calculate weighted cost
                weighted_cost = cost_increase + proximity_weight * centroid_distance
                
                # Update best insertion if better
                if weighted_cost < best_weighted_cost:
                    best_insertion = (vehicle_id, customer, position)
                    best_weighted_cost = weighted_cost
        
        # Check empty vehicles if allowed
        if allow_new_routes:
            for vehicle_id, route in enumerate(current_solution.routes):
                if len(route) == 0:  # Empty vehicle
                    attempts += 1
                    if attempts > max_attempts:
                        return None, {}
                    
                    # Cost for new route: depot-customer-depot
                    cost_increase = 2 * distance_matrix[depot][customer]
                    
                    # For empty routes, use distance to depot
                    centroid_distance = distance_matrix[depot][customer]
                    
                    # Calculate weighted cost
                    weighted_cost = cost_increase + proximity_weight * centroid_distance
                    
                    if weighted_cost < best_weighted_cost:
                        best_insertion = (vehicle_id, customer, 0)
                        best_weighted_cost = weighted_cost
    
    # Return the best insertion operator if found
    if best_insertion:
        vehicle_id, customer, position = best_insertion
        return InsertOperator(vehicle_id, customer, position), {}
    
    # No valid insertion found
    return None, {}