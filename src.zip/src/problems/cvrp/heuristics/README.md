# Heuristic Folder 
 
This heuristic folder contains heuristics of the Capacitated Vehicle Routing Problem (CVRP). 

- basic_heuristics contains the basic heuristics from GPT-4o by "python generate_heuristic.py"
- evolved_heuristics contains the evolved heuristics from GPT-4o by "python evolution_heuristic.py"
