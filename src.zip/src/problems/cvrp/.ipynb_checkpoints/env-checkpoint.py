import os
import tsplib95
import numpy as np
import pandas as pd
import networkx as nx
from src.problems.base.env import BaseEnv
from src.problems.cvrp.components import Solution


class Env(BaseEnv):
    """CVRP env that stores the instance data, current solution, and problem state to support algorithm."""
    def __init__(self, data_name: str, **kwargs):
        super().__init__(data_name, "cvrp")
        self.construction_steps = self.instance_data["node_num"]
        self.key_item = "total_current_cost"
        self.compare = lambda x, y: y - x

    @property
    def is_complete_solution(self) -> bool:
        return len(set([node for route in self.current_solution.routes for node in route])) == self.instance_data["node_num"]

    # 加载CVRP问题的数据文件，解析并返回包含问题核心参数的字典
    def load_data(self, data_path: str) -> None:
        # 加载TSPLIB格式的CVRP数据文件（如.vrp文件），返回问题对象
        problem = tsplib95.load(data_path)
        
        # 获取 depot（仓库节点）的索引，TSPLIB中节点编号从1开始，这里转为0基索引
        depot = problem.depots[0] - 1
        
        # 判断距离计算方式是否为二维欧氏距离（EUC_2D）
        if problem.edge_weight_type == "EUC_2D":
            # 提取所有节点的坐标（键为节点编号1-based，值为(x,y)）
            node_coords = problem.node_coords
            # 计算节点总数（包括depot）
            node_num = len(node_coords)
            # 初始化距离矩阵（node_num x node_num）
            distance_matrix = np.zeros((node_num, node_num))
            # 遍历所有节点对，计算欧氏距离并填充矩阵
            for i in range(node_num):
                for j in range(node_num):
                    if i != j:  # 跳过自身到自身的距离（保持为0）
                        # 获取节点i+1和j+1的坐标（因为node_coords的键是1-based）
                        x1, y1 = node_coords[i + 1]
                        x2, y2 = node_coords[j + 1]
                        # 计算欧氏距离并赋值到矩阵
                        distance_matrix[i][j] = np.sqrt((x1 - x2) **2 + (y1 - y2)** 2)
        # 若距离类型不是EUC_2D，则直接从问题的图结构中提取距离矩阵
        else:
            # 将问题的图结构转换为numpy数组形式的距离矩阵
            distance_matrix = nx.to_numpy_array(problem.get_graph())
            # 节点总数为距离矩阵的维度
            node_num = len(distance_matrix)
        
        # 解析车辆车辆数量（从文件名或数据文件中提取）
        # 情况1：文件名格式如"xxx-kXX.vrp"，其中k后的数字为车辆数（如k10表示10辆车）
        if os.path.basename(data_path).split(".")[0].split("-")[-1][0] == "k":
            vehicle_num = int(os.path.basename(data_path).split(".")[0].split("-")[-1][1:])
        # 情况2：数据文件最后一行包含"VEHICLE : X"，其中X为车辆数
        elif open(data_path).readlines()[-1].strip().split(" : ")[0] == "VEHICLE":
            vehicle_num = int(open(data_path).readlines()[-1].strip().split(" : ")[-1])
        # 其他格式不支持，抛出异常
        else:
            raise NotImplementedError("Vehicle number error")
        
        # 提取车辆的最大容量限制
        capacity = problem.capacity
        # 提取各节点的需求（0基索引，depot的需求通常为0）
        demands = np.array(list(problem.demands.values()))
        
        # 返回包含所有解析出的问题参数的字典
        return {"node_num": node_num, "distance_matrix": distance_matrix, "depot": depot, "vehicle_num": vehicle_num, "capacity": capacity, "demands": demands}

    def init_solution(self) -> Solution:
        return Solution(routes=[[self.instance_data["depot"]] for _ in range(self.instance_data["vehicle_num"])], depot=self.instance_data["depot"])

    def get_key_value(self, solution: Solution=None) -> float:
        """Get the key value of the current solution based on the key item."""
        if solution is None:
            solution = self.current_solution
        total_current_cost = 0
        for vehicle_index in range(self.instance_data["vehicle_num"]):
            route = solution.routes[vehicle_index]
            # The cost of the current solution for each vehicle.
            cost_for_vehicle = sum([self.instance_data["distance_matrix"][route[index]][route[index + 1]] for index in range(len(route) - 1)])
            if len(route) > 0:
                cost_for_vehicle += self.instance_data["distance_matrix"][route[-1]][route[0]]
            total_current_cost += cost_for_vehicle
        return total_current_cost

    def validation_solution(self, solution: Solution=None) -> bool:
        """
        Check the validation of this solution in following items:
            1. Node existence: Each node in each route must be within the valid range.
            2. Uniqueness: Each node (except for the depot) must only be visited once across all routes.
            3. Include depot: Each route must include at the depot.
            4. Capacity constraints: The load of each vehicle must not exceed its capacity.
        """
        if solution is None:
            solution = self.current_solution

        if not isinstance(solution, Solution) or not isinstance(solution.routes, list):
            return False

        # Check node existence
        for route in solution.routes:
            for node in route:
                if not (0 <= node < self.instance_data["node_num"]):
                    return False

        # Check uniqueness
        all_nodes = [node for route in solution.routes for node in route if node != self.instance_data["depot"]] + [self.instance_data["depot"]]
        if len(all_nodes) != len(set(all_nodes)):
            return False

        for route in solution.routes:
            # Check include depot
            if self.instance_data["depot"] not in route:
                return False

            # Check vehicle load capacity constraints
            load = sum(self.instance_data["demands"][node] for node in route)
            if load > self.instance_data["capacity"]:
                return False

        return True
